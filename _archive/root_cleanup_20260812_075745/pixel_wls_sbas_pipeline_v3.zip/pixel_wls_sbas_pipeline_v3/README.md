# V3 — FULL network, pixel-wise coherence/variance WLS

This is the next experiment after V2.

V2 proved that:
- GAMMA coherence mapping is correct: `DIFF/*.cc`, 5521×5930, big-endian float32;
- a selected 666-IFG network can remain connected, full-rank, degree>=3 and bridge-free, yet still strongly degrade the solution;
- therefore V3 performs **no IFG deletion**.

## Main change

V3 moves from one weight per IFG,

```text
w_k
```

to one weight for every PS × IFG observation,

```text
w_ik
```

using the actual GAMMA `.cc` value at each PS location.

Tested modes:

```text
UNIFORM
COH
VAR
VAR_STD
```

where:

```text
COH:
    w = gamma

VAR:
    w ~ gamma^2 / (1 - gamma^2)

VAR_STD:
    VAR * (median(ifg_std) / ifg_std_k)^2
```

Weights are conservatively clipped but no IFG is assigned zero weight solely because its coherence is low.

## Computational implementation

The 257 acquisitions are represented by 256 consecutive phase increments.

Because the current network connects only nearby acquisition indices, its weighted
normal equation is banded. V3 builds and solves independent PS-specific banded
normal equations in vectorized PS blocks instead of calling a 256×256 `lstsq`
375,051 times.

The code includes a synthetic dense-vs-banded WLS self-test.

## Coherence cache

The first run extracts all 763 GAMMA `.cc` rasters at the 375,051 PS positions.

Source:

```text
/mnt/vol-gdc28n1r/insar/cangzhou_P69/DIFF/<date1>_<date2>.cc
```

Layout fixed from the verified production data:

```text
5521 × 5930
>f4
ps2.ij[:,1] = row, 1-based
ps2.ij[:,2] = col, 1-based
```

The expensive result is cached at:

```text
<dataset>/_pixel_wls_cache_v3/coherence_ps_ifg_float16.dat
```

Later runs reuse it.

## Downstream correction branches

For every weighting mode:

```text
RAW_REF
SELF_RAMP
LEGACY_RAMP_SCN_DIAG
```

`SELF_RAMP` is a new robust XY plane estimated from that mode's own acquisition
time series and then re-referenced to the established exact 65 PS.

`LEGACY_RAMP_SCN_DIAG` is **diagnostic only**. It applies old ramp/SCN fields so
we can isolate the effect of the new inversion under the old correction. It is
never automatically selected as a production chain.

## Install

```bash
cd /home/ubuntu/software/pystamps-main

rm -rf /tmp/pixel_wls_v3
mkdir -p /tmp/pixel_wls_v3

unzip /上传目录/pixel_wls_sbas_pipeline_v3.zip \
  -d /tmp/pixel_wls_v3

bash \
  /tmp/pixel_wls_v3/pixel_wls_sbas_pipeline_v3/install.sh
```

Run:

```bash
cd /home/ubuntu/software/pystamps-main

./run_pixel_wls_sbas_v3.sh
```

The first run may spend substantial time building the coherence cache because all
763 ~125 MB coherence files must be sampled. Do not interrupt if progress is moving;
the extraction stage is resumable.

## First outputs to inspect

```bash
D=/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized

LATEST=$(
  find "$D/_audit" \
    -maxdepth 1 \
    -type d \
    -name 'pixel_wls_sbas_v3_*' \
    -printf '%T@ %p\n' |
  sort -nr |
  head -1 |
  cut -d' ' -f2-
)

echo "===== POOLED ====="
column -s, -t "$LATEST/02_branch_pooled_validation.csv"

echo "===== GRID ====="
column -s, -t "$LATEST/03_branch_grid_validation.csv" | less -S

echo "===== TEMPORAL COHERENCE ====="
column -s, -t "$LATEST/05_temporal_coherence_summary.csv"

echo "===== TC QUARTILES ====="
column -s, -t "$LATEST/06_temporal_coherence_truth_quartiles.csv" | less -S

echo "===== DECISION ====="
cat "$LATEST/07_DECISION.json"
```

## Product guard

The expensive full HDF5/TIF product is written only if an eligible self-consistent
new branch (`RAW_REF` or `SELF_RAMP`) beats current Final-C pooled RMSE by at least
2% by default.

The legacy correction diagnostic can never trigger automatic production.
