#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/home/ubuntu/software/pystamps-main}"
PYTHON="${PYTHON:-/home/ubuntu/software/miniconda3/envs/stamps/bin/python}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$ROOT/tools"

cp "$HERE/pixel_wls_sbas_pipeline_v3.py" \
   "$ROOT/tools/pixel_wls_sbas_v3.py"

cp "$HERE/run_pixel_wls_sbas_v3.sh" \
   "$ROOT/run_pixel_wls_sbas_v3.sh"

chmod +x "$ROOT/tools/pixel_wls_sbas_v3.py"
chmod +x "$ROOT/run_pixel_wls_sbas_v3.sh"

echo "Installed:"
echo "  $ROOT/tools/pixel_wls_sbas_v3.py"
echo "  $ROOT/run_pixel_wls_sbas_v3.sh"
echo
echo "No existing V1/V2, Final-C, Stage6/7/8 file is modified."
echo "No conda/pip package is changed."

echo
echo "Dependency check:"
"$PYTHON" - <<'PY'
mods = [
    "numpy",
    "scipy",
    "h5py",
    "geopandas",
    "rasterio",
    "pyproj",
    "pandas",
]
missing = []
for m in mods:
    try:
        __import__(m)
        print("  OK  ", m)
    except Exception as e:
        print("  MISS", m, repr(e))
        missing.append(m)

if missing:
    raise SystemExit(
        "Missing dependencies: "
        + ", ".join(missing)
        + ". Do NOT change the existing environment blindly."
    )
PY

echo
echo "Self-test:"
"$ROOT/run_pixel_wls_sbas_v3.sh" --self-test

echo
echo "Installation complete."
echo
echo "Run:"
echo "  cd '$ROOT'"
echo "  ./run_pixel_wls_sbas_v3.sh"

if [[ "${1:-}" == "--run" ]]; then
    shift
    echo
    echo "Running V3 now..."
    exec "$ROOT/run_pixel_wls_sbas_v3.sh" "$@"
fi
