#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
V3: FULL-network pixel-wise coherence/variance WLS for the Cangzhou GAMMA/pySTAMPS project.

This version intentionally stops optimizing by deleting IFGs.  All 763 IFGs are kept.
The V2 experiment showed that even a topologically healthy selected network strongly
changed the acquisition-space solution because this multilooked dataset contains
substantial non-closure.

Main experiment
---------------
P0 UNIFORM
    Standard full-network least squares.  Implemented with one global pseudoinverse.

P1 COH
    Per-PS/per-IFG weights w_ik proportional to GAMMA coherence gamma_ik.

P2 VAR
    Per-PS/per-IFG phase-variance proxy:
        w_ik ~ gamma_ik^2 / (1 - gamma_ik^2)
    with conservative clipping.  The common number-of-looks factor cancels in a
    relative WLS solution, so no unverified "independent looks" value is assumed.

P3 VAR_STD
    P2 multiplied by the existing global IFG reliability factor
        (median(ifg_std) / ifg_std_k)^2.

For every weighting mode the script evaluates:
    RAW_REF
        Full-network solution with the exact fixed 65-PS reference only.
    SELF_RAMP
        A new robust linear XY ramp estimated from that weighting mode's own time
        series, then re-referenced to the same 65 PS.
    LEGACY_RAMP_SCN_DIAG
        Optional diagnostic only: apply the existing ph_ramp + ph_scn to isolate
        whether a new network inversion helps under the old downstream correction.
        This branch can NEVER be auto-promoted to a new production product.

The script also outputs per-PS temporal coherence from network residuals.

Important
---------
- No IFG is removed.
- Existing Final-C and Stage6/7/8 files are read-only.
- No conda/pip package is installed or changed.
- The expensive GAMMA *.cc extraction is cached as a PS-major float16 matrix.
- Full candidate time-series products are written only when a SELF-CONSISTENT
  (RAW_REF or SELF_RAMP) new branch beats current Final-C by the configured margin.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import gc
import hashlib
import json
import math
import os
import re
import shutil
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy.io import loadmat
from scipy.spatial import cKDTree
from scipy import sparse


# =============================================================================
# basic utilities
# =============================================================================

def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    for row in rows:
        for k in row:
            if k not in fields:
                fields.append(k)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def norm_key(x: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(x).lower())


def local_xy(lon, lat, lon0=None, lat0=None):
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    if lon0 is None:
        lon0 = float(np.nanmedian(lon))
    if lat0 is None:
        lat0 = float(np.nanmedian(lat))
    R = 6371008.8
    x = np.deg2rad(lon - lon0) * R * math.cos(math.radians(lat0))
    y = np.deg2rad(lat - lat0) * R
    return x, y, float(lon0), float(lat0)


def lonlat_to_xy(lon, lat, lon0, lat0):
    R = 6371008.8
    x = math.radians(lon - lon0) * R * math.cos(math.radians(lat0))
    y = math.radians(lat - lat0) * R
    return x, y


def matlab_datenum_to_datetime(v: float) -> dt.datetime:
    ordinal = int(v)
    frac = float(v) - ordinal
    return (
        dt.datetime.fromordinal(ordinal)
        + dt.timedelta(days=frac)
        - dt.timedelta(days=366)
    )


def find_wavelength(project: Path) -> Tuple[float, str]:
    c = 299792458.0
    candidates = (
        list((project / "RSLC_cropped").glob("*.rslc.par"))
        + list(project.rglob("*.rslc.par"))
    )
    for p in candidates[:500]:
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
            m = re.search(r"radar_frequency:\s*([0-9.eE+-]+)", text)
            if m:
                f = float(m.group(1))
                if f > 1e8:
                    return c / f, str(p)
        except Exception:
            pass
    return 0.0554657595, "fallback_Sentinel1_C_band"


def mat_is_hdf5(path: Path) -> bool:
    try:
        import h5py
        with h5py.File(path, "r"):
            return True
    except Exception:
        return False


def classic_load_var(path: Path, name: str) -> np.ndarray:
    obj = loadmat(
        path,
        variable_names=[name],
        squeeze_me=False,
        struct_as_record=False,
    )
    if name not in obj:
        raise KeyError(f"{path}:{name} not found")
    return np.asarray(obj[name])


class MatrixReader:
    """Row-block reader for classic MAT or MATLAB-v7.3 HDF5."""

    def __init__(self, path: Path, var: str, nrow: int, ncol: int):
        self.path = Path(path)
        self.var = var
        self.nrow = int(nrow)
        self.ncol = int(ncol)
        self.hdf5 = mat_is_hdf5(self.path)
        self._classic = None
        self._transposed = False

        if self.hdf5:
            import h5py
            with h5py.File(self.path, "r") as h:
                if var not in h:
                    raise KeyError(f"{self.path}:{var} not found")
                shape = tuple(int(v) for v in h[var].shape)
            if shape == (nrow, ncol):
                self._transposed = False
            elif shape == (ncol, nrow):
                self._transposed = True
            else:
                raise ValueError(
                    f"{self.path}:{var} shape={shape}; expected "
                    f"({nrow},{ncol}) or ({ncol},{nrow})"
                )
        else:
            a = classic_load_var(self.path, var)
            if a.shape == (nrow, ncol):
                self._classic = a
                self._transposed = False
            elif a.shape == (ncol, nrow):
                self._classic = a
                self._transposed = True
            else:
                raise ValueError(
                    f"{self.path}:{var} shape={a.shape}; expected "
                    f"({nrow},{ncol}) or ({ncol},{nrow})"
                )

    def rows(self, idx: np.ndarray) -> np.ndarray:
        idx = np.asarray(idx, dtype=np.int64)
        if self.hdf5:
            import h5py
            order = np.argsort(idx)
            sidx = idx[order]
            if np.any(np.diff(sidx) == 0):
                raise ValueError("rows() requires unique indices")
            with h5py.File(self.path, "r") as h:
                ds = h[self.var]
                if not self._transposed:
                    a = np.asarray(ds[sidx, :])
                else:
                    a = np.asarray(ds[:, sidx]).T
            inv = np.empty_like(order)
            inv[order] = np.arange(len(order))
            return a[inv]
        a = self._classic.T if self._transposed else self._classic
        return np.asarray(a[idx, :])

    def block(self, r0: int, r1: int) -> np.ndarray:
        if self.hdf5:
            import h5py
            with h5py.File(self.path, "r") as h:
                ds = h[self.var]
                if not self._transposed:
                    return np.asarray(ds[r0:r1, :])
                return np.asarray(ds[:, r0:r1]).T
        a = self._classic.T if self._transposed else self._classic
        return np.asarray(a[r0:r1, :])


# =============================================================================
# project metadata
# =============================================================================

def load_ps_metadata(dataset: Path):
    obj = loadmat(
        dataset / "ps2.mat",
        variable_names=["n_ps", "n_image", "lonlat", "ij"],
        squeeze_me=True,
        struct_as_record=False,
    )
    n_ps = int(np.asarray(obj["n_ps"]).reshape(-1)[0])
    n_image = int(np.asarray(obj["n_image"]).reshape(-1)[0])

    lonlat = np.asarray(obj["lonlat"], dtype=float)
    if lonlat.shape[0] != n_ps and lonlat.shape[1] == n_ps:
        lonlat = lonlat.T
    if lonlat.shape[0] != n_ps or lonlat.shape[1] < 2:
        raise ValueError(f"ps2.lonlat unexpected shape {lonlat.shape}")

    ij = np.asarray(obj["ij"])
    if ij.shape[0] != n_ps and ij.shape[1] == n_ps:
        ij = ij.T
    if ij.shape[0] != n_ps or ij.shape[1] < 3:
        raise ValueError(f"ps2.ij unexpected shape {ij.shape}")

    return (
        n_ps,
        n_image,
        lonlat[:, 0].astype(float),
        lonlat[:, 1].astype(float),
        ij,
    )


def load_network(dataset: Path, n_image: int):
    obj = loadmat(
        dataset / "phuw_sm2.mat",
        variable_names=["ifgday_ix", "day"],
        squeeze_me=True,
        struct_as_record=False,
    )

    ifg = np.asarray(obj["ifgday_ix"])
    if ifg.ndim == 2 and ifg.shape[0] == 2 and ifg.shape[1] != 2:
        ifg = ifg.T
    if ifg.ndim != 2 or ifg.shape[1] != 2:
        raise ValueError(f"ifgday_ix shape={ifg.shape}")

    day = np.asarray(obj["day"], dtype=float).reshape(-1)
    if len(day) != n_image:
        raise ValueError(f"day length={len(day)} != n_image={n_image}")

    dts = [matlab_datenum_to_datetime(v) for v in day]
    dates = [d.strftime("%Y%m%d") for d in dts]

    x = np.asarray(ifg, dtype=float)

    if (
        np.nanmin(x) >= 1
        and np.nanmax(x) <= n_image
        and np.allclose(x, np.round(x))
    ):
        edges = np.round(x).astype(int) - 1
        mode = "1based_acquisition_indices"
    elif (
        np.nanmin(x) >= 0
        and np.nanmax(x) < n_image
        and np.allclose(x, np.round(x))
    ):
        edges = np.round(x).astype(int)
        mode = "0based_acquisition_indices"
    else:
        lookup_day = {int(round(v)): i for i, v in enumerate(day)}
        lookup_date = {int(v): i for i, v in enumerate(dates)}
        edges = np.empty_like(x, dtype=int)
        for r in range(len(x)):
            for c in range(2):
                v = int(round(float(x[r, c])))
                if v in lookup_day:
                    edges[r, c] = lookup_day[v]
                elif v in lookup_date:
                    edges[r, c] = lookup_date[v]
                else:
                    raise ValueError(
                        f"Cannot map ifgday_ix value {v} to acquisition"
                    )
        mode = "date_values_mapped"

    if np.any(edges[:, 0] == edges[:, 1]):
        raise ValueError("self-edge found")

    return edges, dates, dts, day, mode


# =============================================================================
# full-network interval design and batched banded WLS
# =============================================================================

def build_interval_design(edges: np.ndarray, n_image: int):
    """Design in consecutive acquisition increments.

    Unknown d_j = x_{j+1} - x_j, j=0..n_image-2.
    Each IFG is a signed sum over consecutive increments.
    """
    n = n_image - 1
    rows = []
    cols = []
    data = []
    spans = np.empty(len(edges), dtype=int)

    for k, (a, b) in enumerate(edges):
        a = int(a)
        b = int(b)
        if a < b:
            lo, hi, sgn = a, b, 1.0
        else:
            lo, hi, sgn = b, a, -1.0
        spans[k] = hi - lo
        for j in range(lo, hi):
            rows.append(k)
            cols.append(j)
            data.append(sgn)

    B = sparse.csr_matrix(
        (np.asarray(data, dtype=np.float64), (rows, cols)),
        shape=(len(edges), n),
    )

    return B, spans


def build_band_contributor_matrices(
    edges: np.ndarray,
    n_image: int,
    max_bandwidth: int,
):
    n = n_image - 1
    spans = np.abs(edges[:, 1] - edges[:, 0])
    bw = int(np.max(spans) - 1)

    if bw > max_bandwidth:
        raise RuntimeError(
            f"Temporal-index half-bandwidth={bw} exceeds --max-bandwidth="
            f"{max_bandwidth}. Inspect the IFG network before using the V3 "
            "vectorized band solver."
        )

    mats = []

    for d in range(bw + 1):
        rows = []
        cols = []

        for e, (a, b) in enumerate(edges):
            lo = int(min(a, b))
            hi = int(max(a, b))

            if hi - lo <= d:
                continue

            # Store A[j, j-d] at band column j.
            # C_d column is k=j-d, so j=k+d.
            for j in range(lo + d, hi):
                rows.append(e)
                cols.append(j - d)

        C = sparse.csr_matrix(
            (
                np.ones(len(rows), dtype=np.float64),
                (rows, cols),
            ),
            shape=(len(edges), n - d),
        )
        mats.append(C)

    return mats, bw


def weighted_normal_band_and_rhs(
    W: np.ndarray,
    Y: np.ndarray,
    B: sparse.csr_matrix,
    contributors: Sequence[sparse.csr_matrix],
    bw: int,
    ridge_rel: float,
):
    """Build a batch of weighted normal equations in lower-band storage.

    A_band[:, d, j] = N[j, j-d]
    """
    W = np.asarray(W, dtype=np.float64)
    Y = np.asarray(Y, dtype=np.float64)

    batch, n_ifg = W.shape
    n = B.shape[1]

    if Y.shape != W.shape:
        raise ValueError("Y/W shape mismatch")

    Ab = np.zeros((batch, bw + 1, n), dtype=np.float64)
    WT = W.T

    for d, C in enumerate(contributors):
        vals = (C.T @ WT).T
        Ab[:, d, d:] = vals

    ZT = (W * Y).T
    rhs = (B.T @ ZT).T

    diag = Ab[:, 0, :]
    scale = np.nanmedian(diag, axis=1)
    ridge = ridge_rel * np.maximum(scale, 1.0)
    Ab[:, 0, :] += ridge[:, None]

    return Ab, rhs


def solve_spd_banded_batch(A_band: np.ndarray, rhs: np.ndarray):
    """Vectorized batch Cholesky for independent SPD lower-banded systems."""
    A_band = np.asarray(A_band, dtype=np.float64)
    rhs = np.asarray(rhs, dtype=np.float64)

    batch, bw1, n = A_band.shape
    bw = bw1 - 1

    if rhs.shape != (batch, n):
        raise ValueError("rhs shape mismatch")

    L = np.zeros_like(A_band)
    bad = np.zeros(batch, dtype=bool)
    eps = 1e-12

    for j in range(n):
        diag = A_band[:, 0, j].copy()

        for d in range(1, min(bw, j) + 1):
            diag -= L[:, d, j] ** 2

        bad_j = (~np.isfinite(diag)) | (diag <= eps)
        bad |= bad_j
        diag = np.where(bad_j, eps, diag)
        L[:, 0, j] = np.sqrt(diag)

        for i in range(j + 1, min(n, j + bw + 1)):
            d = i - j
            val = A_band[:, d, i].copy()
            k0 = max(0, j - bw, i - bw)

            for k in range(k0, j):
                val -= (
                    L[:, i - k, i]
                    * L[:, j - k, j]
                )

            L[:, d, i] = val / L[:, 0, j]

    z = np.empty_like(rhs)

    for j in range(n):
        val = rhs[:, j].copy()

        for d in range(1, min(bw, j) + 1):
            val -= L[:, d, j] * z[:, j - d]

        z[:, j] = val / L[:, 0, j]

    x = np.empty_like(rhs)

    for j in range(n - 1, -1, -1):
        val = z[:, j].copy()

        for i in range(j + 1, min(n, j + bw + 1)):
            val -= L[:, i - j, i] * x[:, i]

        x[:, j] = val / L[:, 0, j]

    x[bad, :] = np.nan

    return x, bad


def increments_to_acquisition(d: np.ndarray, n_image: int) -> np.ndarray:
    x = np.zeros((len(d), n_image), dtype=np.float64)
    x[:, 1:] = np.cumsum(d, axis=1)
    return x


def weighted_mode_weights(
    mode: str,
    coherence: np.ndarray,
    ifg_std_factor: np.ndarray,
    gamma_floor: float,
    gamma_cap: float,
    weight_floor: float,
    weight_cap: float,
):
    g = np.asarray(coherence, dtype=np.float64)
    g = np.where(np.isfinite(g), g, 0.0)
    g = np.clip(g, gamma_floor, gamma_cap)

    if mode == "COH":
        W = g.copy()

    elif mode in ("VAR", "VAR_STD"):
        # Relative high-coherence phase-variance proxy.
        # Any common looks factor would scale every observation weight equally
        # and therefore cancels from the WLS solution.
        W = (g * g) / np.maximum(1.0 - g * g, 1e-6)

        if mode == "VAR_STD":
            W *= ifg_std_factor[None, :]

    else:
        raise ValueError(mode)

    W = np.clip(W, weight_floor, weight_cap)

    # Row-wise normalization changes no WLS solution and improves conditioning.
    med = np.median(W, axis=1)
    med = np.where(np.isfinite(med) & (med > 0), med, 1.0)
    W /= med[:, None]

    return W


def solve_pixel_block(
    Y: np.ndarray,
    coherence: Optional[np.ndarray],
    mode: str,
    B: sparse.csr_matrix,
    contributors: Sequence[sparse.csr_matrix],
    bw: int,
    ifg_std_factor: np.ndarray,
    uniform_pinv: Optional[np.ndarray],
    edge_sign: float,
    args,
):
    Y = np.asarray(Y, dtype=np.float64)

    finite_y = np.isfinite(Y)

    if mode == "UNIFORM":
        if uniform_pinv is None:
            raise RuntimeError("uniform_pinv missing")

        # Uniform reference branch uses the same full network.
        # If any observation is missing, solve that row via the weighted engine
        # with zero weight on missing edges.
        if np.all(finite_y):
            d = Y @ uniform_pinv.T
            bad = np.zeros(len(Y), dtype=bool)
            W_for_tc = np.ones_like(Y)
        else:
            W = finite_y.astype(np.float64)
            Y0 = np.where(finite_y, Y, 0.0)
            Ab, rhs = weighted_normal_band_and_rhs(
                W,
                Y0,
                B,
                contributors,
                bw,
                args.ridge_rel,
            )
            d, bad = solve_spd_banded_batch(Ab, rhs)
            W_for_tc = W

    else:
        if coherence is None:
            raise RuntimeError("pixel-wise coherence block missing")

        W = weighted_mode_weights(
            mode,
            coherence,
            ifg_std_factor,
            args.gamma_floor,
            args.gamma_cap,
            args.weight_floor,
            args.weight_cap,
        )

        # Missing unwrapped observations receive zero weight.
        W = np.where(finite_y, W, 0.0)
        Y0 = np.where(finite_y, Y, 0.0)

        Ab, rhs = weighted_normal_band_and_rhs(
            W,
            Y0,
            B,
            contributors,
            bw,
            args.ridge_rel,
        )
        d, bad = solve_spd_banded_batch(Ab, rhs)
        W_for_tc = W

    d *= edge_sign

    # Temporal coherence from wrapped network residuals.
    pred = (B @ d.T).T
    residual = np.where(finite_y, Y * edge_sign - pred, np.nan)
    phasor = np.exp(1j * residual)

    valid = np.isfinite(residual)
    nvalid = np.sum(valid, axis=1)

    tc = np.abs(
        np.nansum(phasor, axis=1)
        / np.maximum(nvalid, 1)
    )

    Wtc = np.where(valid, W_for_tc, 0.0)
    wsum = np.sum(Wtc, axis=1)

    tc_weighted = np.abs(
        np.nansum(Wtc * phasor, axis=1)
        / np.maximum(wsum, 1e-12)
    )

    tc[nvalid == 0] = np.nan
    tc_weighted[wsum <= 0] = np.nan

    return d, tc, tc_weighted, bad


# =============================================================================
# GAMMA coherence cache
# =============================================================================

def date12_for_edges(edges: np.ndarray, dates: Sequence[str]) -> List[str]:
    return [
        f"{dates[int(a)]}_{dates[int(b)]}"
        for a, b in edges
    ]


def find_cc_file(diff_dir: Path, d1: str, d2: str) -> Path:
    p = diff_dir / f"{d1}_{d2}.cc"
    if p.exists():
        return p
    q = diff_dir / f"{d2}_{d1}.cc"
    if q.exists():
        return q
    raise FileNotFoundError(f"Missing .cc for {d1}_{d2}")


def validate_cc_layout(
    cc_files: Sequence[Path],
    height: int,
    width: int,
    endian: str,
):
    expected = height * width * 4

    bad = [
        str(p)
        for p in cc_files
        if p.stat().st_size != expected
    ]

    if bad:
        raise RuntimeError(
            f"{len(bad)} coherence files do not match "
            f"{height}x{width} float32; first={bad[:3]}"
        )

    # Validate chosen byte order on first file.
    ncell = height * width
    p = cc_files[0]
    a = np.memmap(
        p,
        mode="r",
        dtype=endian,
        shape=(ncell,),
    )
    idx = np.linspace(
        0,
        ncell - 1,
        min(100000, ncell),
        dtype=np.int64,
    )
    v = np.asarray(a[idx], dtype=np.float64)
    physical = np.isfinite(v) & (v >= 0.0) & (v <= 1.05)
    frac = float(np.mean(physical))

    if frac < 0.99:
        raise RuntimeError(
            f"Chosen coherence dtype {endian} is not physically valid: "
            f"physical_fraction={frac:.6f}"
        )

    return frac


def map_ps_flat_indices(
    ij: np.ndarray,
    height: int,
    width: int,
    row_col: int,
    col_col: int,
    index_base: int,
):
    r0 = np.asarray(ij[:, row_col], dtype=float)
    c0 = np.asarray(ij[:, col_col], dtype=float)

    if not (
        np.all(np.isfinite(r0))
        and np.all(np.isfinite(c0))
    ):
        raise RuntimeError("ps2.ij row/col contains non-finite values")

    if not (
        np.allclose(r0, np.round(r0))
        and np.allclose(c0, np.round(c0))
    ):
        raise RuntimeError("ps2.ij selected row/col columns are not integer-like")

    r = np.round(r0).astype(np.int64) - index_base
    c = np.round(c0).astype(np.int64) - index_base

    inside = (
        (r >= 0) & (r < height)
        & (c >= 0) & (c < width)
    )
    inside_fraction = float(np.mean(inside))

    if inside_fraction < 0.999:
        raise RuntimeError(
            f"PS->coherence raster mapping inside fraction only "
            f"{inside_fraction:.6f}"
        )

    flat = r * width + c
    return flat.astype(np.int64), inside_fraction


def coherence_cache_signature(
    cc_files: Sequence[Path],
    flat: np.ndarray,
    height: int,
    width: int,
    endian: str,
):
    h = hashlib.sha256()
    h.update(f"{height}x{width}|{endian}|".encode())
    h.update(np.asarray(flat, dtype=np.int64).tobytes())
    for p in cc_files:
        st = p.stat()
        h.update(
            f"{p.name}|{st.st_size}|{int(st.st_mtime)}|".encode()
        )
    return h.hexdigest()


def build_or_reuse_coherence_cache(
    cache_dir: Path,
    cc_files: Sequence[Path],
    flat: np.ndarray,
    n_ps: int,
    n_ifg: int,
    height: int,
    width: int,
    endian: str,
    workers: int,
):
    cache_dir.mkdir(parents=True, exist_ok=True)

    final_dat = cache_dir / "coherence_ps_ifg_float16.dat"
    meta_path = cache_dir / "coherence_ps_ifg_float16.json"

    signature = coherence_cache_signature(
        cc_files,
        flat,
        height,
        width,
        endian,
    )

    expected_bytes = n_ps * n_ifg * 2

    if final_dat.exists() and meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if (
                meta.get("signature") == signature
                and final_dat.stat().st_size == expected_bytes
                and meta.get("status") == "complete"
            ):
                print("Reusing coherence cache:", final_dat)
                mm = np.memmap(
                    final_dat,
                    mode="r",
                    dtype=np.float16,
                    shape=(n_ps, n_ifg),
                )
                return mm, meta
        except Exception:
            pass

    tmp_ifg = cache_dir / "coherence_ifg_ps_float16.tmp.dat"
    progress_path = cache_dir / "coherence_ifg_ps_progress.json"

    tmp = np.memmap(
        tmp_ifg,
        mode="w+" if not tmp_ifg.exists() else "r+",
        dtype=np.float16,
        shape=(n_ifg, n_ps),
    )

    completed = set()

    if progress_path.exists():
        try:
            pobj = json.loads(progress_path.read_text(encoding="utf-8"))
            if pobj.get("signature") == signature:
                completed = set(int(v) for v in pobj.get("completed_ifg", []))
        except Exception:
            completed = set()

    flat_sorted_order = np.argsort(flat)
    flat_sorted = flat[flat_sorted_order]
    inverse_order = np.empty_like(flat_sorted_order)
    inverse_order[flat_sorted_order] = np.arange(n_ps)

    ncell = height * width

    def read_one(k: int):
        p = cc_files[k]
        a = np.memmap(
            p,
            mode="r",
            dtype=endian,
            shape=(ncell,),
        )
        # Sorted raster indices give close-to-sequential page access.
        v_sorted = np.asarray(a[flat_sorted], dtype=np.float32)
        v = v_sorted[inverse_order]
        physical = np.isfinite(v) & (v >= 0.0) & (v <= 1.05)
        if float(np.mean(physical)) < 0.95:
            raise RuntimeError(
                f"{p.name}: only {np.mean(physical):.4f} physical coherence samples"
            )
        v = np.where(physical, np.clip(v, 0.0, 1.0), 0.0)
        return k, v.astype(np.float16)

    todo = [k for k in range(n_ifg) if k not in completed]

    print(
        f"Building coherence cache: completed={len(completed)}/{n_ifg}, "
        f"remaining={len(todo)}, workers={workers}"
    )

    if todo:
        with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
            futs = {
                ex.submit(read_one, k): k
                for k in todo
            }
            done_count = len(completed)

            for fut in as_completed(futs):
                k, v = fut.result()
                tmp[k, :] = v
                completed.add(k)
                done_count += 1

                if done_count % 10 == 0 or done_count == n_ifg:
                    tmp.flush()
                    progress_path.write_text(
                        json.dumps(
                            {
                                "signature": signature,
                                "completed_ifg": sorted(completed),
                            },
                            indent=2,
                        ),
                        encoding="utf-8",
                    )
                    print(
                        f"  coherence cache IFGs: {done_count}/{n_ifg}"
                    )

    tmp.flush()

    if len(completed) != n_ifg:
        raise RuntimeError("coherence cache extraction incomplete")

    # Transpose once into PS-major layout for fast blockwise WLS.
    print("Transposing coherence cache to PS-major layout ...")
    final = np.memmap(
        final_dat,
        mode="w+",
        dtype=np.float16,
        shape=(n_ps, n_ifg),
    )

    block = 5000
    for r0 in range(0, n_ps, block):
        r1 = min(n_ps, r0 + block)
        final[r0:r1, :] = tmp[:, r0:r1].T
        if r0 % 50000 == 0:
            final.flush()
            print(f"  transpose PS: {r1}/{n_ps}")

    final.flush()

    meta = {
        "status": "complete",
        "signature": signature,
        "shape": [n_ps, n_ifg],
        "dtype": "float16",
        "source_dtype": endian,
        "height": height,
        "width": width,
        "n_ps": n_ps,
        "n_ifg": n_ifg,
        "files_first_last": [
            str(cc_files[0]),
            str(cc_files[-1]),
        ],
    }

    meta_path.write_text(
        json.dumps(meta, indent=2),
        encoding="utf-8",
    )

    # Final cache is the expensive reusable artifact. The transposition temp is not.
    del tmp
    gc.collect()

    try:
        tmp_ifg.unlink()
        progress_path.unlink(missing_ok=True)
    except Exception:
        pass

    mm = np.memmap(
        final_dat,
        mode="r",
        dtype=np.float16,
        shape=(n_ps, n_ifg),
    )

    return mm, meta


# =============================================================================
# reference / ramp / time coefficients
# =============================================================================

def exact_reference_indices(dataset: Path, n_ps: int):
    candidates = sorted(
        [
            p
            for p in dataset.glob("final_C_fixed_reference_*")
            if (
                p
                / "reference"
                / "reference_ps_indices_1based.txt"
            ).exists()
        ],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    if not candidates:
        raise RuntimeError(
            "Established Final-C reference index file not found"
        )

    p = (
        candidates[0]
        / "reference"
        / "reference_ps_indices_1based.txt"
    )

    ids = np.asarray(
        np.loadtxt(p, dtype=np.int64),
        dtype=np.int64,
    ).reshape(-1) - 1

    ids = np.unique(ids)

    if (
        len(ids) < 10
        or np.any(ids < 0)
        or np.any(ids >= n_ps)
    ):
        raise RuntimeError(f"Invalid reference PS list: {p}")

    return ids, str(p)


def spatially_balanced_sample(
    x: np.ndarray,
    y: np.ndarray,
    target_n: int,
    seed: int,
):
    n = len(x)

    if target_n >= n:
        return np.arange(n, dtype=np.int64)

    rng = np.random.default_rng(seed)

    area = (
        max(float(np.max(x) - np.min(x)), 1.0)
        * max(float(np.max(y) - np.min(y)), 1.0)
    )
    cell = max(
        250.0,
        math.sqrt(area / max(target_n, 1)),
    )

    ix = np.floor(x / cell).astype(np.int64)
    iy = np.floor(y / cell).astype(np.int64)

    key = np.rec.fromarrays([ix, iy])
    _, first = np.unique(key, return_index=True)
    sample = first.astype(np.int64)

    if len(sample) > target_n:
        sample = np.sort(
            rng.choice(
                sample,
                size=target_n,
                replace=False,
            )
        )
    elif len(sample) < target_n:
        rest = np.setdiff1d(
            np.arange(n, dtype=np.int64),
            sample,
            assume_unique=False,
        )
        add_n = min(target_n - len(sample), len(rest))
        if add_n > 0:
            add = rng.choice(
                rest,
                size=add_n,
                replace=False,
            )
            sample = np.sort(
                np.concatenate([sample, add])
            )

    return sample


def fit_robust_ramp(
    phase_ts: np.ndarray,
    x: np.ndarray,
    y: np.ndarray,
    huber_k: float,
    iterations: int,
):
    """Epoch-wise robust linear ramp: a + b*x100km + c*y100km."""
    phase_ts = np.asarray(phase_ts, dtype=np.float64)
    xn = np.asarray(x, dtype=np.float64) / 100000.0
    yn = np.asarray(y, dtype=np.float64) / 100000.0

    G = np.column_stack([
        np.ones(len(xn)),
        xn,
        yn,
    ])

    n_epoch = phase_ts.shape[1]
    coef = np.full((3, n_epoch), np.nan, dtype=np.float64)
    r2 = np.full(n_epoch, np.nan, dtype=np.float64)
    n_used = np.zeros(n_epoch, dtype=int)

    for j in range(n_epoch):
        z = phase_ts[:, j]
        good = np.isfinite(z)

        if np.count_nonzero(good) < 100:
            continue

        Gj = G[good]
        zj = z[good]

        beta, *_ = np.linalg.lstsq(Gj, zj, rcond=None)

        w = np.ones(len(zj), dtype=np.float64)

        for _ in range(max(0, iterations)):
            r = zj - Gj @ beta
            med = np.median(r)
            mad = 1.4826 * np.median(np.abs(r - med))

            if not np.isfinite(mad) or mad <= 1e-8:
                break

            u = np.abs(r - med) / (huber_k * mad)
            w = np.ones_like(u)
            mask = u > 1.0
            w[mask] = 1.0 / u[mask]

            sw = np.sqrt(w)
            beta, *_ = np.linalg.lstsq(
                Gj * sw[:, None],
                zj * sw,
                rcond=None,
            )

        pred = Gj @ beta
        resid = zj - pred

        ss_res = float(np.sum(resid ** 2))
        ss_tot = float(
            np.sum(
                (zj - np.mean(zj)) ** 2
            )
        )

        coef[:, j] = beta
        r2[j] = (
            1.0 - ss_res / ss_tot
            if ss_tot > 0 else np.nan
        )
        n_used[j] = len(zj)

    return coef, r2, n_used


def ramp_values(
    x: np.ndarray,
    y: np.ndarray,
    coef: np.ndarray,
):
    G = np.column_stack([
        np.ones(len(x)),
        np.asarray(x, dtype=np.float64) / 100000.0,
        np.asarray(y, dtype=np.float64) / 100000.0,
    ])
    return G @ coef


def slope_coefficients(
    dates_dt: Sequence[dt.datetime],
    year: Optional[int],
):
    n = len(dates_dt)
    c = np.zeros(n, dtype=np.float64)

    if year is None:
        idx = np.arange(n, dtype=int)
    else:
        idx = np.asarray(
            [
                i
                for i, d in enumerate(dates_dt)
                if d.year == year
            ],
            dtype=int,
        )

    if len(idx) < 3:
        return c, idx

    local = [dates_dt[i] for i in idx]
    t0 = local[0]
    t = np.asarray(
        [
            (d - t0).total_seconds()
            / 86400.0
            / 365.2425
            for d in local
        ],
        dtype=np.float64,
    )
    tc = t - np.mean(t)
    den = float(np.sum(tc ** 2))

    if den > 0:
        c[idx] = tc / den

    return c, idx


# =============================================================================
# truth / validation
# =============================================================================

def choose_vfield(gdf, preferred: str):
    geom = gdf.geometry.name
    cols = [c for c in gdf.columns if c != geom]

    for c in cols:
        if c.lower() == preferred.lower():
            return c

    numeric = [
        c
        for c in cols
        if np.issubdtype(gdf[c].dtype, np.number)
    ]

    for p in ("v", "vel", "velocity", "rate"):
        for c in numeric:
            if norm_key(c) == p:
                return c

    raise RuntimeError(
        f"Cannot identify truth field; columns={cols}"
    )


def read_truth_cropped(
    path: Path,
    preferred_field: str,
    scale: float,
    lon0: float,
    lat0: float,
    ps_bbox: Tuple[float, float, float, float],
    buffer_m: float,
):
    import geopandas as gpd

    gdf = gpd.read_file(path)

    if gdf.crs is not None:
        gdf = gdf.to_crs(4326)

    if not np.all(gdf.geometry.geom_type == "Point"):
        raise RuntimeError(f"{path.name} is not Point geometry")

    vf = choose_vfield(gdf, preferred_field)

    lon = np.asarray(gdf.geometry.x, dtype=float)
    lat = np.asarray(gdf.geometry.y, dtype=float)
    v = (
        np.asarray(gdf[vf], dtype=float)
        * scale
    )

    good = (
        np.isfinite(lon)
        & np.isfinite(lat)
        & np.isfinite(v)
    )
    lon, lat, v = lon[good], lat[good], v[good]

    x, y, _, _ = local_xy(
        lon,
        lat,
        lon0,
        lat0,
    )

    xmin, xmax, ymin, ymax = ps_bbox

    inside = (
        (x >= xmin - buffer_m)
        & (x <= xmax + buffer_m)
        & (y >= ymin - buffer_m)
        & (y <= ymax + buffer_m)
    )

    del gdf
    gc.collect()

    return (
        lon[inside],
        lat[inside],
        x[inside],
        y[inside],
        v[inside],
        vf,
    )


def unique_ps_truth_mapping(
    ps_xy: np.ndarray,
    truth_xy: np.ndarray,
    match_m: float,
):
    tree = cKDTree(truth_xy)

    dist, tidx = tree.query(
        ps_xy,
        k=1,
        workers=-1,
    )

    dist = np.asarray(dist, dtype=float)
    tidx = np.asarray(tidx, dtype=np.int64)

    within = np.isfinite(dist) & (dist <= match_m)

    p = np.flatnonzero(within)
    d = dist[within]
    t = tidx[within]

    order = np.argsort(d)
    t_order = t[order]

    _, first = np.unique(
        t_order,
        return_index=True,
    )

    keep = np.sort(order[first])

    return (
        p[keep],
        t[keep],
        d[keep],
    )


def validation_metrics(pred, truth):
    good = np.isfinite(pred) & np.isfinite(truth)

    p = np.asarray(pred[good], dtype=float)
    t = np.asarray(truth[good], dtype=float)

    if len(p) < 3:
        return None

    e = p - t

    if np.std(p) > 0 and np.std(t) > 0:
        cc = float(np.corrcoef(p, t)[0, 1])
    else:
        cc = np.nan

    G = np.column_stack([
        np.ones_like(t),
        t,
    ])

    beta, *_ = np.linalg.lstsq(
        G,
        p,
        rcond=None,
    )

    return {
        "n": int(len(e)),
        "rmse_mm_yr": float(
            np.sqrt(np.mean(e ** 2))
        ),
        "mae_mm_yr": float(
            np.mean(np.abs(e))
        ),
        "mean_bias_mm_yr": float(np.mean(e)),
        "median_bias_mm_yr": float(np.median(e)),
        "p95_abs_error_mm_yr": float(
            np.percentile(np.abs(e), 95)
        ),
        "correlation": cc,
        "regression_intercept_mm_yr": float(beta[0]),
        "regression_pred_vs_truth_slope": float(beta[1]),
        "pred_std_mm_yr": float(np.std(p)),
        "truth_std_mm_yr": float(np.std(t)),
        "pred_std_over_truth_std": (
            float(np.std(p) / np.std(t))
            if np.std(t) > 0
            else np.nan
        ),
    }


def grid_median(x, y, v, size):
    valid = (
        np.isfinite(x)
        & np.isfinite(y)
        & np.isfinite(v)
    )

    x = np.asarray(x[valid], dtype=float)
    y = np.asarray(y[valid], dtype=float)
    v = np.asarray(v[valid], dtype=float)

    ix = np.floor(x / size).astype(np.int64)
    iy = np.floor(y / size).astype(np.int64)

    if len(ix) == 0:
        return (
            np.empty((0, 2), dtype=np.int64),
            np.empty(0, dtype=float),
        )

    ix0 = int(ix.min())
    iy0 = int(iy.min())

    sx = ix - ix0
    sy = iy - iy0

    ny = int(sy.max()) + 1
    key = sx * ny + sy
    order = np.argsort(key)

    key_s = key[order]
    v_s = v[order]

    ukey, starts, counts = np.unique(
        key_s,
        return_index=True,
        return_counts=True,
    )

    med = np.empty(len(ukey), dtype=float)

    for i, (s, c) in enumerate(zip(starts, counts)):
        med[i] = np.median(v_s[s:s+c])

    ux = ukey // ny + ix0
    uy = ukey % ny + iy0

    return (
        np.column_stack([ux, uy]),
        med,
    )


def intersect_cells(a, b):
    dtype = np.dtype([
        ("x", np.int64),
        ("y", np.int64),
    ])

    ak = np.ascontiguousarray(a).view(dtype).reshape(-1)
    bk = np.ascontiguousarray(b).view(dtype).reshape(-1)

    _, ia, ib = np.intersect1d(
        ak,
        bk,
        assume_unique=True,
        return_indices=True,
    )

    return ia, ib


# =============================================================================
# raster output
# =============================================================================

def raster_assignment(lon, lat, template_path: Path):
    import rasterio

    with rasterio.open(template_path) as src:
        profile = src.profile.copy()
        transform = src.transform
        crs = src.crs
        width, height = src.width, src.height

    if crs is None:
        raise RuntimeError(
            f"Raster template lacks CRS: {template_path}"
        )

    if crs.to_epsg() == 4326:
        xs, ys = lon.astype(float), lat.astype(float)
    else:
        from pyproj import Transformer
        tr = Transformer.from_crs(
            "EPSG:4326",
            crs,
            always_xy=True,
        )
        xs, ys = tr.transform(
            lon.astype(float),
            lat.astype(float),
        )
        xs, ys = np.asarray(xs), np.asarray(ys)

    inv = ~transform
    cols_f, rows_f = inv * (xs, ys)

    cols = np.floor(cols_f).astype(np.int64)
    rows = np.floor(rows_f).astype(np.int64)

    inside = (
        np.isfinite(xs)
        & np.isfinite(ys)
        & (rows >= 0)
        & (rows < height)
        & (cols >= 0)
        & (cols < width)
    )

    psidx = np.flatnonzero(inside)
    flat = (
        rows[inside] * width
        + cols[inside]
    ).astype(np.int64)

    return (
        psidx,
        flat,
        profile,
        width,
        height,
    )


def write_ps_median_tif(
    path,
    values,
    psidx,
    flat,
    profile,
    width,
    height,
    tags,
):
    import pandas as pd
    import rasterio

    vals = np.asarray(values, dtype=float)[psidx]
    good = np.isfinite(vals)

    df = pd.DataFrame({
        "cell": flat[good],
        "value": vals[good],
    })

    med = df.groupby(
        "cell",
        sort=False,
    )["value"].median()

    nodata = np.float32(-9999.0)

    arr = np.full(
        height * width,
        nodata,
        dtype=np.float32,
    )

    arr[
        med.index.to_numpy(dtype=np.int64)
    ] = med.to_numpy(dtype=np.float32)

    arr = arr.reshape(height, width)

    out_profile = profile.copy()
    out_profile.update(
        count=1,
        dtype="float32",
        nodata=float(nodata),
        compress="deflate",
        predictor=3,
    )

    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with rasterio.open(
        path,
        "w",
        **out_profile,
    ) as dst:
        dst.write(arr, 1)
        dst.set_band_description(
            1,
            "velocity_mm_per_year",
        )
        dst.update_tags(**tags)


# =============================================================================
# CLI
# =============================================================================

def parse_args():
    p = argparse.ArgumentParser(
        description=(
            "FULL-network per-PS/per-IFG coherence/variance WLS "
            "+ self-consistent ramp + truth validation"
        )
    )

    p.add_argument(
        "--dataset",
        default="/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized",
    )
    p.add_argument(
        "--project",
        default="/mnt/vol-gdc28n1r/insar/cangzhou_P69",
    )
    p.add_argument("--out", default="")
    p.add_argument("--truth-dir", default="")
    p.add_argument("--truth-field", default="v")
    p.add_argument("--truth-scale", type=float, default=1.0)

    p.add_argument(
        "--unwrapped-file",
        default="phuw2_gacos.mat",
    )
    p.add_argument(
        "--unwrapped-var",
        default="ph_uw",
    )

    p.add_argument(
        "--diff-dir",
        default="DIFF",
    )
    p.add_argument(
        "--cc-height",
        type=int,
        default=5521,
    )
    p.add_argument(
        "--cc-width",
        type=int,
        default=5930,
    )
    p.add_argument(
        "--cc-endian",
        default=">f4",
        choices=[">f4", "<f4"],
    )
    p.add_argument(
        "--ij-row-col",
        type=int,
        default=1,
    )
    p.add_argument(
        "--ij-col-col",
        type=int,
        default=2,
    )
    p.add_argument(
        "--ij-index-base",
        type=int,
        default=1,
        choices=[0, 1],
    )

    p.add_argument(
        "--coherence-cache-dir",
        default="",
    )
    p.add_argument(
        "--coherence-cache-workers",
        type=int,
        default=2,
    )

    p.add_argument(
        "--modes",
        default="UNIFORM,COH,VAR,VAR_STD",
    )
    p.add_argument(
        "--gamma-floor",
        type=float,
        default=0.05,
    )
    p.add_argument(
        "--gamma-cap",
        type=float,
        default=0.999,
    )
    p.add_argument(
        "--weight-floor",
        type=float,
        default=0.02,
    )
    p.add_argument(
        "--weight-cap",
        type=float,
        default=50.0,
    )
    p.add_argument(
        "--ifg-std-factor-min",
        type=float,
        default=0.25,
    )
    p.add_argument(
        "--ifg-std-factor-max",
        type=float,
        default=4.0,
    )

    p.add_argument(
        "--block-ps",
        type=int,
        default=2500,
    )
    p.add_argument(
        "--max-bandwidth",
        type=int,
        default=32,
    )
    p.add_argument(
        "--ridge-rel",
        type=float,
        default=1e-8,
    )

    p.add_argument(
        "--ramp-sample",
        type=int,
        default=40000,
    )
    p.add_argument(
        "--ramp-huber-k",
        type=float,
        default=1.5,
    )
    p.add_argument(
        "--ramp-irls-iterations",
        type=int,
        default=3,
    )

    p.add_argument(
        "--reference-lon",
        type=float,
        default=117.21775055,
    )
    p.add_argument(
        "--reference-lat",
        type=float,
        default=38.40310669,
    )
    p.add_argument(
        "--reference-radius-m",
        type=float,
        default=500.0,
    )

    p.add_argument(
        "--legacy-correction-diagnostic",
        action=argparse.BooleanOptionalAction,
        default=True,
    )

    p.add_argument(
        "--match-m",
        type=float,
        default=200.0,
    )
    p.add_argument(
        "--truth-buffer-m",
        type=float,
        default=1500.0,
    )
    p.add_argument(
        "--grid-sizes-m",
        default="500,1000",
    )

    p.add_argument(
        "--min-improvement-to-write-product",
        type=float,
        default=0.02,
    )
    p.add_argument(
        "--always-write-product",
        action="store_true",
    )
    p.add_argument(
        "--raster-template",
        default="postprocess/rasters/geo_velocity.tif",
    )
    p.add_argument(
        "--no-write-tifs",
        action="store_true",
    )
    p.add_argument(
        "--seed",
        type=int,
        default=20260811,
    )
    p.add_argument(
        "--self-test",
        action="store_true",
    )

    return p.parse_args()


# =============================================================================
# self-test
# =============================================================================

def self_test():
    rng = np.random.default_rng(7)

    n_image = 12
    edges = []

    for i in range(n_image):
        for dd in (1, 2, 3):
            if i + dd < n_image:
                edges.append((i, i + dd))

    edges = np.asarray(edges, dtype=int)

    B, spans = build_interval_design(
        edges,
        n_image,
    )

    contributors, bw = (
        build_band_contributor_matrices(
            edges,
            n_image,
            max_bandwidth=10,
        )
    )

    batch = 8
    d_true = rng.normal(
        size=(batch, n_image - 1)
    )

    Y = (B @ d_true.T).T

    gamma = rng.uniform(
        0.15,
        0.95,
        size=Y.shape,
    )

    std_factor = np.ones(
        len(edges),
        dtype=float,
    )

    W = weighted_mode_weights(
        "VAR",
        gamma,
        std_factor,
        gamma_floor=0.05,
        gamma_cap=0.999,
        weight_floor=0.02,
        weight_cap=50.0,
    )

    Ab, rhs = weighted_normal_band_and_rhs(
        W,
        Y,
        B,
        contributors,
        bw,
        ridge_rel=1e-10,
    )

    d, bad = solve_spd_banded_batch(
        Ab,
        rhs,
    )

    assert not np.any(bad)
    assert np.max(np.abs(d - d_true)) < 1e-6

    # Compare against dense WLS.
    Bd = B.toarray()

    for i in range(batch):
        N = Bd.T @ (W[i, :, None] * Bd)
        g = Bd.T @ (W[i] * Y[i])
        dense = np.linalg.solve(N, g)
        assert np.max(np.abs(dense - d[i])) < 1e-6

    # Ramp self-consistency test.
    x = rng.uniform(-50000, 50000, 1000)
    y = rng.uniform(-40000, 40000, 1000)
    coef_true = np.array([
        [1.0, 2.0],
        [0.4, -0.2],
        [-0.3, 0.5],
    ])
    z = ramp_values(x, y, coef_true)
    coef, r2, _ = fit_robust_ramp(
        z,
        x,
        y,
        huber_k=1.5,
        iterations=2,
    )
    assert np.max(np.abs(coef - coef_true)) < 1e-8
    assert np.nanmin(r2) > 0.999999

    print("SELF-TEST: PASS")


# =============================================================================
# main processing
# =============================================================================

def main():
    args = parse_args()

    if args.self_test:
        self_test()
        return

    t0 = time.time()

    dataset = Path(args.dataset).resolve()
    project = Path(args.project).resolve()
    truth_dir = (
        Path(args.truth_dir).resolve()
        if args.truth_dir
        else dataset / "cangzhou"
    )

    stamp = dt.datetime.now().strftime(
        "%Y%m%d_%H%M%S"
    )

    out = (
        Path(args.out).resolve()
        if args.out
        else (
            dataset
            / "_audit"
            / f"pixel_wls_sbas_v3_{stamp}"
        )
    )

    out.mkdir(
        parents=True,
        exist_ok=True,
    )

    print("=" * 80)
    print("V3 FULL-network pixel-wise WLS")
    print("=" * 80)
    print("dataset:", dataset)
    print("project:", project)
    print("output :", out)
    print()

    required = [
        dataset / "ps2.mat",
        dataset / "phuw_sm2.mat",
        dataset / args.unwrapped_file,
        dataset / "ifgstd2.mat",
    ]

    for p in required:
        if not p.exists():
            raise FileNotFoundError(p)

    n_ps, n_image, lon, lat, ij = (
        load_ps_metadata(dataset)
    )

    (
        edges,
        dates,
        dates_dt,
        day,
        ifg_mode,
    ) = load_network(
        dataset,
        n_image,
    )

    n_ifg = len(edges)

    x, y, lon0, lat0 = local_xy(
        lon,
        lat,
    )

    ps_xy = np.column_stack([x, y])

    ps_bbox = (
        float(np.min(x)),
        float(np.max(x)),
        float(np.min(y)),
        float(np.max(y)),
    )

    wavelength, wavelength_source = (
        find_wavelength(project)
    )

    phase_to_mm = (
        -wavelength
        / (4 * np.pi)
        * 1000.0
    )

    print(
        f"n_ps={n_ps}, "
        f"n_image={n_image}, "
        f"n_ifg={n_ifg}"
    )
    print(
        f"dates={dates[0]}..{dates[-1]}"
    )
    print(
        f"phase_to_mm={phase_to_mm:.9f}"
    )
    print(
        f"ifgday_ix={ifg_mode}"
    )

    # ------------------------------------------------------------------
    # Full network only.
    # ------------------------------------------------------------------
    B, spans = build_interval_design(
        edges,
        n_image,
    )

    contributors, bw = (
        build_band_contributor_matrices(
            edges,
            n_image,
            args.max_bandwidth,
        )
    )

    print(
        f"temporal-index IFG span: "
        f"min={int(np.min(spans))}, "
        f"median={float(np.median(spans)):.1f}, "
        f"max={int(np.max(spans))}, "
        f"normal half-bandwidth={bw}"
    )

    rank_B = int(
        np.linalg.matrix_rank(
            B.toarray()
        )
    )

    if rank_B != n_image - 1:
        raise RuntimeError(
            f"Full network rank={rank_B}; "
            f"expected={n_image-1}"
        )

    # ------------------------------------------------------------------
    # Coherence files / exact production grid.
    # ------------------------------------------------------------------
    diff_dir = (
        Path(args.diff_dir).resolve()
        if Path(args.diff_dir).is_absolute()
        else project / args.diff_dir
    )

    if not diff_dir.is_dir():
        raise FileNotFoundError(diff_dir)

    cc_files = []

    for a, b in edges:
        cc_files.append(
            find_cc_file(
                diff_dir,
                dates[int(a)],
                dates[int(b)],
            )
        )

    cc_physical_fraction = validate_cc_layout(
        cc_files,
        args.cc_height,
        args.cc_width,
        args.cc_endian,
    )

    flat, inside_fraction = (
        map_ps_flat_indices(
            ij,
            args.cc_height,
            args.cc_width,
            args.ij_row_col,
            args.ij_col_col,
            args.ij_index_base,
        )
    )

    print()
    print("GAMMA coherence mapping:")
    print(
        f"  grid={args.cc_height}x{args.cc_width}"
    )
    print(
        f"  dtype={args.cc_endian}"
    )
    print(
        f"  PS inside fraction={inside_fraction:.6f}"
    )
    print(
        f"  byte-order physical fraction={cc_physical_fraction:.6f}"
    )
    print(
        f"  mapped IFGs={len(cc_files)}/{n_ifg}"
    )

    cache_dir = (
        Path(args.coherence_cache_dir).resolve()
        if args.coherence_cache_dir
        else (
            dataset
            / "_pixel_wls_cache_v3"
        )
    )

    coh_cache, coh_cache_meta = (
        build_or_reuse_coherence_cache(
            cache_dir,
            cc_files,
            flat,
            n_ps,
            n_ifg,
            args.cc_height,
            args.cc_width,
            args.cc_endian,
            args.coherence_cache_workers,
        )
    )

    # ------------------------------------------------------------------
    # IFG std global factor.
    # ------------------------------------------------------------------
    obj = loadmat(
        dataset / "ifgstd2.mat",
        variable_names=["ifg_std"],
        squeeze_me=True,
        struct_as_record=False,
    )

    ifg_std = np.asarray(
        obj["ifg_std"],
        dtype=float,
    ).reshape(-1)

    if len(ifg_std) != n_ifg:
        raise RuntimeError(
            f"ifg_std len={len(ifg_std)} "
            f"!= n_ifg={n_ifg}"
        )

    good_std = (
        np.isfinite(ifg_std)
        & (ifg_std > 0)
    )

    med_std = float(
        np.median(ifg_std[good_std])
    )

    ifg_std_filled = np.where(
        good_std,
        ifg_std,
        med_std,
    )

    ifg_std_factor = (
        med_std
        / ifg_std_filled
    ) ** 2

    ifg_std_factor = np.clip(
        ifg_std_factor,
        args.ifg_std_factor_min,
        args.ifg_std_factor_max,
    )

    # ------------------------------------------------------------------
    # Observation reader.
    # ------------------------------------------------------------------
    obs_reader = MatrixReader(
        dataset / args.unwrapped_file,
        args.unwrapped_var,
        n_ps,
        n_ifg,
    )

    # Uniform pseudoinverse in incremental design.
    B_dense = B.toarray()
    uniform_pinv = np.linalg.pinv(
        B_dense,
        rcond=1e-10,
    )

    # ------------------------------------------------------------------
    # Edge sign calibration versus phuw_sm2 acquisition phase.
    # ------------------------------------------------------------------
    print()
    print("Calibrating IFG observation sign ...")

    rng = np.random.default_rng(
        args.seed + 1
    )

    sign_idx = np.sort(
        rng.choice(
            n_ps,
            size=min(1500, n_ps),
            replace=False,
        )
    )

    Ysign = np.asarray(
        obs_reader.rows(sign_idx),
        dtype=np.float64,
    )

    dsign = Ysign @ uniform_pinv.T
    Xsign = increments_to_acquisition(
        dsign,
        n_image,
    )

    target = classic_load_var(
        dataset / "phuw_sm2.mat",
        "ph_uw",
    )

    if target.shape == (n_image, n_ps):
        target = target.T

    if target.shape != (n_ps, n_image):
        raise RuntimeError(
            f"phuw_sm2.ph_uw shape={target.shape}"
        )

    Tsign = np.asarray(
        target[sign_idx, :],
        dtype=np.float64,
    )

    sign_scores = {}

    for s in (+1.0, -1.0):
        D = Tsign - s * Xsign
        D -= np.nanmedian(
            D,
            axis=0,
            keepdims=True,
        )
        sign_scores[str(int(s))] = float(
            np.nanmedian(np.abs(D))
        )

    edge_sign = (
        +1.0
        if sign_scores["1"] <= sign_scores["-1"]
        else -1.0
    )

    print(
        "  plus score :",
        sign_scores["1"],
    )
    print(
        "  minus score:",
        sign_scores["-1"],
    )
    print(
        "  selected   :",
        edge_sign,
    )

    del target, Tsign, Ysign, Xsign, dsign
    gc.collect()

    # ------------------------------------------------------------------
    # Fixed exact reference PS.
    # ------------------------------------------------------------------
    ref_ids, ref_source = exact_reference_indices(
        dataset,
        n_ps,
    )

    print()
    print(
        f"Fixed reference: "
        f"{args.reference_lon:.8f},"
        f"{args.reference_lat:.8f}, "
        f"R={args.reference_radius_m:.0f}m, "
        f"PS={len(ref_ids)}"
    )
    print("  source:", ref_source)

    # ------------------------------------------------------------------
    # Truth and match mappings.
    # ------------------------------------------------------------------
    truth = {}

    refx, refy = lonlat_to_xy(
        args.reference_lon,
        args.reference_lat,
        lon0,
        lat0,
    )

    print()
    print("Preparing truth ...")

    for year in (2021, 2022, 2023):
        p = truth_dir / f"result{year}.shp"

        if not p.exists():
            raise FileNotFoundError(p)

        (
            tlon,
            tlat,
            tx,
            ty,
            tv_raw,
            vf,
        ) = read_truth_cropped(
            p,
            args.truth_field,
            args.truth_scale,
            lon0,
            lat0,
            ps_bbox,
            args.truth_buffer_m,
        )

        tree = cKDTree(
            np.column_stack([tx, ty])
        )

        ref_truth_ids = np.asarray(
            tree.query_ball_point(
                [refx, refy],
                r=args.reference_radius_m,
            ),
            dtype=np.int64,
        )

        if len(ref_truth_ids) < 10:
            raise RuntimeError(
                f"{year}: too few truth points in reference area"
            )

        truth_ref = float(
            np.median(tv_raw[ref_truth_ids])
        )

        tv = tv_raw - truth_ref

        pidx, tidx, dist = (
            unique_ps_truth_mapping(
                ps_xy,
                np.column_stack([tx, ty]),
                args.match_m,
            )
        )

        truth[year] = {
            "x": tx,
            "y": ty,
            "v": tv,
            "pidx": pidx,
            "tidx": tidx,
            "dist": dist,
            "truth_ref": truth_ref,
            "field": vf,
        }

        print(
            f"  {year}: truth={len(tv)}, "
            f"matched={len(pidx)}, "
            f"truth_ref={truth_ref:.4f}"
        )

    # ------------------------------------------------------------------
    # Current Final-C baseline.
    # ------------------------------------------------------------------
    final_candidates = sorted(
        [
            p
            for p in dataset.glob(
                "final_C_fixed_reference_*"
            )
            if (
                p
                / "velocity"
                / "final_C_velocity_points.npz"
            ).exists()
        ],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    if not final_candidates:
        raise RuntimeError(
            "Current Final-C baseline not found"
        )

    final_npz = (
        final_candidates[0]
        / "velocity"
        / "final_C_velocity_points.npz"
    )

    current_preds = {}
    baseline_year_rows = []
    pooled_p = []
    pooled_t = []

    with np.load(
        final_npz,
        allow_pickle=False,
    ) as z:
        for year in (2021, 2022, 2023):
            v = np.asarray(
                z[f"velocity_{year}_mm_yr"],
                dtype=float,
            )
            current_preds[year] = v

            td = truth[year]
            pred = v[td["pidx"]]
            tv = td["v"][td["tidx"]]

            mm = validation_metrics(
                pred,
                tv,
            )

            baseline_year_rows.append({
                "branch": "CURRENT_FINAL_C",
                "mode": "current_custom",
                "correction": "RAMP_SCN",
                "self_consistent_new_chain": 0,
                "year": year,
                **mm,
            })

            good = (
                np.isfinite(pred)
                & np.isfinite(tv)
            )
            pooled_p.append(pred[good])
            pooled_t.append(tv[good])

    current_pooled = {
        "branch": "CURRENT_FINAL_C",
        "mode": "current_custom",
        "correction": "RAMP_SCN",
        "self_consistent_new_chain": 0,
        **validation_metrics(
            np.concatenate(pooled_p),
            np.concatenate(pooled_t),
        ),
    }

    print()
    print(
        "Current Final-C pooled RMSE:",
        current_pooled["rmse_mm_yr"],
    )

    # ------------------------------------------------------------------
    # Optional legacy correction matrices for CONTROLLED DIAGNOSTIC ONLY.
    # ------------------------------------------------------------------
    legacy_ramp = None
    legacy_scn = None

    if args.legacy_correction_diagnostic:
        print()
        print(
            "Loading legacy ramp/SCN for diagnostic isolation only ..."
        )

        legacy_ramp = classic_load_var(
            dataset / "scla2.mat",
            "ph_ramp",
        )

        if legacy_ramp.shape == (n_image, n_ps):
            legacy_ramp = legacy_ramp.T

        legacy_scn = classic_load_var(
            dataset / "uw_space_time.mat",
            "ph_scn",
        )

        if legacy_scn.shape == (n_image, n_ps):
            legacy_scn = legacy_scn.T

        if (
            legacy_ramp.shape != (n_ps, n_image)
            or legacy_scn.shape != (n_ps, n_image)
        ):
            raise RuntimeError(
                "Legacy correction matrix shape mismatch"
            )

        legacy_ramp = np.asarray(
            legacy_ramp,
            dtype=np.float32,
        )
        legacy_scn = np.asarray(
            legacy_scn,
            dtype=np.float32,
        )

    # ------------------------------------------------------------------
    # Date slope coefficients.
    # ------------------------------------------------------------------
    years_all = sorted(
        set(d.year for d in dates_dt)
    )

    slope_coef = {
        "full": slope_coefficients(
            dates_dt,
            None,
        )[0]
    }

    for yy in years_all:
        slope_coef[str(yy)] = (
            slope_coefficients(
                dates_dt,
                yy,
            )[0]
        )

    grid_sizes = sorted({
        float(v)
        for v in args.grid_sizes_m.split(",")
        if v.strip()
    })

    # ------------------------------------------------------------------
    # Modes.
    # ------------------------------------------------------------------
    modes = [
        m.strip().upper()
        for m in args.modes.split(",")
        if m.strip()
    ]

    allowed = {
        "UNIFORM",
        "COH",
        "VAR",
        "VAR_STD",
    }

    if not modes or any(m not in allowed for m in modes):
        raise ValueError(
            f"modes must be subset of {sorted(allowed)}"
        )

    ramp_sample = spatially_balanced_sample(
        x,
        y,
        args.ramp_sample,
        args.seed + 2,
    )

    # Always include exact ref PS in ramp solve pool.
    sample_union = np.unique(
        np.concatenate([
            ramp_sample,
            ref_ids,
        ])
    )

    # Maps back from union to ramp/ref.
    union_pos = {
        int(v): i
        for i, v in enumerate(sample_union)
    }

    ramp_pos = np.asarray(
        [union_pos[int(v)] for v in ramp_sample],
        dtype=np.int64,
    )

    ref_pos = np.asarray(
        [union_pos[int(v)] for v in ref_ids],
        dtype=np.int64,
    )

    branch_year_rows = list(baseline_year_rows)
    branch_pooled_rows = [current_pooled]
    branch_grid_rows = []
    ramp_rows = []
    tc_summary_rows = []
    tc_quartile_rows = []

    velocity_store: Dict[
        str,
        Dict[str, Dict[int, np.ndarray]]
    ] = {}

    tc_store: Dict[str, np.ndarray] = {}

    ramp_model_store: Dict[str, Dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Process each weighting mode.
    # ------------------------------------------------------------------
    for mode in modes:
        mode_t0 = time.time()

        print()
        print("=" * 80)
        print("MODE:", mode)
        print("=" * 80)

        # --------------------------------------------------------------
        # A. Solve ramp/reference sample with this mode.
        # --------------------------------------------------------------
        Ysample = np.asarray(
            obs_reader.rows(sample_union),
            dtype=np.float64,
        )

        Csample = (
            None
            if mode == "UNIFORM"
            else np.asarray(
                coh_cache[sample_union, :],
                dtype=np.float32,
            )
        )

        d_sample, tc_s, tcw_s, bad_s = (
            solve_pixel_block(
                Ysample,
                Csample,
                mode,
                B,
                contributors,
                bw,
                ifg_std_factor,
                uniform_pinv,
                edge_sign,
                args,
            )
        )

        if np.any(bad_s):
            print(
                f"WARNING: {np.count_nonzero(bad_s)} "
                "sample WLS systems flagged numerically bad"
            )

        Xsample = increments_to_acquisition(
            d_sample,
            n_image,
        )

        Xref_raw = Xsample[ref_pos, :]
        ref_ts_raw = np.nanmedian(
            Xref_raw,
            axis=0,
        )

        Xramp_sample_rawref = (
            Xsample[ramp_pos, :]
            - ref_ts_raw[None, :]
        )

        ramp_coef, ramp_r2, ramp_n = (
            fit_robust_ramp(
                Xramp_sample_rawref,
                x[ramp_sample],
                y[ramp_sample],
                args.ramp_huber_k,
                args.ramp_irls_iterations,
            )
        )

        # Exact reference after self-ramp.
        plane_ref = ramp_values(
            x[ref_ids],
            y[ref_ids],
            ramp_coef,
        )

        Xref_rawref = (
            Xref_raw
            - ref_ts_raw[None, :]
        )

        self_ramp_ref_offset = (
            np.nanmedian(
                Xref_rawref - plane_ref,
                axis=0,
            )
        )

        # Exact legacy correction reference for diagnostic.
        legacy_ref_ts = None

        if args.legacy_correction_diagnostic:
            legacy_ref_ts = np.nanmedian(
                Xref_raw
                - np.asarray(
                    legacy_ramp[ref_ids, :],
                    dtype=np.float64,
                )
                - np.asarray(
                    legacy_scn[ref_ids, :],
                    dtype=np.float64,
                ),
                axis=0,
            )

        ramp_model_store[mode] = {
            "coef": ramp_coef,
            "ref_ts_raw": ref_ts_raw,
            "self_ramp_ref_offset": self_ramp_ref_offset,
            "legacy_ref_ts": legacy_ref_ts,
        }

        for j, d in enumerate(dates):
            ramp_rows.append({
                "mode": mode,
                "date": d,
                "intercept_rad": float(ramp_coef[0, j]),
                "x_rad_per_100km": float(ramp_coef[1, j]),
                "y_rad_per_100km": float(ramp_coef[2, j]),
                "r2": float(ramp_r2[j]),
                "n_fit": int(ramp_n[j]),
            })

        print(
            "Self-ramp R2 median/P05:",
            float(np.nanmedian(ramp_r2)),
            float(np.nanpercentile(ramp_r2, 5)),
        )

        del (
            Ysample,
            Csample,
            d_sample,
            Xsample,
            Xref_raw,
            Xramp_sample_rawref,
            plane_ref,
            Xref_rawref,
        )
        gc.collect()

        # --------------------------------------------------------------
        # B. Full PS pass.
        # --------------------------------------------------------------
        corrections = [
            "RAW_REF",
            "SELF_RAMP",
        ]

        if args.legacy_correction_diagnostic:
            corrections.append(
                "LEGACY_RAMP_SCN_DIAG"
            )

        velocity_store[mode] = {
            corr: {
                year: np.full(
                    n_ps,
                    np.nan,
                    dtype=np.float32,
                )
                for year in (2021, 2022, 2023)
            }
            for corr in corrections
        }

        tc_all = np.full(
            n_ps,
            np.nan,
            dtype=np.float32,
        )

        tcw_all = np.full(
            n_ps,
            np.nan,
            dtype=np.float32,
        )

        mean_coh_all = np.full(
            n_ps,
            np.nan,
            dtype=np.float32,
        )

        eff_coh_all = np.full(
            n_ps,
            np.nan,
            dtype=np.float32,
        )

        bad_total = 0

        model = ramp_model_store[mode]

        for r0 in range(
            0,
            n_ps,
            args.block_ps,
        ):
            r1 = min(
                n_ps,
                r0 + args.block_ps,
            )

            Y = np.asarray(
                obs_reader.block(r0, r1),
                dtype=np.float64,
            )

            C = np.asarray(
                coh_cache[r0:r1, :],
                dtype=np.float32,
            )

            d_block, tc, tcw, bad = (
                solve_pixel_block(
                    Y,
                    None if mode == "UNIFORM" else C,
                    mode,
                    B,
                    contributors,
                    bw,
                    ifg_std_factor,
                    uniform_pinv,
                    edge_sign,
                    args,
                )
            )

            Xraw = increments_to_acquisition(
                d_block,
                n_image,
            )

            tc_all[r0:r1] = tc.astype(
                np.float32
            )
            tcw_all[r0:r1] = tcw.astype(
                np.float32
            )
            mean_coh_all[r0:r1] = np.mean(
                C,
                axis=1,
            ).astype(np.float32)
            eff_coh_all[r0:r1] = np.mean(
                C >= 0.4,
                axis=1,
            ).astype(np.float32)

            bad_total += int(
                np.count_nonzero(bad)
            )

            # Raw exact reference.
            X_raw_ref = (
                Xraw
                - model["ref_ts_raw"][None, :]
            )

            # Self-consistent ramp and exact re-reference.
            plane = ramp_values(
                x[r0:r1],
                y[r0:r1],
                model["coef"],
            )

            X_self = (
                X_raw_ref
                - plane
                - model["self_ramp_ref_offset"][None, :]
            )

            X_legacy = None

            if args.legacy_correction_diagnostic:
                X_legacy = (
                    Xraw
                    - np.asarray(
                        legacy_ramp[r0:r1, :],
                        dtype=np.float64,
                    )
                    - np.asarray(
                        legacy_scn[r0:r1, :],
                        dtype=np.float64,
                    )
                    - model["legacy_ref_ts"][None, :]
                )

            for year in (2021, 2022, 2023):
                c = slope_coef[str(year)]

                velocity_store[
                    mode
                ]["RAW_REF"][year][r0:r1] = (
                    (X_raw_ref @ c)
                    * phase_to_mm
                ).astype(np.float32)

                velocity_store[
                    mode
                ]["SELF_RAMP"][year][r0:r1] = (
                    (X_self @ c)
                    * phase_to_mm
                ).astype(np.float32)

                if X_legacy is not None:
                    velocity_store[
                        mode
                    ]["LEGACY_RAMP_SCN_DIAG"][year][r0:r1] = (
                        (X_legacy @ c)
                        * phase_to_mm
                    ).astype(np.float32)

            if (
                r0 == 0
                or r1 == n_ps
                or r1 % 25000 < args.block_ps
            ):
                print(
                    f"  {mode}: PS {r1}/{n_ps}, "
                    f"bad_systems={bad_total}"
                )

            del (
                Y,
                C,
                d_block,
                Xraw,
                X_raw_ref,
                X_self,
                plane,
                X_legacy,
            )
            gc.collect()

        tc_store[mode] = tc_all

        tc_summary_rows.append({
            "mode": mode,
            "n_ps": n_ps,
            "bad_wls_systems": bad_total,
            "temporal_coherence_median": float(
                np.nanmedian(tc_all)
            ),
            "temporal_coherence_p10": float(
                np.nanpercentile(tc_all, 10)
            ),
            "temporal_coherence_p90": float(
                np.nanpercentile(tc_all, 90)
            ),
            "weighted_temporal_coherence_median": float(
                np.nanmedian(tcw_all)
            ),
            "mean_input_coherence_median": float(
                np.nanmedian(mean_coh_all)
            ),
            "effective_coh_ratio_ge_0p4_median": float(
                np.nanmedian(eff_coh_all)
            ),
        })

        # --------------------------------------------------------------
        # C. Truth validation.
        # --------------------------------------------------------------
        for corr in corrections:
            pooled_pred = []
            pooled_truth = []

            for year in (2021, 2022, 2023):
                td = truth[year]
                v = velocity_store[
                    mode
                ][corr][year]

                pred = v[td["pidx"]]
                tv = td["v"][td["tidx"]]

                mm = validation_metrics(
                    pred,
                    tv,
                )

                self_consistent = int(
                    corr in (
                        "RAW_REF",
                        "SELF_RAMP",
                    )
                )

                branch_name = (
                    f"{mode}_{corr}"
                )

                branch_year_rows.append({
                    "branch": branch_name,
                    "mode": mode,
                    "correction": corr,
                    "self_consistent_new_chain": self_consistent,
                    "year": year,
                    **mm,
                })

                good = (
                    np.isfinite(pred)
                    & np.isfinite(tv)
                )

                pooled_pred.append(pred[good])
                pooled_truth.append(tv[good])

                # Grid validation.
                px = x[td["pidx"]][good]
                py = y[td["pidx"]][good]
                tx = td["x"][td["tidx"]][good]
                ty = td["y"][td["tidx"]][good]

                for gs in grid_sizes:
                    pc, pv = grid_median(
                        px,
                        py,
                        pred[good],
                        gs,
                    )
                    tcells, tvm = grid_median(
                        tx,
                        ty,
                        tv[good],
                        gs,
                    )

                    ia, ib = intersect_cells(
                        pc,
                        tcells,
                    )

                    gm = validation_metrics(
                        pv[ia],
                        tvm[ib],
                    )

                    branch_grid_rows.append({
                        "branch": branch_name,
                        "mode": mode,
                        "correction": corr,
                        "self_consistent_new_chain": self_consistent,
                        "year": year,
                        "grid_m": gs,
                        **gm,
                    })

            pooled_mm = validation_metrics(
                np.concatenate(pooled_pred),
                np.concatenate(pooled_truth),
            )

            branch_pooled_rows.append({
                "branch": f"{mode}_{corr}",
                "mode": mode,
                "correction": corr,
                "self_consistent_new_chain": int(
                    corr in (
                        "RAW_REF",
                        "SELF_RAMP",
                    )
                ),
                **pooled_mm,
            })

            print(
                f"{mode}_{corr:24s} "
                f"pooled RMSE={pooled_mm['rmse_mm_yr']:.3f}, "
                f"corr={pooled_mm['correlation']:.3f}"
            )

        # --------------------------------------------------------------
        # D. Does temporal coherence predict truth error?
        # Use SELF_RAMP, because it is the principal self-consistent branch.
        # --------------------------------------------------------------
        for year in (2021, 2022, 2023):
            td = truth[year]
            pidx = td["pidx"]
            tidx = td["tidx"]

            v = velocity_store[
                mode
            ]["SELF_RAMP"][year][pidx]

            tv = td["v"][tidx]
            q = tc_all[pidx]

            good = (
                np.isfinite(v)
                & np.isfinite(tv)
                & np.isfinite(q)
            )

            if np.count_nonzero(good) < 100:
                continue

            vg = v[good]
            tg = tv[good]
            qg = q[good]

            edges_q = np.quantile(
                qg,
                [0, 0.25, 0.5, 0.75, 1.0],
            )

            for qi in range(4):
                if qi < 3:
                    mask = (
                        (qg >= edges_q[qi])
                        & (qg < edges_q[qi+1])
                    )
                else:
                    mask = (
                        (qg >= edges_q[qi])
                        & (qg <= edges_q[qi+1])
                    )

                mm = validation_metrics(
                    vg[mask],
                    tg[mask],
                )

                tc_quartile_rows.append({
                    "mode": mode,
                    "year": year,
                    "quartile": qi + 1,
                    "tc_min": float(edges_q[qi]),
                    "tc_max": float(edges_q[qi+1]),
                    **mm,
                })

        # Per-mode PS quality file.
        np.savez_compressed(
            out / f"quality_{mode}.npz",
            ps_index_1based=np.arange(
                1,
                n_ps + 1,
                dtype=np.int32,
            ),
            temporal_coherence=tc_all,
            weighted_temporal_coherence=tcw_all,
            mean_input_coherence=mean_coh_all,
            effective_coh_ratio_ge_0p4=eff_coh_all,
        )

        print(
            f"{mode} runtime: "
            f"{time.time() - mode_t0:.1f} s"
        )

        del (
            tcw_all,
            mean_coh_all,
            eff_coh_all,
        )
        gc.collect()

    # ------------------------------------------------------------------
    # Save validation.
    # ------------------------------------------------------------------
    write_csv(
        out / "01_branch_validation_by_year.csv",
        branch_year_rows,
    )

    write_csv(
        out / "02_branch_pooled_validation.csv",
        branch_pooled_rows,
    )

    write_csv(
        out / "03_branch_grid_validation.csv",
        branch_grid_rows,
    )

    write_csv(
        out / "04_self_ramp_epoch_models.csv",
        ramp_rows,
    )

    write_csv(
        out / "05_temporal_coherence_summary.csv",
        tc_summary_rows,
    )

    write_csv(
        out / "06_temporal_coherence_truth_quartiles.csv",
        tc_quartile_rows,
    )

    # ------------------------------------------------------------------
    # Decide the best SELF-CONSISTENT new branch.
    # Legacy correction diagnostic is excluded by construction.
    # ------------------------------------------------------------------
    self_rows = [
        r
        for r in branch_pooled_rows
        if (
            r["branch"] != "CURRENT_FINAL_C"
            and int(r["self_consistent_new_chain"]) == 1
        )
    ]

    best_self = min(
        self_rows,
        key=lambda r: r["rmse_mm_yr"],
    )

    diagnostic_rows = [
        r
        for r in branch_pooled_rows
        if (
            r["branch"] != "CURRENT_FINAL_C"
            and int(r["self_consistent_new_chain"]) == 0
        )
    ]

    best_diag = (
        min(
            diagnostic_rows,
            key=lambda r: r["rmse_mm_yr"],
        )
        if diagnostic_rows
        else None
    )

    improvement = (
        current_pooled["rmse_mm_yr"]
        - best_self["rmse_mm_yr"]
    ) / current_pooled["rmse_mm_yr"]

    if improvement >= args.min_improvement_to_write_product:
        classification = (
            "PIXEL_WLS_SELF_CONSISTENT_IMPROVEMENT_SUPPORTED"
        )
    elif (
        best_diag is not None
        and best_diag["rmse_mm_yr"]
        < current_pooled["rmse_mm_yr"]
    ):
        classification = (
            "PIXEL_WLS_PROMISING_ONLY_WITH_LEGACY_CORRECTION_DIAGNOSTIC"
        )
    else:
        classification = (
            "PIXEL_WLS_NOT_BETTER_THAN_CURRENT_FINAL_C"
        )

    decision = {
        "classification": classification,
        "current_final_C": current_pooled,
        "best_self_consistent_new_branch": best_self,
        "best_legacy_correction_diagnostic_branch": best_diag,
        "relative_rmse_improvement_best_self_vs_current_final_C": improvement,
        "product_write_threshold": args.min_improvement_to_write_product,
        "important":
            "Only RAW_REF and SELF_RAMP are eligible self-consistent V3 branches. "
            "LEGACY_RAMP_SCN_DIAG is a controlled isolation experiment and cannot "
            "be promoted automatically.",
    }

    (
        out / "07_DECISION.json"
    ).write_text(
        json.dumps(
            decision,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    print()
    print("=" * 80)
    print("V3 DECISION")
    print("=" * 80)
    print(
        "Current Final-C:",
        current_pooled["rmse_mm_yr"],
    )
    print(
        "Best self-consistent:",
        best_self["branch"],
        best_self["rmse_mm_yr"],
    )
    print(
        "Relative improvement:",
        f"{100 * improvement:.2f}%",
    )
    if best_diag is not None:
        print(
            "Best legacy correction diagnostic:",
            best_diag["branch"],
            best_diag["rmse_mm_yr"],
        )
    print(
        "Classification:",
        classification,
    )

    # ------------------------------------------------------------------
    # Optional winning self-consistent product.
    # ------------------------------------------------------------------
    write_product = (
        args.always_write_product
        or improvement >= args.min_improvement_to_write_product
    )

    product_dir = None

    if write_product:
        best_branch = best_self["branch"]
        best_mode = best_self["mode"]
        best_corr = best_self["correction"]

        print()
        print("=" * 80)
        print("Writing winning self-consistent V3 product")
        print("=" * 80)
        print(
            "branch:",
            best_branch,
        )

        product_dir = (
            out
            / "best_self_consistent_product"
        )
        product_dir.mkdir(
            parents=True,
            exist_ok=True,
        )

        model = ramp_model_store[best_mode]

        # All calendar/full rates.
        velocity_product = {
            label: np.full(
                n_ps,
                np.nan,
                dtype=np.float32,
            )
            for label in slope_coef
        }

        # Full HDF5 time series.
        import h5py

        h5_path = (
            product_dir
            / "pixel_wls_timeseries.h5"
        )

        with h5py.File(
            h5_path,
            "w",
        ) as h:
            h.attrs["branch"] = best_branch
            h.attrs["mode"] = best_mode
            h.attrs["correction"] = best_corr
            h.attrs["reference_lon"] = args.reference_lon
            h.attrs["reference_lat"] = args.reference_lat
            h.attrs["reference_radius_m"] = args.reference_radius_m
            h.attrs["reference_ps_count"] = len(ref_ids)
            h.attrs["phase_to_mm"] = phase_to_mm

            h.create_dataset(
                "lon",
                data=lon.astype(np.float64),
                compression="lzf",
            )
            h.create_dataset(
                "lat",
                data=lat.astype(np.float64),
                compression="lzf",
            )
            h.create_dataset(
                "date_yyyymmdd",
                data=np.asarray(
                    [int(d) for d in dates],
                    dtype=np.int32,
                ),
            )

            ds = h.create_dataset(
                "los_displacement_mm",
                shape=(n_ps, n_image),
                dtype="f4",
                chunks=(
                    min(args.block_ps, n_ps),
                    n_image,
                ),
                compression="lzf",
            )

            tc_ds = h.create_dataset(
                "temporal_coherence",
                shape=(n_ps,),
                dtype="f4",
                compression="lzf",
            )

            for r0 in range(
                0,
                n_ps,
                args.block_ps,
            ):
                r1 = min(
                    n_ps,
                    r0 + args.block_ps,
                )

                Y = np.asarray(
                    obs_reader.block(r0, r1),
                    dtype=np.float64,
                )

                C = np.asarray(
                    coh_cache[r0:r1, :],
                    dtype=np.float32,
                )

                d_block, tc, tcw, bad = (
                    solve_pixel_block(
                        Y,
                        None if best_mode == "UNIFORM" else C,
                        best_mode,
                        B,
                        contributors,
                        bw,
                        ifg_std_factor,
                        uniform_pinv,
                        edge_sign,
                        args,
                    )
                )

                Xraw = increments_to_acquisition(
                    d_block,
                    n_image,
                )

                X = (
                    Xraw
                    - model["ref_ts_raw"][None, :]
                )

                if best_corr == "SELF_RAMP":
                    plane = ramp_values(
                        x[r0:r1],
                        y[r0:r1],
                        model["coef"],
                    )
                    X = (
                        X
                        - plane
                        - model[
                            "self_ramp_ref_offset"
                        ][None, :]
                    )

                for label, c in slope_coef.items():
                    velocity_product[
                        label
                    ][r0:r1] = (
                        (X @ c)
                        * phase_to_mm
                    ).astype(np.float32)

                ds[r0:r1, :] = (
                    X * phase_to_mm
                ).astype(np.float32)

                tc_ds[r0:r1] = tc.astype(
                    np.float32
                )

                if (
                    r0 == 0
                    or r1 == n_ps
                    or r1 % 25000 < args.block_ps
                ):
                    print(
                        f"  product PS: {r1}/{n_ps}"
                    )

                del (
                    Y,
                    C,
                    d_block,
                    Xraw,
                    X,
                )
                gc.collect()

        payload = {
            "ps_index_1based": np.arange(
                1,
                n_ps + 1,
                dtype=np.int32,
            ),
            "lon": lon.astype(np.float64),
            "lat": lat.astype(np.float64),
            "full_velocity_mm_yr": velocity_product[
                "full"
            ],
        }

        for yy in years_all:
            payload[
                f"velocity_{yy}_mm_yr"
            ] = velocity_product[str(yy)]

        np.savez_compressed(
            product_dir
            / "pixel_wls_velocity_points.npz",
            **payload,
        )

        raster_template = Path(
            args.raster_template
        )

        if not raster_template.is_absolute():
            raster_template = (
                dataset
                / raster_template
            )

        if (
            not args.no_write_tifs
            and raster_template.exists()
        ):
            (
                psidx,
                flat_r,
                profile,
                width_r,
                height_r,
            ) = raster_assignment(
                lon,
                lat,
                raster_template,
            )

            tags = {
                "source_branch": best_branch,
                "units": "mm/year",
                "reference_lon": f"{args.reference_lon:.10f}",
                "reference_lat": f"{args.reference_lat:.10f}",
                "reference_radius_m": f"{args.reference_radius_m:.3f}",
                "rasterization": "median_of_PS_in_template_pixel",
            }

            write_ps_median_tif(
                product_dir
                / "full_period_velocity.tif",
                velocity_product["full"],
                psidx,
                flat_r,
                profile,
                width_r,
                height_r,
                {**tags, "period": "full"},
            )

            ann = (
                product_dir
                / "annual_velocity"
            )

            for yy in years_all:
                write_ps_median_tif(
                    ann
                    / f"annual_velocity_{yy}.tif",
                    velocity_product[str(yy)],
                    psidx,
                    flat_r,
                    profile,
                    width_r,
                    height_r,
                    {**tags, "period": str(yy)},
                )

    else:
        print()
        print(
            "Full product skipped: "
            "no eligible self-consistent V3 branch "
            "met the improvement threshold."
        )

    # ------------------------------------------------------------------
    # manifest
    # ------------------------------------------------------------------
    manifest = {
        "version": "pixel_wls_sbas_v3",
        "dataset": str(dataset),
        "project": str(project),
        "output": str(out),
        "n_ps": n_ps,
        "n_image": n_image,
        "n_ifg": n_ifg,
        "ifg_selection": "NONE_FULL_763_NETWORK",
        "network_rank": rank_B,
        "max_temporal_index_span": int(np.max(spans)),
        "normal_half_bandwidth": bw,
        "coherence": {
            "diff_dir": str(diff_dir),
            "grid": [
                args.cc_height,
                args.cc_width,
            ],
            "dtype": args.cc_endian,
            "ij_row_col": args.ij_row_col,
            "ij_col_col": args.ij_col_col,
            "ij_index_base": args.ij_index_base,
            "inside_fraction": inside_fraction,
            "cache_dir": str(cache_dir),
            "cache_meta": coh_cache_meta,
        },
        "weight_modes": modes,
        "weight_formula": {
            "COH": "w=gamma",
            "VAR":
                "w=gamma^2/(1-gamma^2), clipped; common looks factor omitted because it cancels in relative WLS",
            "VAR_STD":
                "VAR * (median(ifg_std)/ifg_std)^2",
        },
        "edge_sign": edge_sign,
        "edge_sign_scores": sign_scores,
        "phase_to_mm": phase_to_mm,
        "wavelength_m": wavelength,
        "wavelength_source": wavelength_source,
        "reference": {
            "lon": args.reference_lon,
            "lat": args.reference_lat,
            "radius_m": args.reference_radius_m,
            "ps_count": len(ref_ids),
            "source": ref_source,
        },
        "ramp": {
            "method":
                "mode-specific robust linear XY plane estimated from the new referenced acquisition time series",
            "sample_ps": len(ramp_sample),
            "huber_k": args.ramp_huber_k,
            "irls_iterations": args.ramp_irls_iterations,
        },
        "legacy_correction_diagnostic":
            args.legacy_correction_diagnostic,
        "decision": decision,
        "product_dir":
            str(product_dir)
            if product_dir is not None
            else None,
        "runtime_seconds":
            time.time() - t0,
    }

    (
        out / "MANIFEST.json"
    ).write_text(
        json.dumps(
            manifest,
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )

    readme = f"""
V3 FULL-network pixel-wise WLS completed
============================================================================

IFGs:
  {n_ifg} / {n_ifg} retained
  No IFG deletion is performed in V3.

Coherence:
  source = {diff_dir}/*.cc
  grid   = {args.cc_height} x {args.cc_width}
  dtype  = {args.cc_endian}
  PS->grid inside fraction = {inside_fraction:.6f}

Network:
  rank = {rank_B}/{n_image-1}
  max acquisition-index span = {int(np.max(spans))}
  normal half-bandwidth = {bw}

Current Final-C pooled RMSE:
  {current_pooled['rmse_mm_yr']:.6f} mm/yr

Best SELF-CONSISTENT V3 branch:
  {best_self['branch']}
  RMSE = {best_self['rmse_mm_yr']:.6f} mm/yr
  relative improvement = {100*improvement:.3f} %

Classification:
  {classification}

Important:
  LEGACY_RAMP_SCN_DIAG is diagnostic only. It applies correction fields estimated
  from the existing production chain and is not eligible for automatic promotion.

Key outputs:
  01_branch_validation_by_year.csv
  02_branch_pooled_validation.csv
  03_branch_grid_validation.csv
  04_self_ramp_epoch_models.csv
  05_temporal_coherence_summary.csv
  06_temporal_coherence_truth_quartiles.csv
  07_DECISION.json
  quality_<MODE>.npz
  MANIFEST.json

Reusable expensive coherence cache:
  {cache_dir}

Existing Final-C and Stage6/7/8 are untouched.
""".strip()

    (
        out / "READ_ME_FIRST.txt"
    ).write_text(
        readme + "\n",
        encoding="utf-8",
    )

    print()
    print("=" * 80)
    print("V3 COMPLETE")
    print("=" * 80)
    print(
        "runtime:",
        f"{time.time() - t0:.1f} s",
    )
    print("OUTPUT:", out)
    print()
    print("First inspect:")
    for p in [
        out / "02_branch_pooled_validation.csv",
        out / "03_branch_grid_validation.csv",
        out / "05_temporal_coherence_summary.csv",
        out / "06_temporal_coherence_truth_quartiles.csv",
        out / "07_DECISION.json",
        out / "MANIFEST.json",
    ]:
        print(" ", p)


if __name__ == "__main__":
    main()
