#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
V5: quality-guided robust local-plane denoising of Final-C annual velocity.

Goal
----
Reduce local/high-frequency annual-velocity noise while preserving the ORIGINAL
4:1 processing resolution and the original PS sampling.

This script DOES NOT:
- aggregate to 250/500/1000 m grids;
- resample the PS points;
- change the full-period velocity;
- modify the displacement time series;
- rerun Stage6/7/8;
- overwrite Final-C.

It operates only on annual Final-C velocity values at the SAME 375,051 PS.

Method
------
For each target PS i, fit a robust local plane to neighboring PS j:

    v_j = a_i + b_i * dx_ij + c_i * dy_ij + e_j

with:
    - Gaussian distance weight;
    - neighbor reliability weight from pm2.mat:coh_ps;
    - Huber IRLS residual downweighting.

The local prediction at the target is a_i.  The correction is applied adaptively:

    strength_i = lambda * (1 - q_i)^gamma

    v_final_i = v_raw_i + strength_i * (a_i - v_raw_i)

High-quality PS therefore retain most of their original value, while low-quality
PS borrow more support from nearby reliable PS.

The local PLANE, rather than a local mean, preserves first-order deformation
gradients and therefore is safer around broad subsidence bowls.

Reference-frame preservation
----------------------------
The script does NOT re-zero annual velocities.  It only removes the median FILTER
CORRECTION over the established 65 reference PS:

    delta <- delta - median(delta_ref)

so the filter itself introduces no new reference-region offset.

Parameter selection
-------------------
A compact parameter set is screened on a deterministic truth subset, then the best
few are evaluated on all matched 2021/2022/2023 truth points.

A leave-one-year-out (LOYO) diagnostic is reported:
    train 2021+2022 -> test 2023
    train 2021+2023 -> test 2022
    train 2022+2023 -> test 2021

The production parameter is chosen by fold-winner consensus, with deterministic
tie-breaking.  It is promoted only if the full validation passes guardrails.

Original 4:1 resolution
-----------------------
Output GeoTIFFs use the EXACT raster transform/shape/CRS of the existing Final-C
annual GeoTIFF template.  There is no coarse grid aggregation or resampling.

This is an annual-velocity post-processing experiment.  The original Final-C
time series and full-period velocity remain authoritative and untouched.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import gc
import hashlib
import json
import math
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
from scipy.io import loadmat
from scipy.spatial import cKDTree


# =============================================================================
# utilities
# =============================================================================

def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    for row in rows:
        for k in row:
            if k not in fields:
                fields.append(k)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def local_xy(lon, lat, lon0=None, lat0=None):
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    if lon0 is None:
        lon0 = float(np.nanmedian(lon))
    if lat0 is None:
        lat0 = float(np.nanmedian(lat))
    R = 6371008.8
    x = np.deg2rad(lon - lon0) * R * math.cos(math.radians(lat0))
    y = np.deg2rad(lat - lat0) * R
    return x, y, float(lon0), float(lat0)


def lonlat_to_xy(lon, lat, lon0, lat0):
    R = 6371008.8
    x = math.radians(lon - lon0) * R * math.cos(math.radians(lat0))
    y = math.radians(lat - lat0) * R
    return x, y


def sha256_array_sample(a: np.ndarray) -> str:
    a = np.asarray(a)
    h = hashlib.sha256()
    h.update(str(a.shape).encode())
    if a.size:
        idx = np.linspace(0, a.size - 1, min(10000, a.size), dtype=np.int64)
        h.update(np.asarray(a.reshape(-1)[idx]).tobytes())
    return h.hexdigest()


def validation_metrics(pred, truth):
    good = np.isfinite(pred) & np.isfinite(truth)
    p = np.asarray(pred[good], dtype=float)
    t = np.asarray(truth[good], dtype=float)
    if len(p) < 3:
        return None
    e = p - t
    corr = (
        float(np.corrcoef(p, t)[0, 1])
        if np.std(p) > 0 and np.std(t) > 0
        else np.nan
    )
    G = np.column_stack([np.ones_like(t), t])
    beta, *_ = np.linalg.lstsq(G, p, rcond=None)
    return {
        "n": int(len(e)),
        "rmse_mm_yr": float(np.sqrt(np.mean(e ** 2))),
        "mae_mm_yr": float(np.mean(np.abs(e))),
        "mean_bias_mm_yr": float(np.mean(e)),
        "median_bias_mm_yr": float(np.median(e)),
        "p95_abs_error_mm_yr": float(np.percentile(np.abs(e), 95)),
        "correlation": corr,
        "regression_intercept_mm_yr": float(beta[0]),
        "regression_pred_vs_truth_slope": float(beta[1]),
        "pred_std_mm_yr": float(np.std(p)),
        "truth_std_mm_yr": float(np.std(t)),
        "pred_std_over_truth_std": (
            float(np.std(p) / np.std(t))
            if np.std(t) > 0 else np.nan
        ),
    }


def fit_global_plane(values, x, y):
    good = (
        np.isfinite(values)
        & np.isfinite(x)
        & np.isfinite(y)
    )
    if np.count_nonzero(good) < 100:
        return np.array([np.nan, np.nan, np.nan])
    G = np.column_stack([
        np.ones(np.count_nonzero(good)),
        x[good] / 100000.0,
        y[good] / 100000.0,
    ])
    beta, *_ = np.linalg.lstsq(G, values[good], rcond=None)
    return beta


# =============================================================================
# load Final-C / quality / reference
# =============================================================================

def find_latest_final_c(dataset: Path) -> Path:
    candidates = sorted(
        [
            p for p in dataset.glob("final_C_fixed_reference_*")
            if (p / "velocity" / "final_C_velocity_points.npz").exists()
        ],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise FileNotFoundError("No final_C_fixed_reference_* velocity product found")
    return candidates[0]


def load_final_c(final_dir: Path):
    p = final_dir / "velocity" / "final_C_velocity_points.npz"
    with np.load(p, allow_pickle=False) as z:
        files = set(z.files)
        lon = np.asarray(z["lon"], dtype=np.float64)
        lat = np.asarray(z["lat"], dtype=np.float64)
        full = np.asarray(z["full_velocity_mm_yr"], dtype=np.float32)
        annual = {}
        for name in z.files:
            m = re.fullmatch(r"velocity_(\d{4})_mm_yr", name)
            if m:
                annual[int(m.group(1))] = np.asarray(z[name], dtype=np.float32)
    if not annual:
        raise RuntimeError(f"No annual velocity arrays in {p}")
    return lon, lat, full, annual, p


def load_coh_ps(dataset: Path, n_ps: int):
    path = dataset / "pm2.mat"
    if not path.exists():
        raise FileNotFoundError(path)
    obj = loadmat(
        path,
        variable_names=["coh_ps"],
        squeeze_me=True,
        struct_as_record=False,
    )
    if "coh_ps" not in obj:
        raise KeyError(f"{path}:coh_ps not found")
    q = np.asarray(obj["coh_ps"], dtype=float).reshape(-1)
    if len(q) != n_ps:
        raise ValueError(f"coh_ps length={len(q)} != n_ps={n_ps}")
    return q, str(path)


def normalize_quality(q: np.ndarray):
    q = np.asarray(q, dtype=float)
    good = np.isfinite(q)
    if np.count_nonzero(good) < 100:
        raise RuntimeError("Too few finite quality values")
    p05, p95 = np.percentile(q[good], [5, 95])
    if p95 <= p05:
        raise RuntimeError("Degenerate quality distribution")
    out = np.zeros_like(q, dtype=np.float32)
    out[good] = np.clip(
        (q[good] - p05) / (p95 - p05),
        0.0,
        1.0,
    ).astype(np.float32)
    out[~good] = 0.0
    return out, {
        "raw_p05": float(p05),
        "raw_p50": float(np.median(q[good])),
        "raw_p95": float(p95),
        "normalized_p50": float(np.median(out[good])),
    }


def exact_reference_indices(final_dir: Path, n_ps: int):
    p = final_dir / "reference" / "reference_ps_indices_1based.txt"
    if not p.exists():
        raise FileNotFoundError(p)
    ids = np.asarray(np.loadtxt(p, dtype=np.int64), dtype=np.int64).reshape(-1) - 1
    ids = np.unique(ids)
    if len(ids) < 10 or np.any(ids < 0) or np.any(ids >= n_ps):
        raise RuntimeError(f"Invalid reference PS list: {p}")
    return ids, str(p)


# =============================================================================
# KNN cache
# =============================================================================

def build_or_reuse_knn_cache(
    cache_dir: Path,
    x: np.ndarray,
    y: np.ndarray,
    max_k: int,
    query_chunk: int,
):
    cache_dir.mkdir(parents=True, exist_ok=True)
    idx_path = cache_dir / f"knn_k{max_k}_index.i32"
    dist_path = cache_dir / f"knn_k{max_k}_dist_m.f32"
    meta_path = cache_dir / f"knn_k{max_k}.json"

    sig = hashlib.sha256()
    sig.update(str(len(x)).encode())
    sig.update(str(max_k).encode())
    sig.update(sha256_array_sample(x).encode())
    sig.update(sha256_array_sample(y).encode())
    signature = sig.hexdigest()

    expected_idx_bytes = len(x) * max_k * 4
    expected_dist_bytes = len(x) * max_k * 4

    if idx_path.exists() and dist_path.exists() and meta_path.exists():
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            if (
                meta.get("signature") == signature
                and idx_path.stat().st_size == expected_idx_bytes
                and dist_path.stat().st_size == expected_dist_bytes
                and meta.get("status") == "complete"
            ):
                print("Reusing KNN cache:", cache_dir)
                idx_mm = np.memmap(
                    idx_path, mode="r", dtype=np.int32,
                    shape=(len(x), max_k),
                )
                dist_mm = np.memmap(
                    dist_path, mode="r", dtype=np.float32,
                    shape=(len(x), max_k),
                )
                return idx_mm, dist_mm, meta
        except Exception:
            pass

    print(f"Building KNN cache: n_ps={len(x)}, max_k={max_k}")
    tree = cKDTree(np.column_stack([x, y]))

    idx_mm = np.memmap(
        idx_path, mode="w+", dtype=np.int32,
        shape=(len(x), max_k),
    )
    dist_mm = np.memmap(
        dist_path, mode="w+", dtype=np.float32,
        shape=(len(x), max_k),
    )

    for r0 in range(0, len(x), query_chunk):
        r1 = min(len(x), r0 + query_chunk)
        pts = np.column_stack([x[r0:r1], y[r0:r1]])
        d, ii = tree.query(
            pts,
            k=max_k + 1,
            workers=-1,
        )
        d = np.asarray(d, dtype=np.float64)
        ii = np.asarray(ii, dtype=np.int64)

        center_ids = np.arange(r0, r1, dtype=np.int64)[:, None]
        self_mask = ii == center_ids
        d[self_mask] = np.inf

        order = np.argsort(d, axis=1)[:, :max_k]
        rows = np.arange(r1 - r0)[:, None]
        ii2 = ii[rows, order]
        d2 = d[rows, order]

        idx_mm[r0:r1, :] = ii2.astype(np.int32)
        dist_mm[r0:r1, :] = d2.astype(np.float32)

        if r0 == 0 or r1 == len(x) or r1 % 50000 < query_chunk:
            idx_mm.flush()
            dist_mm.flush()
            print(f"  KNN PS: {r1}/{len(x)}")

    idx_mm.flush()
    dist_mm.flush()

    meta = {
        "status": "complete",
        "signature": signature,
        "n_ps": len(x),
        "max_k": max_k,
        "index_dtype": "int32",
        "distance_dtype": "float32",
        "coordinate_units": "meters_local_equirectangular",
        "note": "Same PS sampling; cache does not aggregate or resample.",
    }
    meta_path.write_text(json.dumps(meta, indent=2), encoding="utf-8")

    del tree
    gc.collect()

    idx_mm = np.memmap(
        idx_path, mode="r", dtype=np.int32,
        shape=(len(x), max_k),
    )
    dist_mm = np.memmap(
        dist_path, mode="r", dtype=np.float32,
        shape=(len(x), max_k),
    )
    return idx_mm, dist_mm, meta


# =============================================================================
# robust local plane
# =============================================================================

def _safe_batch_solve_3x3(N: np.ndarray, rhs: np.ndarray):
    """Solve a batch of 3x3 systems, compatible with NumPy 1.x/2.x signatures."""
    out = np.full_like(rhs, np.nan, dtype=np.float64)
    try:
        # Explicit (...,3,1) RHS avoids NumPy-version ambiguity for stacked solve.
        sol = np.linalg.solve(N, rhs[..., None])[..., 0]
        good = np.all(np.isfinite(sol), axis=1)
        out[good] = sol[good]
        return out, good
    except (np.linalg.LinAlgError, ValueError):
        good = np.zeros(len(rhs), dtype=bool)
        for i in range(len(rhs)):
            try:
                s = np.linalg.solve(N[i], rhs[i])
                if np.all(np.isfinite(s)):
                    out[i] = s
                    good[i] = True
            except (np.linalg.LinAlgError, ValueError):
                pass
        return out, good


def robust_local_plane_chunk(
    values: np.ndarray,
    center_idx: np.ndarray,
    knn_idx,
    knn_dist,
    x: np.ndarray,
    y: np.ndarray,
    quality: np.ndarray,
    *,
    k: int,
    radius_m: float,
    h_m: float,
    quality_power: float,
    huber_k: float,
    irls_iterations: int,
    min_neighbors: int,
):
    centers = np.asarray(center_idx, dtype=np.int64)
    nbr = np.asarray(knn_idx[centers, :k], dtype=np.int64)
    dist = np.asarray(knn_dist[centers, :k], dtype=np.float64)

    vn = np.asarray(values[nbr], dtype=np.float64)
    qn = np.asarray(quality[nbr], dtype=np.float64)

    dx = (x[nbr] - x[centers, None]) / 1000.0
    dy = (y[nbr] - y[centers, None]) / 1000.0

    valid = (
        np.isfinite(vn)
        & np.isfinite(dist)
        & (dist <= radius_m)
        & (nbr >= 0)
    )
    n_valid = np.sum(valid, axis=1)

    w_spatial = np.exp(-0.5 * (dist / max(h_m, 1.0)) ** 2)
    w_quality = np.maximum(qn, 0.02) ** quality_power
    base_w = np.where(valid, w_spatial * w_quality, 0.0)

    # Scale x/y near O(1) for numerical stability.
    X = np.stack([
        np.ones_like(dx),
        dx,
        dy,
    ], axis=2)

    w = base_w.copy()
    beta = np.full((len(centers), 3), np.nan, dtype=np.float64)
    solved = np.zeros(len(centers), dtype=bool)
    local_mad = np.full(len(centers), np.nan, dtype=np.float64)

    for it in range(max(1, irls_iterations + 1)):
        N = np.einsum("mk,mki,mkj->mij", w, X, X)
        rhs = np.einsum("mk,mki,mk->mi", w, X, vn)

        trace = np.trace(N, axis1=1, axis2=2)
        ridge = np.maximum(trace * 1e-8, 1e-10)
        N[:, 0, 0] += ridge
        N[:, 1, 1] += ridge
        N[:, 2, 2] += ridge

        beta_new, good = _safe_batch_solve_3x3(N, rhs)
        good &= n_valid >= min_neighbors
        beta[good] = beta_new[good]
        solved |= good

        if it >= irls_iterations:
            break

        pred = np.einsum("mki,mi->mk", X, beta_new)
        resid = vn - pred
        resid = np.where(valid, resid, np.nan)

        med = np.nanmedian(resid, axis=1)
        mad = 1.4826 * np.nanmedian(
            np.abs(resid - med[:, None]), axis=1
        )
        mad = np.where(np.isfinite(mad), np.maximum(mad, 0.5), 1.0)
        local_mad = mad

        u = np.abs(resid - med[:, None]) / (huber_k * mad[:, None])
        wr = np.ones_like(u)
        mask = np.isfinite(u) & (u > 1.0)
        wr[mask] = 1.0 / u[mask]
        wr[~np.isfinite(u)] = 0.0
        w = base_w * wr

    local = beta[:, 0]
    grad = np.sqrt(beta[:, 1] ** 2 + beta[:, 2] ** 2)  # mm/yr/km

    local[~solved] = np.nan
    grad[~solved] = np.nan
    local_mad[~solved] = np.nan

    return local, grad, local_mad, n_valid, solved


def filter_centers(
    values: np.ndarray,
    centers: np.ndarray,
    knn_idx,
    knn_dist,
    x,
    y,
    quality,
    ref_ids,
    cfg: Dict[str, Any],
    *,
    block_centers: int,
    correction_cap_mm_yr: float,
    apply_reference_correction_zero: bool,
):
    centers = np.asarray(centers, dtype=np.int64)
    pred = np.full(len(centers), np.nan, dtype=np.float32)
    local_pred = np.full(len(centers), np.nan, dtype=np.float32)
    gradient = np.full(len(centers), np.nan, dtype=np.float32)
    local_mad = np.full(len(centers), np.nan, dtype=np.float32)
    n_neighbors = np.zeros(len(centers), dtype=np.int16)
    strength = np.zeros(len(centers), dtype=np.float32)

    # To preserve the correction reference, we need the correction at reference PS.
    # Compute it separately using the exact same configuration.
    ref_local, _, _, _, ref_solved = robust_local_plane_chunk(
        values,
        ref_ids,
        knn_idx,
        knn_dist,
        x,
        y,
        quality,
        k=cfg["k"],
        radius_m=cfg["radius_m"],
        h_m=cfg["h_m"],
        quality_power=cfg["quality_power"],
        huber_k=cfg["huber_k"],
        irls_iterations=cfg["irls_iterations"],
        min_neighbors=cfg["min_neighbors"],
    )
    qref = np.asarray(quality[ref_ids], dtype=float)
    sref = cfg["lambda"] * (1.0 - qref) ** cfg["gamma"]
    rawref = np.asarray(values[ref_ids], dtype=float)
    dref = sref * (ref_local - rawref)
    if correction_cap_mm_yr > 0:
        dref = np.clip(dref, -correction_cap_mm_yr, correction_cap_mm_yr)
    correction_ref_median = (
        float(np.nanmedian(dref[ref_solved]))
        if np.any(ref_solved) else 0.0
    )

    for c0 in range(0, len(centers), block_centers):
        c1 = min(len(centers), c0 + block_centers)
        ids = centers[c0:c1]

        loc, grad, mad, nnei, solved = robust_local_plane_chunk(
            values,
            ids,
            knn_idx,
            knn_dist,
            x,
            y,
            quality,
            k=cfg["k"],
            radius_m=cfg["radius_m"],
            h_m=cfg["h_m"],
            quality_power=cfg["quality_power"],
            huber_k=cfg["huber_k"],
            irls_iterations=cfg["irls_iterations"],
            min_neighbors=cfg["min_neighbors"],
        )

        raw = np.asarray(values[ids], dtype=float)
        qc = np.asarray(quality[ids], dtype=float)

        s = cfg["lambda"] * (1.0 - qc) ** cfg["gamma"]
        delta = s * (loc - raw)
        delta[~solved] = 0.0

        if correction_cap_mm_yr > 0:
            delta = np.clip(
                delta,
                -correction_cap_mm_yr,
                correction_cap_mm_yr,
            )

        if apply_reference_correction_zero:
            delta -= correction_ref_median

        out = raw + delta

        pred[c0:c1] = out.astype(np.float32)
        local_pred[c0:c1] = loc.astype(np.float32)
        gradient[c0:c1] = grad.astype(np.float32)
        local_mad[c0:c1] = mad.astype(np.float32)
        n_neighbors[c0:c1] = nnei.astype(np.int16)
        strength[c0:c1] = s.astype(np.float32)

    return {
        "filtered": pred,
        "local_plane": local_pred,
        "gradient_mm_yr_per_km": gradient,
        "local_mad_mm_yr": local_mad,
        "n_neighbors": n_neighbors,
        "strength": strength,
        "correction_reference_median_removed": correction_ref_median,
    }


# =============================================================================
# truth
# =============================================================================

def choose_vfield(gdf, preferred: str):
    geom = gdf.geometry.name
    cols = [c for c in gdf.columns if c != geom]
    for c in cols:
        if c.lower() == preferred.lower():
            return c
    numeric = [c for c in cols if np.issubdtype(gdf[c].dtype, np.number)]
    for p in ("v", "vel", "velocity", "rate"):
        for c in numeric:
            key = re.sub(r"[^a-z0-9]", "", c.lower())
            if key == p:
                return c
    raise RuntimeError(f"Cannot identify truth velocity field: {cols}")


def read_truth_cropped(
    path: Path,
    preferred_field: str,
    scale: float,
    lon0: float,
    lat0: float,
    ps_bbox: Tuple[float, float, float, float],
    buffer_m: float,
):
    import geopandas as gpd

    gdf = gpd.read_file(path)
    if gdf.crs is not None:
        gdf = gdf.to_crs(4326)
    if not np.all(gdf.geometry.geom_type == "Point"):
        raise RuntimeError(f"{path.name} is not Point geometry")
    vf = choose_vfield(gdf, preferred_field)

    lon = np.asarray(gdf.geometry.x, dtype=float)
    lat = np.asarray(gdf.geometry.y, dtype=float)
    v = np.asarray(gdf[vf], dtype=float) * scale
    good = np.isfinite(lon) & np.isfinite(lat) & np.isfinite(v)
    lon, lat, v = lon[good], lat[good], v[good]

    x, y, _, _ = local_xy(lon, lat, lon0, lat0)
    xmin, xmax, ymin, ymax = ps_bbox
    inside = (
        (x >= xmin - buffer_m)
        & (x <= xmax + buffer_m)
        & (y >= ymin - buffer_m)
        & (y <= ymax + buffer_m)
    )

    del gdf
    gc.collect()

    return x[inside], y[inside], v[inside], vf


def unique_ps_truth_mapping(ps_xy, truth_xy, match_m):
    tree = cKDTree(truth_xy)
    dist, tidx = tree.query(ps_xy, k=1, workers=-1)
    dist = np.asarray(dist, dtype=float)
    tidx = np.asarray(tidx, dtype=np.int64)

    within = np.isfinite(dist) & (dist <= match_m)
    p = np.flatnonzero(within)
    d = dist[within]
    t = tidx[within]

    order = np.argsort(d)
    t_order = t[order]
    _, first = np.unique(t_order, return_index=True)
    keep = np.sort(order[first])

    return p[keep], t[keep], d[keep]


# =============================================================================
# raster at exact existing resolution
# =============================================================================

def raster_assignment(lon, lat, template_path: Path):
    import rasterio
    with rasterio.open(template_path) as src:
        profile = src.profile.copy()
        transform = src.transform
        crs = src.crs
        width, height = src.width, src.height

    if crs is None:
        raise RuntimeError(f"Template has no CRS: {template_path}")

    if crs.to_epsg() == 4326:
        xs, ys = lon.astype(float), lat.astype(float)
    else:
        from pyproj import Transformer
        tr = Transformer.from_crs("EPSG:4326", crs, always_xy=True)
        xs, ys = tr.transform(lon.astype(float), lat.astype(float))
        xs, ys = np.asarray(xs), np.asarray(ys)

    inv = ~transform
    cols_f, rows_f = inv * (xs, ys)
    cols = np.floor(cols_f).astype(np.int64)
    rows = np.floor(rows_f).astype(np.int64)

    inside = (
        np.isfinite(xs) & np.isfinite(ys)
        & (rows >= 0) & (rows < height)
        & (cols >= 0) & (cols < width)
    )
    psidx = np.flatnonzero(inside)
    flat = (rows[inside] * width + cols[inside]).astype(np.int64)

    return psidx, flat, profile, width, height


def write_ps_median_tif(
    path: Path,
    values,
    psidx,
    flat,
    profile,
    width,
    height,
    tags,
):
    import pandas as pd
    import rasterio

    vals = np.asarray(values, dtype=float)[psidx]
    good = np.isfinite(vals)

    df = pd.DataFrame({
        "cell": flat[good],
        "value": vals[good],
    })
    med = df.groupby("cell", sort=False)["value"].median()

    nodata = np.float32(-9999.0)
    arr = np.full(height * width, nodata, dtype=np.float32)
    arr[med.index.to_numpy(dtype=np.int64)] = med.to_numpy(dtype=np.float32)
    arr = arr.reshape(height, width)

    out_profile = profile.copy()
    out_profile.update(
        count=1,
        dtype="float32",
        nodata=float(nodata),
        compress="deflate",
        predictor=3,
    )

    path.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(path, "w", **out_profile) as dst:
        dst.write(arr, 1)
        dst.set_band_description(1, tags.get("band_description", "value"))
        dst.update_tags(**{k: str(v) for k, v in tags.items()})


def choose_raster_template(final_dir: Path, fallback: Path):
    annual_dir = final_dir / "rasters" / "annual_velocity"
    if annual_dir.is_dir():
        candidates = sorted(annual_dir.glob("*.tif"))
        if candidates:
            return candidates[0]
    # Some prior product layouts put annual_velocity directly under final dir.
    for d in [
        final_dir / "annual_velocity",
        final_dir / "rasters",
    ]:
        if d.is_dir():
            candidates = sorted(d.glob("*.tif"))
            if candidates:
                return candidates[0]
    if fallback.exists():
        return fallback
    raise FileNotFoundError("Could not find existing raster template")


# =============================================================================
# candidate configurations / selection
# =============================================================================

def candidate_configs():
    # Compact, physically interpretable screen. No coarse-grid output.
    geom = [
        ("K24_R500", 24, 500.0, 300.0),
        ("K32_R750", 32, 750.0, 450.0),
        ("K48_R750", 48, 750.0, 450.0),
        ("K48_R1000", 48, 1000.0, 600.0),
        ("K64_R1000", 64, 1000.0, 600.0),
        ("K64_R1500", 64, 1500.0, 900.0),
    ]
    strengths = [0.50, 0.75, 1.00]
    out = []
    for name, k, radius, h in geom:
        for lam in strengths:
            out.append({
                "name": f"{name}_L{lam:.2f}",
                "k": k,
                "radius_m": radius,
                "h_m": h,
                "lambda": lam,
                "gamma": 1.5,
                "quality_power": 1.0,
                "huber_k": 1.5,
                "irls_iterations": 2,
                "min_neighbors": 10,
            })
    return out


def loyo_select(
    full_metrics: Dict[str, Dict[int, Dict[str, Any]]],
    years=(2021, 2022, 2023),
):
    fold_rows = []
    winner_counts = {}

    for holdout in years:
        train = [y for y in years if y != holdout]
        scored = []
        for cfg_name, ym in full_metrics.items():
            train_rmse = np.mean([ym[y]["rmse_mm_yr"] for y in train])
            scored.append((train_rmse, cfg_name))
        scored.sort()
        _, winner = scored[0]
        winner_counts[winner] = winner_counts.get(winner, 0) + 1
        fold_rows.append({
            "holdout_year": holdout,
            "train_years": "+".join(str(y) for y in train),
            "selected_config": winner,
            "train_mean_rmse_mm_yr": float(scored[0][0]),
            "holdout_rmse_mm_yr": float(full_metrics[winner][holdout]["rmse_mm_yr"]),
            "holdout_correlation": float(full_metrics[winner][holdout]["correlation"]),
        })

    # Consensus: most fold wins; tie -> best mean full RMSE among tied.
    maxwins = max(winner_counts.values())
    tied = [k for k, v in winner_counts.items() if v == maxwins]
    tied.sort(
        key=lambda cfg: np.mean(
            [full_metrics[cfg][y]["rmse_mm_yr"] for y in years]
        )
    )
    selected = tied[0]
    return selected, fold_rows, winner_counts


# =============================================================================
# CLI
# =============================================================================

def parse_args():
    p = argparse.ArgumentParser(
        description="V5 Final-C annual local-noise denoising at original 4:1 resolution"
    )
    p.add_argument(
        "--dataset",
        default="/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized",
    )
    p.add_argument("--truth-dir", default="")
    p.add_argument("--truth-field", default="v")
    p.add_argument("--truth-scale", type=float, default=1.0)
    p.add_argument("--match-m", type=float, default=200.0)
    p.add_argument("--truth-buffer-m", type=float, default=1500.0)

    p.add_argument("--knn-max-k", type=int, default=64)
    p.add_argument("--knn-query-chunk", type=int, default=25000)
    p.add_argument("--filter-block-centers", type=int, default=5000)

    p.add_argument("--tune-sample-per-year", type=int, default=30000)
    p.add_argument("--top-n-full", type=int, default=4)

    p.add_argument("--correction-cap-mm-yr", type=float, default=20.0)
    p.add_argument("--min-mean-improvement", type=float, default=0.03)
    p.add_argument("--max-single-year-degradation", type=float, default=0.01)

    p.add_argument("--reference-lon", type=float, default=117.21775055)
    p.add_argument("--reference-lat", type=float, default=38.40310669)
    p.add_argument("--reference-radius-m", type=float, default=500.0)

    p.add_argument("--out", default="")
    p.add_argument("--cache-dir", default="")
    p.add_argument("--always-write-product", action="store_true")
    p.add_argument("--no-write-tifs", action="store_true")
    p.add_argument(
        "--raster-template",
        default="postprocess/rasters/geo_velocity.tif",
    )
    p.add_argument("--seed", type=int, default=20260811)
    p.add_argument("--self-test", action="store_true")
    return p.parse_args()


def self_test():
    rng = np.random.default_rng(0)
    # synthetic tilted plane + sparse outliers
    gx, gy = np.meshgrid(np.arange(20)*100.0, np.arange(20)*100.0)
    x = gx.ravel()
    y = gy.ravel()
    true = 5.0 + 0.004*x - 0.002*y
    raw = true + rng.normal(0, 1.0, len(true))
    outliers = rng.choice(len(true), size=20, replace=False)
    raw[outliers] += rng.normal(0, 12.0, len(outliers))
    q = np.ones(len(true), dtype=np.float32)
    q[outliers] = 0.1

    tree = cKDTree(np.column_stack([x, y]))
    d, ii = tree.query(np.column_stack([x, y]), k=17)
    d = d[:, 1:].astype(np.float32)
    ii = ii[:, 1:].astype(np.int32)

    cfg = {
        "k": 16,
        "radius_m": 600.0,
        "h_m": 300.0,
        "lambda": 1.0,
        "gamma": 1.5,
        "quality_power": 1.0,
        "huber_k": 1.5,
        "irls_iterations": 2,
        "min_neighbors": 8,
    }
    centers = np.arange(len(true), dtype=np.int64)
    ref = np.arange(10, dtype=np.int64)
    r = filter_centers(
        raw, centers, ii, d, x, y, q, ref, cfg,
        block_centers=100,
        correction_cap_mm_yr=20.0,
        apply_reference_correction_zero=False,
    )
    rmse_raw = np.sqrt(np.mean((raw-true)**2))
    rmse_f = np.sqrt(np.mean((r["filtered"]-true)**2))
    assert rmse_f < rmse_raw
    # The robust filter should recover the known large-scale plane more accurately
    # than the outlier-contaminated raw field.
    br = fit_global_plane(raw, x, y)
    bf = fit_global_plane(r["filtered"], x, y)
    bt = fit_global_plane(true, x, y)
    assert np.linalg.norm(bf[1:]-bt[1:]) < np.linalg.norm(br[1:]-bt[1:])
    print("SELF-TEST: PASS")
    print("  raw RMSE     :", rmse_raw)
    print("  filtered RMSE:", rmse_f)
    print("  raw plane-gradient error     :", np.linalg.norm(br[1:]-bt[1:]))
    print("  filtered plane-gradient error:", np.linalg.norm(bf[1:]-bt[1:]))


# =============================================================================
# main
# =============================================================================

def main():
    args = parse_args()
    if args.self_test:
        self_test()
        return

    t0 = time.time()
    dataset = Path(args.dataset).resolve()
    truth_dir = (
        Path(args.truth_dir).resolve()
        if args.truth_dir
        else dataset / "cangzhou"
    )

    final_dir = find_latest_final_c(dataset)
    lon, lat, full_velocity, annual, final_npz = load_final_c(final_dir)
    n_ps = len(lon)
    years_all = sorted(annual.keys())

    print("=" * 80)
    print("V5 Final-C annual local denoising — ORIGINAL 4:1 RESOLUTION")
    print("=" * 80)
    print("dataset :", dataset)
    print("Final-C :", final_dir)
    print("n_ps    :", n_ps)
    print("years   :", years_all)
    print("No PS aggregation / no coarse resampling.")
    print()

    if not all(y in annual for y in (2021, 2022, 2023)):
        raise RuntimeError("Final-C must contain annual velocities for 2021/2022/2023")

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = (
        Path(args.out).resolve()
        if args.out
        else dataset / "_audit" / f"finalC_local_denoise_v5_{stamp}"
    )
    out.mkdir(parents=True, exist_ok=True)

    x, y, lon0, lat0 = local_xy(lon, lat)
    ps_xy = np.column_stack([x, y])
    ps_bbox = (
        float(np.min(x)), float(np.max(x)),
        float(np.min(y)), float(np.max(y)),
    )

    coh_raw, coh_source = load_coh_ps(dataset, n_ps)
    quality, quality_meta = normalize_quality(coh_raw)

    ref_ids, ref_source = exact_reference_indices(final_dir, n_ps)

    cache_dir = (
        Path(args.cache_dir).resolve()
        if args.cache_dir
        else dataset / "_finalC_local_denoise_cache_v5"
    )
    knn_idx, knn_dist, knn_meta = build_or_reuse_knn_cache(
        cache_dir,
        x,
        y,
        args.knn_max_k,
        args.knn_query_chunk,
    )

    # ------------------------------------------------------------------
    # Truth mappings
    # ------------------------------------------------------------------
    truth = {}
    rng = np.random.default_rng(args.seed)
    refx, refy = lonlat_to_xy(
        args.reference_lon,
        args.reference_lat,
        lon0,
        lat0,
    )

    print("\nPreparing truth mappings ...")
    for year in (2021, 2022, 2023):
        p = truth_dir / f"result{year}.shp"
        if not p.exists():
            raise FileNotFoundError(p)

        tx, ty, tv_raw, vf = read_truth_cropped(
            p,
            args.truth_field,
            args.truth_scale,
            lon0,
            lat0,
            ps_bbox,
            args.truth_buffer_m,
        )

        tt = cKDTree(np.column_stack([tx, ty]))
        truth_ref_ids = np.asarray(
            tt.query_ball_point(
                [refx, refy],
                r=args.reference_radius_m,
            ),
            dtype=np.int64,
        )
        if len(truth_ref_ids) < 10:
            raise RuntimeError(f"{year}: too few truth reference points")
        truth_ref = float(np.nanmedian(tv_raw[truth_ref_ids]))
        tv = tv_raw - truth_ref

        pidx, tidx, dist = unique_ps_truth_mapping(
            ps_xy,
            np.column_stack([tx, ty]),
            args.match_m,
        )

        # deterministic tuning subset
        if len(pidx) > args.tune_sample_per_year:
            choose = np.sort(
                rng.choice(
                    len(pidx),
                    size=args.tune_sample_per_year,
                    replace=False,
                )
            )
        else:
            choose = np.arange(len(pidx))

        truth[year] = {
            "v": tv,
            "pidx": pidx,
            "tidx": tidx,
            "dist": dist,
            "tune_pidx": pidx[choose],
            "tune_tidx": tidx[choose],
            "truth_ref": truth_ref,
            "field": vf,
        }

        print(
            f"  {year}: matched={len(pidx)}, "
            f"tune={len(choose)}, truth_ref={truth_ref:.4f}"
        )

    # Raw baseline metrics.
    raw_metrics = {}
    for year in (2021, 2022, 2023):
        td = truth[year]
        raw_metrics[year] = validation_metrics(
            annual[year][td["pidx"]],
            td["v"][td["tidx"]],
        )

    # ------------------------------------------------------------------
    # Coarse candidate screen
    # ------------------------------------------------------------------
    configs = candidate_configs()
    if max(c["k"] for c in configs) > args.knn_max_k:
        raise RuntimeError("--knn-max-k smaller than candidate k")

    print(f"\nCoarse screening {len(configs)} configs ...")
    coarse_rows = []
    coarse_score = {}

    for ci, cfg in enumerate(configs, 1):
        year_metrics = []
        print(f"[{ci:02d}/{len(configs)}] {cfg['name']}")
        for year in (2021, 2022, 2023):
            td = truth[year]
            centers = td["tune_pidx"]
            result = filter_centers(
                annual[year],
                centers,
                knn_idx,
                knn_dist,
                x,
                y,
                quality,
                ref_ids,
                cfg,
                block_centers=args.filter_block_centers,
                correction_cap_mm_yr=args.correction_cap_mm_yr,
                apply_reference_correction_zero=True,
            )
            truth_v = td["v"][td["tune_tidx"]]
            mm = validation_metrics(result["filtered"], truth_v)
            year_metrics.append(mm["rmse_mm_yr"])
            coarse_rows.append({
                "config": cfg["name"],
                "year": year,
                **cfg,
                **mm,
            })
        coarse_score[cfg["name"]] = float(np.mean(year_metrics))

    write_csv(out / "01_coarse_screen.csv", coarse_rows)

    ranked = sorted(configs, key=lambda c: coarse_score[c["name"]])
    finalists = ranked[:max(1, args.top_n_full)]

    print("\nFull validation finalists:")
    for cfg in finalists:
        print(" ", cfg["name"], "coarse mean RMSE", coarse_score[cfg["name"]])

    # ------------------------------------------------------------------
    # Full matched validation
    # ------------------------------------------------------------------
    full_rows = []
    full_metrics: Dict[str, Dict[int, Dict[str, Any]]] = {}
    correction_rows = []
    finalist_predictions = {}

    for cfg in finalists:
        cfg_name = cfg["name"]
        full_metrics[cfg_name] = {}
        finalist_predictions[cfg_name] = {}

        print(f"\nFULL validation: {cfg_name}")

        for year in (2021, 2022, 2023):
            td = truth[year]
            centers = td["pidx"]
            result = filter_centers(
                annual[year],
                centers,
                knn_idx,
                knn_dist,
                x,
                y,
                quality,
                ref_ids,
                cfg,
                block_centers=args.filter_block_centers,
                correction_cap_mm_yr=args.correction_cap_mm_yr,
                apply_reference_correction_zero=True,
            )
            truth_v = td["v"][td["tidx"]]
            mm = validation_metrics(result["filtered"], truth_v)
            full_metrics[cfg_name][year] = mm
            finalist_predictions[cfg_name][year] = result["filtered"]

            raw = annual[year][centers]
            delta = result["filtered"] - raw

            full_rows.append({
                "config": cfg_name,
                "year": year,
                **cfg,
                **mm,
                "raw_rmse_mm_yr": raw_metrics[year]["rmse_mm_yr"],
                "relative_rmse_improvement": (
                    raw_metrics[year]["rmse_mm_yr"] - mm["rmse_mm_yr"]
                ) / raw_metrics[year]["rmse_mm_yr"],
            })

            correction_rows.append({
                "config": cfg_name,
                "year": year,
                "n": len(delta),
                "correction_median_mm_yr": float(np.nanmedian(delta)),
                "correction_median_abs_mm_yr": float(np.nanmedian(np.abs(delta))),
                "correction_p90_abs_mm_yr": float(np.nanpercentile(np.abs(delta), 90)),
                "correction_p95_abs_mm_yr": float(np.nanpercentile(np.abs(delta), 95)),
                "correction_max_abs_mm_yr": float(np.nanmax(np.abs(delta))),
                "reference_correction_median_removed_mm_yr": float(
                    result["correction_reference_median_removed"]
                ),
            })

            print(
                f"  {year}: raw={raw_metrics[year]['rmse_mm_yr']:.3f}, "
                f"filtered={mm['rmse_mm_yr']:.3f}, "
                f"improve={100*(raw_metrics[year]['rmse_mm_yr']-mm['rmse_mm_yr'])/raw_metrics[year]['rmse_mm_yr']:.2f}%"
            )

    write_csv(out / "02_full_validation.csv", full_rows)
    write_csv(out / "03_correction_validation.csv", correction_rows)

    selected_name, fold_rows, winner_counts = loyo_select(full_metrics)
    write_csv(out / "04_leave_one_year_out.csv", fold_rows)

    selected_cfg = next(c for c in finalists if c["name"] == selected_name)

    print("\nLOYO selected production config:", selected_name)
    print("fold winner counts:", winner_counts)

    # ------------------------------------------------------------------
    # Guardrails
    # ------------------------------------------------------------------
    selected_year_metrics = full_metrics[selected_name]
    rel_improvements = {}
    for year in (2021, 2022, 2023):
        rel_improvements[year] = (
            raw_metrics[year]["rmse_mm_yr"]
            - selected_year_metrics[year]["rmse_mm_yr"]
        ) / raw_metrics[year]["rmse_mm_yr"]

    mean_improvement = float(np.mean(list(rel_improvements.values())))
    worst_improvement = float(np.min(list(rel_improvements.values())))

    pass_mean = mean_improvement >= args.min_mean_improvement
    pass_single_year = worst_improvement >= -args.max_single_year_degradation

    # Correction/plane preservation diagnostics on truth-matched centers.
    selected_diag_rows = []
    for year in (2021, 2022, 2023):
        td = truth[year]
        centers = td["pidx"]
        pred = finalist_predictions[selected_name][year]
        raw = annual[year][centers]
        br = fit_global_plane(raw, x[centers], y[centers])
        bf = fit_global_plane(pred, x[centers], y[centers])
        selected_diag_rows.append({
            "year": year,
            "raw_plane_intercept": float(br[0]),
            "raw_plane_x_mm_yr_per_100km": float(br[1]),
            "raw_plane_y_mm_yr_per_100km": float(br[2]),
            "filtered_plane_intercept": float(bf[0]),
            "filtered_plane_x_mm_yr_per_100km": float(bf[1]),
            "filtered_plane_y_mm_yr_per_100km": float(bf[2]),
            "plane_x_change": float(bf[1] - br[1]),
            "plane_y_change": float(bf[2] - br[2]),
            "relative_rmse_improvement": rel_improvements[year],
        })
    write_csv(out / "05_large_scale_plane_preservation.csv", selected_diag_rows)

    eligible = pass_mean and pass_single_year

    decision = {
        "selected_config": selected_cfg,
        "winner_counts": winner_counts,
        "relative_rmse_improvement_by_year": rel_improvements,
        "mean_relative_rmse_improvement": mean_improvement,
        "worst_single_year_relative_improvement": worst_improvement,
        "guardrails": {
            "min_mean_improvement": args.min_mean_improvement,
            "max_single_year_degradation": args.max_single_year_degradation,
            "pass_mean": pass_mean,
            "pass_single_year": pass_single_year,
        },
        "eligible_for_product": bool(eligible),
        "resolution_policy": (
            "Original PS sampling preserved. GeoTIFF transform/shape/CRS copied "
            "from existing Final-C raster template. No 250/500/1000 m aggregation."
        ),
    }
    (out / "06_DECISION.json").write_text(
        json.dumps(decision, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("\nDecision:")
    print(json.dumps(decision, ensure_ascii=False, indent=2))

    # ------------------------------------------------------------------
    # Full same-resolution annual product
    # ------------------------------------------------------------------
    write_product = eligible or args.always_write_product
    product_dir = None

    if write_product:
        product_dir = out / "same_resolution_product"
        product_dir.mkdir(parents=True, exist_ok=True)

        print("\nGenerating SAME-RESOLUTION annual product ...")
        print("Selected:", selected_name)

        annual_filtered = {}
        annual_correction = {}
        diagnostics = {}

        all_centers = np.arange(n_ps, dtype=np.int64)

        for year in years_all:
            print(f"  year {year}")
            result = filter_centers(
                annual[year],
                all_centers,
                knn_idx,
                knn_dist,
                x,
                y,
                quality,
                ref_ids,
                selected_cfg,
                block_centers=args.filter_block_centers,
                correction_cap_mm_yr=args.correction_cap_mm_yr,
                apply_reference_correction_zero=True,
            )

            vf = np.asarray(result["filtered"], dtype=np.float32)
            delta = vf - np.asarray(annual[year], dtype=np.float32)

            annual_filtered[year] = vf
            annual_correction[year] = delta
            diagnostics[year] = {
                "gradient": result["gradient_mm_yr_per_km"],
                "local_mad": result["local_mad_mm_yr"],
                "n_neighbors": result["n_neighbors"],
                "strength": result["strength"],
                "correction_reference_median_removed": result[
                    "correction_reference_median_removed"
                ],
            }

        # Point product: full-period velocity copied UNCHANGED.
        payload = {
            "ps_index_1based": np.arange(1, n_ps + 1, dtype=np.int32),
            "lon": lon.astype(np.float64),
            "lat": lat.astype(np.float64),
            "full_velocity_mm_yr": full_velocity.astype(np.float32),
            "coh_ps": coh_raw.astype(np.float32),
            "quality_normalized": quality.astype(np.float32),
        }
        for year in years_all:
            payload[f"velocity_{year}_mm_yr"] = annual_filtered[year]
            payload[f"correction_{year}_mm_yr"] = annual_correction[year]

        np.savez_compressed(
            product_dir / "annual_velocity_same_4x1_resolution_points.npz",
            **payload,
        )

        # Separate diagnostic NPZ to keep main product cleaner.
        diag_payload = {}
        for year in years_all:
            diag_payload[f"local_gradient_{year}_mm_yr_per_km"] = diagnostics[year]["gradient"]
            diag_payload[f"local_mad_{year}_mm_yr"] = diagnostics[year]["local_mad"]
            diag_payload[f"n_neighbors_{year}"] = diagnostics[year]["n_neighbors"]
            diag_payload[f"blend_strength_{year}"] = diagnostics[year]["strength"]
        np.savez_compressed(
            product_dir / "local_filter_diagnostics.npz",
            **diag_payload,
        )

        # Exact original-raster template.
        fallback = Path(args.raster_template)
        if not fallback.is_absolute():
            fallback = dataset / fallback

        if not args.no_write_tifs:
            template = choose_raster_template(final_dir, fallback)
            print("Raster template:", template)

            psidx, flat, profile, width, height = raster_assignment(
                lon, lat, template
            )

            common_tags = {
                "method": "quality_guided_robust_local_plane",
                "selected_config": selected_name,
                "source": str(final_dir),
                "original_4x1_resolution_preserved": "yes",
                "aggregation": "none",
                "resampling": "none",
                "full_period_velocity_changed": "no",
                "units": "mm/year",
            }

            # Full-period velocity copied at same raster geometry, not filtered.
            write_ps_median_tif(
                product_dir / "full_period_velocity_UNCHANGED.tif",
                full_velocity,
                psidx, flat, profile, width, height,
                {
                    **common_tags,
                    "band_description": "full_period_velocity_mm_per_year",
                    "filter_applied": "no",
                },
            )

            annual_dir = product_dir / "annual_velocity"
            corr_dir = product_dir / "annual_correction"

            for year in years_all:
                write_ps_median_tif(
                    annual_dir / f"annual_velocity_{year}.tif",
                    annual_filtered[year],
                    psidx, flat, profile, width, height,
                    {
                        **common_tags,
                        "band_description": "annual_velocity_mm_per_year",
                        "year": year,
                        "filter_applied": "yes",
                    },
                )
                write_ps_median_tif(
                    corr_dir / f"annual_correction_{year}.tif",
                    annual_correction[year],
                    psidx, flat, profile, width, height,
                    {
                        **common_tags,
                        "band_description": "annual_filter_correction_mm_per_year",
                        "year": year,
                        "filter_applied": "correction_only",
                    },
                )

            raster_meta = {
                "template": str(template),
                "width": width,
                "height": height,
                "transform": list(profile["transform"])[:6],
                "crs": str(profile.get("crs")),
                "note": (
                    "Output rasters copy template shape/transform/CRS exactly. "
                    "No 500m/1000m grid product is created."
                ),
            }
            (product_dir / "RASTER_RESOLUTION.json").write_text(
                json.dumps(raster_meta, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )

    else:
        print(
            "\nProduct NOT written: selected filter did not pass guardrails. "
            "Use --always-write-product only for a deliberate diagnostic output."
        )

    manifest = {
        "version": "finalC_local_denoise_v5",
        "dataset": str(dataset),
        "source_final_C": str(final_dir),
        "source_velocity_npz": str(final_npz),
        "n_ps": n_ps,
        "years": years_all,
        "quality_source": coh_source,
        "quality_normalization": quality_meta,
        "reference_source": ref_source,
        "knn_cache": str(cache_dir),
        "knn_meta": knn_meta,
        "selected_config": selected_cfg,
        "decision": decision,
        "correction_cap_mm_yr": args.correction_cap_mm_yr,
        "product_dir": str(product_dir) if product_dir else None,
        "critical_resolution_statement": (
            "Same original PS positions and existing Final-C raster geometry. "
            "No spatial aggregation/downsampling; 4:1 processing resolution preserved."
        ),
        "runtime_seconds": time.time() - t0,
    }
    (out / "MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    readme = f"""
V5 Final-C local denoising complete
============================================================================

Source:
  {final_dir}

PS:
  {n_ps}

Resolution:
  ORIGINAL 4:1 processing resolution preserved.
  No 250 m / 500 m / 1000 m aggregation.
  No PS downsampling.
  Same existing Final-C raster geometry is used for GeoTIFF output.

Selected configuration:
  {selected_name}

Truth relative RMSE improvement:
  2021: {100*rel_improvements[2021]:.3f} %
  2022: {100*rel_improvements[2022]:.3f} %
  2023: {100*rel_improvements[2023]:.3f} %
  mean: {100*mean_improvement:.3f} %

Eligible product:
  {eligible}

Full-period velocity:
  UNCHANGED.

Time series:
  UNCHANGED.

Only annual velocity is locally regularized.

Key audit files:
  01_coarse_screen.csv
  02_full_validation.csv
  03_correction_validation.csv
  04_leave_one_year_out.csv
  05_large_scale_plane_preservation.csv
  06_DECISION.json
  MANIFEST.json

Product, if guardrails passed:
  same_resolution_product/
""".strip()

    (out / "READ_ME_FIRST.txt").write_text(
        readme + "\n",
        encoding="utf-8",
    )

    print("\n" + "=" * 80)
    print("V5 COMPLETE")
    print("=" * 80)
    print("runtime:", f"{time.time()-t0:.1f}s")
    print("output :", out)
    print("selected:", selected_name)
    print("mean relative RMSE improvement:", f"{100*mean_improvement:.2f}%")
    print("same-resolution product:", product_dir)
    print()
    print("First inspect:")
    for p in [
        out / "02_full_validation.csv",
        out / "03_correction_validation.csv",
        out / "04_leave_one_year_out.csv",
        out / "05_large_scale_plane_preservation.csv",
        out / "06_DECISION.json",
        out / "MANIFEST.json",
    ]:
        print(" ", p)


if __name__ == "__main__":
    main()
