#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/home/ubuntu/software/pystamps-main}"
PYTHON="${PYTHON:-/home/ubuntu/software/miniconda3/envs/stamps/bin/python}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$ROOT/tools"

cp "$HERE/finalC_local_denoise_v5.py" \
   "$ROOT/tools/finalC_local_denoise_v5.py"
cp "$HERE/run_finalC_local_denoise_v5.sh" \
   "$ROOT/run_finalC_local_denoise_v5.sh"

chmod +x "$ROOT/tools/finalC_local_denoise_v5.py"
chmod +x "$ROOT/run_finalC_local_denoise_v5.sh"

echo "Installed:"
echo "  $ROOT/tools/finalC_local_denoise_v5.py"
echo "  $ROOT/run_finalC_local_denoise_v5.sh"
echo
echo "Resolution policy:"
echo "  - same PS positions"
echo "  - same existing Final-C raster geometry"
echo "  - no spatial aggregation/downsampling"
echo "  - full-period velocity unchanged"
echo
echo "No Conda/Python package is changed."

echo
echo "Dependency check:"
"$PYTHON" - <<'PY'
mods = ["numpy", "scipy", "geopandas", "rasterio", "pyproj", "pandas"]
missing = []
for m in mods:
    try:
        __import__(m)
        print("  OK  ", m)
    except Exception as e:
        print("  MISS", m, repr(e))
        missing.append(m)
if missing:
    raise SystemExit(
        "Missing dependencies: " + ", ".join(missing)
        + ". Do not change the existing environment blindly."
    )
PY

echo
echo "Self-test:"
"$ROOT/run_finalC_local_denoise_v5.sh" --self-test

echo
echo "Installation complete."
echo
echo "Run:"
echo "  cd '$ROOT'"
echo "  ./run_finalC_local_denoise_v5.sh"

if [[ "${1:-}" == "--run" ]]; then
    shift
    exec "$ROOT/run_finalC_local_denoise_v5.sh" "$@"
fi
