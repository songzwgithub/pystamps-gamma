# V5 — Final-C annual local denoising at original 4:1 resolution

This round targets the remaining local/high-frequency noise in the annual
Final-C velocity maps.

It does **not** change the processing resolution.

## Resolution guarantee

V5 preserves:

```text
same 375,051 PS positions
same existing Final-C GeoTIFF width / height
same transform
same CRS
same 4:1 processing-resolution product geometry
```

It does **not** create a 250 m, 500 m, or 1000 m aggregated product.

The 500–1500 m values used inside the algorithm are only **neighborhood support
radii** for the local regression. They are not output pixel sizes.

## Method

At every original PS:

```text
neighbor PS
    ↓
distance weight
× coh_ps reliability weight
× Huber robust residual weight
    ↓
local linear plane
    ↓
quality-adaptive correction
    ↓
same original PS location
```

High-quality PS remain close to their original Final-C value. Low-quality PS
receive a stronger correction from the robust local plane.

The local plane preserves a first-order deformation gradient and is therefore
safer than a mean/Gaussian filter.

## What remains unchanged

```text
Final-C displacement time series : unchanged
full-period velocity             : unchanged
PS coordinates                   : unchanged
Stage6/7/8                       : unchanged
reference frame                  : unchanged
```

Only annual velocity is regularized.

The filter correction is constrained to have zero median correction over the
established exact 65 reference PS. This preserves the existing reference frame
without annual re-zeroing.

## Install

```bash
cd /home/ubuntu/software/pystamps-main

rm -rf /tmp/finalC_v5
mkdir -p /tmp/finalC_v5

unzip /上传目录/finalC_local_denoise_v5.zip \
  -d /tmp/finalC_v5

bash \
  /tmp/finalC_v5/finalC_local_denoise_v5/install.sh
```

Run:

```bash
cd /home/ubuntu/software/pystamps-main

./run_finalC_local_denoise_v5.sh
```

The first run builds a reusable KNN cache:

```text
<dataset>/_finalC_local_denoise_cache_v5/
```

## Parameter screen

The script tests compact local-plane configurations:

```text
K24 / R500
K32 / R750
K48 / R750
K48 / R1000
K64 / R1000
K64 / R1500
```

with correction strengths:

```text
0.50
0.75
1.00
```

`R` is a neighborhood support radius, **not raster resolution**.

The best few candidates are evaluated on all matched 2021/2022/2023 truth
points. A leave-one-year-out diagnostic is then used for parameter stability.

## First outputs to inspect

```bash
D=/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized

LATEST=$(
  find "$D/_audit" \
    -maxdepth 1 \
    -type d \
    -name 'finalC_local_denoise_v5_*' \
    -printf '%T@ %p\n' |
  sort -nr |
  head -1 |
  cut -d' ' -f2-
)

echo "===== FULL VALIDATION ====="
column -s, -t "$LATEST/02_full_validation.csv"

echo "===== CORRECTION ====="
column -s, -t "$LATEST/03_correction_validation.csv"

echo "===== LOYO ====="
column -s, -t "$LATEST/04_leave_one_year_out.csv"

echo "===== LARGE-SCALE PLANE ====="
column -s, -t "$LATEST/05_large_scale_plane_preservation.csv"

echo "===== DECISION ====="
cat "$LATEST/06_DECISION.json"
```

If the validation guardrails pass, the output product is:

```text
same_resolution_product/
├── annual_velocity_same_4x1_resolution_points.npz
├── local_filter_diagnostics.npz
├── full_period_velocity_UNCHANGED.tif
├── annual_velocity/
│   └── annual_velocity_YYYY.tif
├── annual_correction/
│   └── annual_correction_YYYY.tif
└── RASTER_RESOLUTION.json
```
