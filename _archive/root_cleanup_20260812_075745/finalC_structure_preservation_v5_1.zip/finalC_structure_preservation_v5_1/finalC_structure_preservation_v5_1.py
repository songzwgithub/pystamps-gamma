#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
V5.1 — Final-C annual denoising structure-preservation audit.

Requires the already-installed V5:
    /home/ubuntu/software/pystamps-main/tools/finalC_local_denoise_v5.py

This round DOES NOT search for stronger smoothing. It compares only:
    K48_R750_L1.00
    K64_R1000_L1.00
    K64_R1500_L1.00

Selection:
1) Find the best pooled 2021–2023 truth RMSE.
2) Define near-best:
       RMSE <= best + max(0.05 mm/yr, 0.5% * best)
3) Among near-best choose the SMALLEST radius, then smaller K/h.
4) Require every validation year to improve >=5%, large-scale plane-gradient
   magnitude change <=3%, and strict final correction cap <=20 mm/yr.

Resolution:
- same original PS positions;
- same existing 4:1 Final-C raster geometry;
- no aggregation/downsampling;
- R is neighborhood support radius, NOT output resolution;
- full-period velocity and displacement time series remain unchanged.

V5.1 also fixes the V5 final-cap ordering:
    local correction -> reference correction zeroing -> FINAL clip
so the final written correction itself cannot exceed +/- cap.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import gc
import importlib.util
import json
import math
import os
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Sequence

import numpy as np
from scipy.spatial import cKDTree


def load_v5(root: Path):
    p = root / "tools" / "finalC_local_denoise_v5.py"
    if not p.exists():
        raise FileNotFoundError(
            f"Required installed V5 not found: {p}\n"
            "Install/run V5 first."
        )
    spec = importlib.util.spec_from_file_location("finalC_local_denoise_v5_installed", p)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {p}")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def configs():
    return [
        dict(
            name="K48_R750_L1.00", k=48, radius_m=750.0, h_m=450.0,
            lambda_=1.0, gamma=1.5, quality_power=1.0,
            huber_k=1.5, irls_iterations=2, min_neighbors=10,
        ),
        dict(
            name="K64_R1000_L1.00", k=64, radius_m=1000.0, h_m=600.0,
            lambda_=1.0, gamma=1.5, quality_power=1.0,
            huber_k=1.5, irls_iterations=2, min_neighbors=10,
        ),
        dict(
            name="K64_R1500_L1.00", k=64, radius_m=1500.0, h_m=900.0,
            lambda_=1.0, gamma=1.5, quality_power=1.0,
            huber_k=1.5, irls_iterations=2, min_neighbors=10,
        ),
    ]


def cfg_for_v5(c):
    return {
        "name": c["name"],
        "k": c["k"],
        "radius_m": c["radius_m"],
        "h_m": c["h_m"],
        "lambda": c["lambda_"],
        "gamma": c["gamma"],
        "quality_power": c["quality_power"],
        "huber_k": c["huber_k"],
        "irls_iterations": c["irls_iterations"],
        "min_neighbors": c["min_neighbors"],
    }


def filter_centers_v51(
    v5,
    values,
    centers,
    knn_idx,
    knn_dist,
    x,
    y,
    quality,
    ref_ids,
    c,
    block_centers,
    cap,
):
    cfg = cfg_for_v5(c)
    centers = np.asarray(centers, dtype=np.int64)

    # Determine the filter correction over exact reference PS using the same kernel.
    ref_local, _, _, _, ref_solved = v5.robust_local_plane_chunk(
        values, ref_ids, knn_idx, knn_dist, x, y, quality,
        k=cfg["k"], radius_m=cfg["radius_m"], h_m=cfg["h_m"],
        quality_power=cfg["quality_power"], huber_k=cfg["huber_k"],
        irls_iterations=cfg["irls_iterations"], min_neighbors=cfg["min_neighbors"],
    )
    qref = np.asarray(quality[ref_ids], float)
    rawref = np.asarray(values[ref_ids], float)
    sref = cfg["lambda"] * (1.0 - qref) ** cfg["gamma"]
    dref = sref * (ref_local - rawref)
    ref_shift = (
        float(np.nanmedian(dref[ref_solved]))
        if np.any(ref_solved) else 0.0
    )

    out = np.full(len(centers), np.nan, np.float32)
    corr = np.full(len(centers), np.nan, np.float32)
    nnei = np.zeros(len(centers), np.int16)

    for r0 in range(0, len(centers), block_centers):
        r1 = min(len(centers), r0 + block_centers)
        ids = centers[r0:r1]

        loc, _, _, nvalid, solved = v5.robust_local_plane_chunk(
            values, ids, knn_idx, knn_dist, x, y, quality,
            k=cfg["k"], radius_m=cfg["radius_m"], h_m=cfg["h_m"],
            quality_power=cfg["quality_power"], huber_k=cfg["huber_k"],
            irls_iterations=cfg["irls_iterations"], min_neighbors=cfg["min_neighbors"],
        )

        raw = np.asarray(values[ids], float)
        qc = np.asarray(quality[ids], float)
        strength = cfg["lambda"] * (1.0 - qc) ** cfg["gamma"]

        delta = strength * (loc - raw)
        delta[~solved] = 0.0

        # V5.1: preserve reference first, then strictly apply FINAL cap.
        delta = delta - ref_shift
        if cap > 0:
            delta = np.clip(delta, -cap, cap)

        out[r0:r1] = (raw + delta).astype(np.float32)
        corr[r0:r1] = delta.astype(np.float32)
        nnei[r0:r1] = nvalid.astype(np.int16)

    return out, corr, nnei, ref_shift


def effective_support(knn_dist, c, n_ps, sample_n, seed):
    rng = np.random.default_rng(seed)
    ids = (
        np.arange(n_ps, dtype=np.int64)
        if sample_n >= n_ps
        else np.sort(rng.choice(n_ps, sample_n, replace=False))
    )
    d = np.asarray(knn_dist[ids, :c["k"]], float)
    n = np.sum(np.isfinite(d) & (d <= c["radius_m"]), axis=1)
    kth = d[:, c["k"] - 1]
    return {
        "config": c["name"],
        "sample_n": len(ids),
        "k": c["k"],
        "radius_m": c["radius_m"],
        "h_m": c["h_m"],
        "neighbors_within_radius_p10": float(np.percentile(n, 10)),
        "neighbors_within_radius_median": float(np.median(n)),
        "neighbors_within_radius_p90": float(np.percentile(n, 90)),
        "fraction_full_k_within_radius": float(np.mean(kth <= c["radius_m"])),
        "kth_neighbor_distance_p50_m": float(np.percentile(kth, 50)),
        "kth_neighbor_distance_p90_m": float(np.percentile(kth, 90)),
        "kth_neighbor_distance_p95_m": float(np.percentile(kth, 95)),
    }


def plane_metric(v5, raw, fil, x, y, year, name):
    br = v5.fit_global_plane(raw, x, y)
    bf = v5.fit_global_plane(fil, x, y)
    gr = float(np.hypot(br[1], br[2]))
    gf = float(np.hypot(bf[1], bf[2]))
    return {
        "config": name,
        "year": year,
        "raw_x_mm_yr_per_100km": float(br[1]),
        "raw_y_mm_yr_per_100km": float(br[2]),
        "filtered_x_mm_yr_per_100km": float(bf[1]),
        "filtered_y_mm_yr_per_100km": float(bf[2]),
        "raw_gradient_magnitude": gr,
        "filtered_gradient_magnitude": gf,
        "gradient_magnitude_relative_change": (
            float((gf - gr) / gr) if gr > 0 else np.nan
        ),
    }


def extrema_rows(raw, fil, year, name):
    rows = []
    for label, a in [("RAW", raw), ("FILTERED", fil)]:
        v = np.asarray(a, float)
        v = v[np.isfinite(v)]
        p = np.percentile(v, [2, 5, 50, 95, 98])
        rows.append({
            "config": name, "year": year, "field": label, "n": len(v),
            "p02": float(p[0]), "p05": float(p[1]), "median": float(p[2]),
            "p95": float(p[3]), "p98": float(p[4]),
            "p95_minus_p05": float(p[3] - p[1]),
            "p98_minus_p02": float(p[4] - p[0]),
        })
    return rows


def quality_quartile_rows(corr, quality, year, name):
    q = np.asarray(quality, float)
    d = np.asarray(corr, float)
    good = np.isfinite(q) & np.isfinite(d)
    q, d = q[good], d[good]
    qe = np.quantile(q, [0, .25, .5, .75, 1])
    rows = []
    for i in range(4):
        if i < 3:
            m = (q >= qe[i]) & (q < qe[i+1])
        else:
            m = (q >= qe[i]) & (q <= qe[i+1])
        z = np.abs(d[m])
        rows.append({
            "config": name, "year": year, "quality_quartile": i+1,
            "quality_min": float(qe[i]), "quality_max": float(qe[i+1]),
            "n": int(len(z)),
            "median_abs_correction": float(np.median(z)),
            "p90_abs_correction": float(np.percentile(z, 90)),
            "p95_abs_correction": float(np.percentile(z, 95)),
        })
    return rows


def build_edges(knn_idx, knn_dist, n_ps, center_n, nbr_n, seed):
    rng = np.random.default_rng(seed)
    centers = (
        np.arange(n_ps, dtype=np.int64)
        if center_n >= n_ps
        else np.sort(rng.choice(n_ps, center_n, replace=False))
    )
    nbr = np.asarray(knn_idx[centers, :nbr_n], np.int64)
    dist = np.asarray(knn_dist[centers, :nbr_n], float)
    a = np.repeat(centers, nbr_n)
    b = nbr.ravel()
    d = dist.ravel()
    good = np.isfinite(d) & (d > 0) & (d <= 1500) & (a != b)
    a, b, d = a[good], b[good], d[good]
    lo = np.minimum(a, b)
    hi = np.maximum(a, b)
    order = np.lexsort((hi, lo))
    lo, hi, d = lo[order], hi[order], d[order]
    keep = np.ones(len(lo), dtype=bool)
    if len(lo) > 1:
        keep[1:] = (lo[1:] != lo[:-1]) | (hi[1:] != hi[:-1])
    return lo[keep], hi[keep], d[keep]


def detail_rows(raw, fil, ea, eb, ed, year, name):
    bands = [
        (0, 250, "0_250m"),
        (250, 500, "250_500m"),
        (500, 1000, "500_1000m"),
        (1000, 1500, "1000_1500m"),
    ]
    rows = []
    raw = np.asarray(raw, float)
    fil = np.asarray(fil, float)
    for lo, hi, label in bands:
        m = (ed > lo) & (ed <= hi)
        if not np.any(m):
            continue
        a, b, dist = ea[m], eb[m], ed[m]
        dr = raw[a] - raw[b]
        df = fil[a] - fil[b]
        good = np.isfinite(dr) & np.isfinite(df)
        dr, df, dist = dr[good], df[good], dist[good]
        if len(dr) < 10:
            continue
        ar, af = np.abs(dr), np.abs(df)
        mr, mf = np.median(ar), np.median(af)
        p90r, p90f = np.percentile(ar, 90), np.percentile(af, 90)
        gr = ar / np.maximum(dist / 1000.0, 1e-6)
        gf = af / np.maximum(dist / 1000.0, 1e-6)
        rows.append({
            "config": name, "year": year, "distance_band": label,
            "n_edges": len(dr),
            "raw_median_abs_pairdiff": float(mr),
            "filtered_median_abs_pairdiff": float(mf),
            "median_pairdiff_retention_ratio": float(mf/mr) if mr > 0 else np.nan,
            "raw_p90_abs_pairdiff": float(p90r),
            "filtered_p90_abs_pairdiff": float(p90f),
            "p90_pairdiff_retention_ratio": float(p90f/p90r) if p90r > 0 else np.nan,
            "raw_median_abs_gradient_mm_yr_per_km": float(np.median(gr)),
            "filtered_median_abs_gradient_mm_yr_per_km": float(np.median(gf)),
            "gradient_retention_ratio": (
                float(np.median(gf)/np.median(gr)) if np.median(gr) > 0 else np.nan
            ),
        })
    return rows


def prepare_truth(v5, truth_dir, years, ps_xy, ps_bbox, lon0, lat0, refx, refy, args):
    truth = {}
    for year in years:
        p = truth_dir / f"result{year}.shp"
        tx, ty, tv_raw, vf = v5.read_truth_cropped(
            p, args.truth_field, args.truth_scale, lon0, lat0,
            ps_bbox, args.truth_buffer_m,
        )
        tree = cKDTree(np.column_stack([tx, ty]))
        rid = np.asarray(
            tree.query_ball_point([refx, refy], r=args.reference_radius_m),
            np.int64,
        )
        if len(rid) < 10:
            raise RuntimeError(f"{year}: too few truth points in reference region")
        tref = float(np.nanmedian(tv_raw[rid]))
        tv = tv_raw - tref
        pidx, tidx, dist = v5.unique_ps_truth_mapping(
            ps_xy, np.column_stack([tx, ty]), args.match_m
        )
        truth[year] = dict(v=tv, pidx=pidx, tidx=tidx, truth_ref=tref)
        print(f"truth {year}: matched={len(pidx)}, ref={tref:.4f}")
    return truth


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--root", default="/home/ubuntu/software/pystamps-main")
    p.add_argument(
        "--dataset",
        default="/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized",
    )
    p.add_argument("--truth-dir", default="")
    p.add_argument("--truth-field", default="v")
    p.add_argument("--truth-scale", type=float, default=1.0)
    p.add_argument("--match-m", type=float, default=200.0)
    p.add_argument("--truth-buffer-m", type=float, default=1500.0)
    p.add_argument("--reference-lon", type=float, default=117.21775055)
    p.add_argument("--reference-lat", type=float, default=38.40310669)
    p.add_argument("--reference-radius-m", type=float, default=500.0)

    p.add_argument("--correction-cap-mm-yr", type=float, default=20.0)
    p.add_argument("--near-best-abs-mm-yr", type=float, default=0.05)
    p.add_argument("--near-best-rel", type=float, default=0.005)
    p.add_argument("--min-each-year-improvement", type=float, default=0.05)
    p.add_argument("--max-plane-gradient-relative-change", type=float, default=0.03)

    p.add_argument("--block-centers", type=int, default=5000)
    p.add_argument("--support-sample", type=int, default=100000)
    p.add_argument("--structure-centers", type=int, default=100000)
    p.add_argument("--structure-neighbors", type=int, default=8)

    p.add_argument("--out", default="")
    p.add_argument("--cache-dir", default="")
    p.add_argument("--always-write-product", action="store_true")
    p.add_argument("--no-write-tifs", action="store_true")
    p.add_argument(
        "--raster-template",
        default="postprocess/rasters/geo_velocity.tif",
    )
    p.add_argument("--seed", type=int, default=20260812)
    p.add_argument("--self-test", action="store_true")
    return p.parse_args()


def self_test():
    c = np.clip(np.array([20.0, -20.0, 5.0]) - 2.0, -20.0, 20.0)
    assert np.allclose(c, [18.0, -20.0, 3.0])
    cc = configs()
    assert [x["radius_m"] for x in cc] == [750.0, 1000.0, 1500.0]
    print("SELF-TEST: PASS")


def main():
    args = parse_args()
    if args.self_test:
        self_test()
        return

    t0 = time.time()
    root = Path(args.root).resolve()
    v5 = load_v5(root)

    dataset = Path(args.dataset).resolve()
    truth_dir = Path(args.truth_dir).resolve() if args.truth_dir else dataset / "cangzhou"
    final_dir = v5.find_latest_final_c(dataset)
    lon, lat, full_velocity, annual, final_npz = v5.load_final_c(final_dir)
    n_ps = len(lon)
    years = (2021, 2022, 2023)

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = (
        Path(args.out).resolve()
        if args.out
        else dataset / "_audit" / f"finalC_structure_preservation_v5_1_{stamp}"
    )
    out.mkdir(parents=True, exist_ok=True)

    print("="*80)
    print("V5.1 — SAME 4:1 GEOMETRY / STRUCTURE PRESERVATION")
    print("="*80)
    print("Final-C:", final_dir)
    print("n_ps   :", n_ps)
    print("Candidates: R750, R1000, R1500 only.")
    print("No aggregation / no downsampling.")

    x, y, lon0, lat0 = v5.local_xy(lon, lat)
    ps_xy = np.column_stack([x, y])
    ps_bbox = (float(x.min()), float(x.max()), float(y.min()), float(y.max()))

    coh_raw, coh_source = v5.load_coh_ps(dataset, n_ps)
    quality, quality_meta = v5.normalize_quality(coh_raw)
    ref_ids, ref_source = v5.exact_reference_indices(final_dir, n_ps)

    cache_dir = (
        Path(args.cache_dir).resolve()
        if args.cache_dir
        else dataset / "_finalC_local_denoise_cache_v5"
    )
    knn_idx, knn_dist, knn_meta = v5.build_or_reuse_knn_cache(
        cache_dir, x, y, 64, 25000
    )

    refx, refy = v5.lonlat_to_xy(
        args.reference_lon, args.reference_lat, lon0, lat0
    )
    truth = prepare_truth(
        v5, truth_dir, years, ps_xy, ps_bbox, lon0, lat0, refx, refy, args
    )

    support_rows = [
        effective_support(knn_dist, c, n_ps, args.support_sample, args.seed+i)
        for i, c in enumerate(configs())
    ]
    write_csv(out / "01_effective_support.csv", support_rows)

    print("Building spatial-detail edge sample ...")
    ea, eb, ed = build_edges(
        knn_idx, knn_dist, n_ps,
        args.structure_centers, args.structure_neighbors, args.seed
    )
    print("edges:", len(ea))

    # raw truth baseline
    raw_year = {}
    raw_pp, raw_tt = [], []
    for year in years:
        td = truth[year]
        p = annual[year][td["pidx"]]
        t = td["v"][td["tidx"]]
        raw_year[year] = v5.validation_metrics(p, t)
        g = np.isfinite(p) & np.isfinite(t)
        raw_pp.append(p[g]); raw_tt.append(t[g])
    raw_pooled = v5.validation_metrics(np.concatenate(raw_pp), np.concatenate(raw_tt))

    truth_rows, pooled_rows = [], []
    corr_rows, q_rows, ext_rows, plane_rows, spatial_rows = [], [], [], [], []
    cand_rmse = {}
    cand_pooled = {}
    filtered_3yr = {}
    all_ids = np.arange(n_ps, dtype=np.int64)

    for c in configs():
        name = c["name"]
        cand_rmse[name] = {}
        filtered_3yr[name] = {}
        pp, tt = [], []

        print("\nCANDIDATE:", name)
        for year in years:
            fil, corr, nnei, ref_shift = filter_centers_v51(
                v5, annual[year], all_ids,
                knn_idx, knn_dist, x, y, quality, ref_ids, c,
                args.block_centers, args.correction_cap_mm_yr,
            )
            filtered_3yr[name][year] = fil

            td = truth[year]
            pred = fil[td["pidx"]]
            tv = td["v"][td["tidx"]]
            mm = v5.validation_metrics(pred, tv)
            cand_rmse[name][year] = mm["rmse_mm_yr"]
            improve = (
                raw_year[year]["rmse_mm_yr"] - mm["rmse_mm_yr"]
            ) / raw_year[year]["rmse_mm_yr"]

            truth_rows.append({
                "config": name, "year": year, **mm,
                "raw_rmse_mm_yr": raw_year[year]["rmse_mm_yr"],
                "relative_rmse_improvement": improve,
            })
            g = np.isfinite(pred) & np.isfinite(tv)
            pp.append(pred[g]); tt.append(tv[g])

            corr_rows.append({
                "config": name, "year": year, "n": n_ps,
                "median_correction_mm_yr": float(np.nanmedian(corr)),
                "median_abs_correction_mm_yr": float(np.nanmedian(np.abs(corr))),
                "p90_abs_correction_mm_yr": float(np.nanpercentile(np.abs(corr), 90)),
                "p95_abs_correction_mm_yr": float(np.nanpercentile(np.abs(corr), 95)),
                "max_abs_correction_mm_yr": float(np.nanmax(np.abs(corr))),
                "fraction_at_final_cap": float(
                    np.mean(np.abs(corr) >= args.correction_cap_mm_yr - 1e-5)
                ),
                "reference_shift_removed_before_final_cap": ref_shift,
            })
            q_rows.extend(quality_quartile_rows(corr, quality, year, name))
            ext_rows.extend(extrema_rows(annual[year], fil, year, name))
            plane_rows.append(plane_metric(v5, annual[year], fil, x, y, year, name))
            spatial_rows.extend(detail_rows(annual[year], fil, ea, eb, ed, year, name))

            print(
                f" {year}: {raw_year[year]['rmse_mm_yr']:.3f}"
                f" -> {mm['rmse_mm_yr']:.3f}"
                f" ({100*improve:.2f}%)"
            )

            del corr, nnei
            gc.collect()

        pm = v5.validation_metrics(np.concatenate(pp), np.concatenate(tt))
        cand_pooled[name] = pm
        pooled_rows.append({
            "config": name, **pm,
            "raw_pooled_rmse_mm_yr": raw_pooled["rmse_mm_yr"],
            "relative_rmse_improvement": (
                raw_pooled["rmse_mm_yr"] - pm["rmse_mm_yr"]
            ) / raw_pooled["rmse_mm_yr"],
        })
        print(" pooled:", pm["rmse_mm_yr"])

    write_csv(out / "02_truth_by_year.csv", truth_rows)
    write_csv(out / "03_truth_pooled.csv", pooled_rows)
    write_csv(out / "04_correction_full_domain.csv", corr_rows)
    write_csv(out / "05_correction_by_quality_quartile.csv", q_rows)
    write_csv(out / "06_extrema_preservation.csv", ext_rows)
    write_csv(out / "07_large_scale_plane_preservation.csv", plane_rows)
    write_csv(out / "08_spatial_detail_retention.csv", spatial_rows)

    # Nested LOYO: the 3 candidates were fixed BEFORE this V5.1 run.
    loyo_rows, wins = [], {}
    for holdout in years:
        train = [y for y in years if y != holdout]
        ranking = sorted(
            (np.mean([cand_rmse[n][y] for y in train]), n)
            for n in cand_rmse
        )
        score, winner = ranking[0]
        wins[winner] = wins.get(winner, 0) + 1
        loyo_rows.append({
            "holdout_year": holdout,
            "train_years": "+".join(str(y) for y in train),
            "selected_config_training_only": winner,
            "train_mean_rmse_mm_yr": float(score),
            "holdout_rmse_mm_yr": float(cand_rmse[winner][holdout]),
        })
    write_csv(out / "09_nested_leave_one_year_out.csv", loyo_rows)

    # Near-best + minimal support selection.
    best_name = min(cand_pooled, key=lambda n: cand_pooled[n]["rmse_mm_yr"])
    best_rmse = cand_pooled[best_name]["rmse_mm_yr"]
    tol = max(args.near_best_abs_mm_yr, args.near_best_rel * best_rmse)
    near = [
        c for c in configs()
        if cand_pooled[c["name"]]["rmse_mm_yr"] <= best_rmse + tol
    ]
    selected = sorted(near, key=lambda c: (c["radius_m"], c["k"], c["h_m"]))[0]
    selected_name = selected["name"]

    year_imp = {}
    for year in years:
        year_imp[year] = (
            raw_year[year]["rmse_mm_yr"] - cand_rmse[selected_name][year]
        ) / raw_year[year]["rmse_mm_yr"]

    selected_planes = [
        r for r in plane_rows if r["config"] == selected_name
    ]
    max_plane_change = max(
        abs(float(r["gradient_magnitude_relative_change"]))
        for r in selected_planes
    )
    selected_corr = [r for r in corr_rows if r["config"] == selected_name]
    observed_cap = max(float(r["max_abs_correction_mm_yr"]) for r in selected_corr)

    pass_truth = min(year_imp.values()) >= args.min_each_year_improvement
    pass_plane = max_plane_change <= args.max_plane_gradient_relative_change
    pass_cap = observed_cap <= args.correction_cap_mm_yr + 1e-4
    eligible = pass_truth and pass_plane and pass_cap

    decision = {
        "raw_pooled_rmse_mm_yr": raw_pooled["rmse_mm_yr"],
        "truth_rmse_best_config": best_name,
        "truth_rmse_best_mm_yr": best_rmse,
        "near_best_tolerance_mm_yr": tol,
        "near_best_configs": [c["name"] for c in near],
        "selection_rule": (
            "Choose smallest radius/K/h among candidates within the near-best "
            "truth-RMSE tolerance."
        ),
        "selected_conservative_config": selected,
        "selected_pooled_rmse_mm_yr": cand_pooled[selected_name]["rmse_mm_yr"],
        "selected_relative_improvement_by_year": year_imp,
        "nested_loyo_wins": wins,
        "max_large_scale_gradient_relative_change": max_plane_change,
        "observed_max_abs_final_correction_mm_yr": observed_cap,
        "guardrails": {
            "pass_truth": pass_truth,
            "pass_plane": pass_plane,
            "pass_strict_final_cap": pass_cap,
        },
        "eligible_for_product": bool(eligible),
        "resolution_policy": (
            "Same original PS positions and same existing Final-C 4:1 raster "
            "geometry; no coarse-grid aggregation or resampling."
        ),
    }
    (out / "10_DECISION.json").write_text(
        json.dumps(decision, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("\nDECISION")
    print(json.dumps(decision, ensure_ascii=False, indent=2))

    # Write only conservatively selected product.
    product_dir = None
    if eligible or args.always_write_product:
        product_dir = out / "same_4x1_resolution_product"
        product_dir.mkdir(parents=True, exist_ok=True)

        annual_fil, annual_corr = {}, {}
        for year in sorted(annual):
            if year in years:
                fil = filtered_3yr[selected_name][year]
                corr = fil - np.asarray(annual[year], np.float32)
            else:
                print("product year", year)
                fil, corr, _, _ = filter_centers_v51(
                    v5, annual[year], all_ids,
                    knn_idx, knn_dist, x, y, quality, ref_ids, selected,
                    args.block_centers, args.correction_cap_mm_yr,
                )
            annual_fil[year] = np.asarray(fil, np.float32)
            annual_corr[year] = np.asarray(corr, np.float32)

        payload = {
            "ps_index_1based": np.arange(1, n_ps+1, dtype=np.int32),
            "lon": lon.astype(np.float64),
            "lat": lat.astype(np.float64),
            "full_velocity_mm_yr": full_velocity.astype(np.float32),
            "coh_ps": coh_raw.astype(np.float32),
            "quality_normalized": quality.astype(np.float32),
        }
        for year in sorted(annual):
            payload[f"velocity_{year}_mm_yr"] = annual_fil[year]
            payload[f"correction_{year}_mm_yr"] = annual_corr[year]
        np.savez_compressed(
            product_dir / "annual_velocity_structure_preserved_same_4x1_points.npz",
            **payload
        )

        if not args.no_write_tifs:
            fallback = Path(args.raster_template)
            if not fallback.is_absolute():
                fallback = dataset / fallback
            template = v5.choose_raster_template(final_dir, fallback)
            psidx, flat, profile, width, height = v5.raster_assignment(
                lon, lat, template
            )
            tags = {
                "method": "V5.1 structure-preserving robust local plane",
                "selected_config": selected_name,
                "source_final_C": str(final_dir),
                "original_4x1_raster_geometry_preserved": "yes",
                "aggregation": "none",
                "resampling": "none",
                "full_period_velocity_changed": "no",
                "time_series_changed": "no",
                "neighborhood_radius_is_not_output_resolution": "yes",
            }
            v5.write_ps_median_tif(
                product_dir / "full_period_velocity_UNCHANGED.tif",
                full_velocity, psidx, flat, profile, width, height,
                {**tags, "band_description": "full_period_velocity_mm_per_year"}
            )
            for year in sorted(annual):
                v5.write_ps_median_tif(
                    product_dir / "annual_velocity" / f"annual_velocity_{year}.tif",
                    annual_fil[year], psidx, flat, profile, width, height,
                    {**tags, "year": year, "band_description": "annual_velocity_mm_per_year"}
                )
                v5.write_ps_median_tif(
                    product_dir / "annual_correction" / f"annual_correction_{year}.tif",
                    annual_corr[year], psidx, flat, profile, width, height,
                    {**tags, "year": year, "band_description": "annual_correction_mm_per_year"}
                )
            (product_dir / "RASTER_RESOLUTION.json").write_text(
                json.dumps({
                    "template": str(template),
                    "width": width,
                    "height": height,
                    "transform": list(profile["transform"])[:6],
                    "crs": str(profile.get("crs")),
                    "selected_config": selected_name,
                    "note": "Exact existing raster geometry; no coarse-grid output."
                }, ensure_ascii=False, indent=2),
                encoding="utf-8"
            )

    (out / "MANIFEST.json").write_text(
        json.dumps({
            "version": "finalC_structure_preservation_v5_1",
            "dataset": str(dataset),
            "source_final_C": str(final_dir),
            "source_velocity_npz": str(final_npz),
            "n_ps": n_ps,
            "quality_source": coh_source,
            "quality_normalization": quality_meta,
            "reference_source": ref_source,
            "knn_cache": str(cache_dir),
            "knn_meta": knn_meta,
            "fixed_candidates": configs(),
            "decision": decision,
            "product_dir": str(product_dir) if product_dir else None,
            "runtime_seconds": time.time()-t0,
        }, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    print("\nV5.1 COMPLETE")
    print("runtime:", f"{time.time()-t0:.1f}s")
    print("output :", out)
    print("product:", product_dir)
    print("\nInspect:")
    for p in [
        out/"01_effective_support.csv",
        out/"03_truth_pooled.csv",
        out/"04_correction_full_domain.csv",
        out/"07_large_scale_plane_preservation.csv",
        out/"08_spatial_detail_retention.csv",
        out/"09_nested_leave_one_year_out.csv",
        out/"10_DECISION.json",
    ]:
        print(" ", p)


if __name__ == "__main__":
    main()
