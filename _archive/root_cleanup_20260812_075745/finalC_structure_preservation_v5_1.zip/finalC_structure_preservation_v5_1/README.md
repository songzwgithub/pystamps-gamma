# V5.1 — keep 4:1 geometry, choose minimum necessary spatial support

V5.1 compares only three already-established candidates:

```text
K48_R750_L1.00
K64_R1000_L1.00
K64_R1500_L1.00
```

It does **not** search larger radii or stronger smoothing.

The output remains at the original PS locations and copies the existing Final-C
GeoTIFF geometry exactly. `R=1000 m` is a local support radius, not a 1000 m
output pixel.

## New checks

- actual 48th/64th-neighbor distances;
- strict final correction cap;
- correction by quality quartile;
- P02/P05/P95/P98 preservation;
- large-scale plane-gradient preservation;
- pairwise spatial-detail retention at:
  - 0–250 m
  - 250–500 m
  - 500–1000 m
  - 1000–1500 m
- nested leave-one-year-out among the three fixed candidates.

## Conservative selection

A candidate is near-best when:

```text
RMSE <= best + max(0.05 mm/yr, 0.5% * best)
```

Among near-best candidates, V5.1 chooses the smallest radius, then smaller K/h.

This is intentionally designed to choose R1000 instead of R1500 if the RMSE
difference is negligible.

## V5 correction-cap fix

V5 used:

```text
clip -> reference correction
```

so the final value could exceed ±20 mm/yr.

V5.1 uses:

```text
reference correction -> FINAL clip
```

so the final written correction is strictly bounded.

## Install

```bash
cd /home/ubuntu/software/pystamps-main

rm -rf /tmp/finalC_v5_1
mkdir -p /tmp/finalC_v5_1

unzip /上传目录/finalC_structure_preservation_v5_1.zip \
  -d /tmp/finalC_v5_1

bash \
  /tmp/finalC_v5_1/finalC_structure_preservation_v5_1/install.sh
```

Run:

```bash
cd /home/ubuntu/software/pystamps-main
./run_finalC_structure_preservation_v5_1.sh
```

It reuses:

```text
<dataset>/_finalC_local_denoise_cache_v5/
```

## Inspect

```bash
D=/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized

LATEST=$(
  find "$D/_audit" \
    -maxdepth 1 \
    -type d \
    -name 'finalC_structure_preservation_v5_1_*' \
    -printf '%T@ %p\n' |
  sort -nr |
  head -1 |
  cut -d' ' -f2-
)

column -s, -t "$LATEST/01_effective_support.csv"
column -s, -t "$LATEST/03_truth_pooled.csv"
column -s, -t "$LATEST/04_correction_full_domain.csv"
column -s, -t "$LATEST/07_large_scale_plane_preservation.csv"
column -s, -t "$LATEST/08_spatial_detail_retention.csv" | less -S
column -s, -t "$LATEST/09_nested_leave_one_year_out.csv"
cat "$LATEST/10_DECISION.json"
```

If guardrails pass, only the conservative selected candidate is written to:

```text
same_4x1_resolution_product/
```

Full-period velocity and the original displacement time series are unchanged.
