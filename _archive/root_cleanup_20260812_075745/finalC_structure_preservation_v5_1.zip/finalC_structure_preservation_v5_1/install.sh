#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/home/ubuntu/software/pystamps-main}"
PYTHON="${PYTHON:-/home/ubuntu/software/miniconda3/envs/stamps/bin/python}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

V5="$ROOT/tools/finalC_local_denoise_v5.py"
[[ -f "$V5" ]] || {
  echo "ERROR: installed V5 dependency not found:" >&2
  echo "  $V5" >&2
  echo "Install the previous V5 bundle first." >&2
  exit 4
}

mkdir -p "$ROOT/tools"

cp "$HERE/finalC_structure_preservation_v5_1.py" \
   "$ROOT/tools/finalC_structure_preservation_v5_1.py"
cp "$HERE/run_finalC_structure_preservation_v5_1.sh" \
   "$ROOT/run_finalC_structure_preservation_v5_1.sh"

chmod +x "$ROOT/tools/finalC_structure_preservation_v5_1.py"
chmod +x "$ROOT/run_finalC_structure_preservation_v5_1.sh"

echo "Installed V5.1."
echo "Existing V5 is only imported; it is not overwritten."
echo "Stage6/7/8, Final-C, time series, and environment are untouched."

echo
echo "Self-test:"
"$ROOT/run_finalC_structure_preservation_v5_1.sh" --self-test

echo
echo "Run:"
echo "  cd '$ROOT'"
echo "  ./run_finalC_structure_preservation_v5_1.sh"

if [[ "${1:-}" == "--run" ]]; then
  shift
  exec "$ROOT/run_finalC_structure_preservation_v5_1.sh" "$@"
fi
