#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
IFG network quality selection + conservative network protection + SBAS/WLS inversion for the customized pySTAMPS/GAMMA project.

Design goals
------------
1. Do NOT use temporal/perpendicular baseline for quality screening here; the user's
   IFG generation step has already constrained them.
2. IFG hard-deletion evidence uses three independent families only:
     - wrapped-phase spatial continuity
     - per-IFG coherence / effective coherence ratio when GAMMA coherence rasters
       can be mapped reliably
     - ifg_std (global IFG noise)
   Network residual consistency is diagnostic only and NEVER casts a hard-delete vote,
   because multilook-induced non-closure is known in this dataset.
3. Conservative dynamic graph protection:
     - never disconnect the acquisition network
     - do not reduce a node below the original minimum degree floor (default >= 3)
     - do not create any new bridge edge when the original network has none
     - weak edges necessary for 2-edge robustness are retained and labelled
4. Inversion:
     - standard uniform least squares (SBAS-like connected-network LS)
     - inverse-ifg_std WLS
     - multi-quality WLS (diagnostic extension)
5. Uses the same fixed reference region for all branches.
6. Existing ramp/SCN fields are used only as explicitly labelled downstream
   compatibility diagnostics; they were estimated from the current production chain
   and are not claimed to be re-estimated self-consistently for a new network solution.
7. Reads sources only; writes to a new output directory. Existing Final-C and Stage6
   checkpoints are never modified.

This is deliberately self-contained and does not install or import MintPy.
It implements the mature concepts (quality-driven network modification,
connectivity protection, uniform/WLS network inversion) without changing the
existing conda environment.

The default dataset paths are specific to the user's current Cangzhou project.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import gc
import json
import math
import os
import re
import shutil
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import numpy as np
from scipy.io import loadmat, whosmat
from scipy.spatial import cKDTree


# =============================================================================
# Generic utilities
# =============================================================================

def norm_key(x: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(x).lower())


def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    for row in rows:
        for k in row:
            if k not in fields:
                fields.append(k)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def local_xy(lon, lat, lon0=None, lat0=None):
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    if lon0 is None:
        lon0 = float(np.nanmedian(lon))
    if lat0 is None:
        lat0 = float(np.nanmedian(lat))
    R = 6371008.8
    x = np.deg2rad(lon - lon0) * R * math.cos(math.radians(lat0))
    y = np.deg2rad(lat - lat0) * R
    return x, y, float(lon0), float(lat0)


def lonlat_to_xy(lon, lat, lon0, lat0):
    R = 6371008.8
    x = math.radians(lon - lon0) * R * math.cos(math.radians(lat0))
    y = math.radians(lat - lat0) * R
    return x, y


def matlab_datenum_to_datetime(v: float) -> dt.datetime:
    ordinal = int(v)
    frac = float(v) - ordinal
    return (
        dt.datetime.fromordinal(ordinal)
        + dt.timedelta(days=frac)
        - dt.timedelta(days=366)
    )


def find_wavelength(project: Path) -> Tuple[float, str]:
    c = 299792458.0
    candidates = (
        list((project / "RSLC_cropped").glob("*.rslc.par"))
        + list(project.rglob("*.rslc.par"))
    )
    for p in candidates[:300]:
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
            m = re.search(r"radar_frequency:\s*([0-9.eE+-]+)", text)
            if m:
                f = float(m.group(1))
                if f > 1e8:
                    return c / f, str(p)
        except Exception:
            pass
    # Sentinel-1 C-band fallback only if automatic discovery fails.
    # This value is also checked against the current project's prior results.
    return 0.0554657595, "fallback_Sentinel1_C_band"


def mat_is_hdf5(path: Path) -> bool:
    try:
        import h5py
        with h5py.File(path, "r"):
            return True
    except Exception:
        return False


def classic_load_var(path: Path, name: str) -> np.ndarray:
    obj = loadmat(
        path,
        variable_names=[name],
        squeeze_me=False,
        struct_as_record=False,
    )
    if name not in obj:
        raise KeyError(f"{path}:{name} not found")
    return np.asarray(obj[name])


class MatrixReader:
    """Read row blocks from either HDF5-v7.3 or classic MAT.

    Classic MAT variables must be loaded into RAM once; HDF5 is read blockwise.
    """

    def __init__(self, path: Path, var: str, nrow: int, ncol: int):
        self.path = Path(path)
        self.var = var
        self.nrow = int(nrow)
        self.ncol = int(ncol)
        self.hdf5 = mat_is_hdf5(self.path)
        self._classic = None
        self._transposed = False

        if self.hdf5:
            import h5py
            with h5py.File(self.path, "r") as h:
                if var not in h:
                    raise KeyError(f"{self.path}:{var} not found")
                shape = tuple(int(v) for v in h[var].shape)
            if shape == (nrow, ncol):
                self._transposed = False
            elif shape == (ncol, nrow):
                self._transposed = True
            else:
                raise ValueError(
                    f"{self.path}:{var} shape={shape}; expected "
                    f"({nrow},{ncol}) or ({ncol},{nrow})"
                )
        else:
            a = classic_load_var(self.path, var)
            if a.shape == (nrow, ncol):
                self._classic = a
                self._transposed = False
            elif a.shape == (ncol, nrow):
                self._classic = a
                self._transposed = True
            else:
                raise ValueError(
                    f"{self.path}:{var} shape={a.shape}; expected "
                    f"({nrow},{ncol}) or ({ncol},{nrow})"
                )

    def rows(self, idx: np.ndarray, cols: Optional[np.ndarray] = None) -> np.ndarray:
        idx = np.asarray(idx, dtype=np.int64)
        if cols is not None:
            cols = np.asarray(cols, dtype=np.int64)

        if self.hdf5:
            import h5py
            # h5py advanced indices must be sorted/unique.  Caller generally provides
            # sorted indices; preserve arbitrary order with a reorder map.
            order = np.argsort(idx)
            sidx = idx[order]
            if np.any(np.diff(sidx) == 0):
                raise ValueError("MatrixReader.rows requires unique row indices")
            with h5py.File(self.path, "r") as h:
                ds = h[self.var]
                if not self._transposed:
                    a = np.asarray(ds[sidx, :])
                else:
                    # HDF5 MATLAB datasets can be transposed.
                    a = np.asarray(ds[:, sidx]).T
            inv = np.empty_like(order)
            inv[order] = np.arange(len(order))
            a = a[inv]
        else:
            a = self._classic.T if self._transposed else self._classic
            a = np.asarray(a[idx, :])

        if cols is not None:
            a = a[:, cols]
        return a

    def block(self, r0: int, r1: int, cols: Optional[np.ndarray] = None) -> np.ndarray:
        if self.hdf5:
            import h5py
            with h5py.File(self.path, "r") as h:
                ds = h[self.var]
                if not self._transposed:
                    a = np.asarray(ds[r0:r1, :])
                else:
                    a = np.asarray(ds[:, r0:r1]).T
        else:
            a0 = self._classic.T if self._transposed else self._classic
            a = np.asarray(a0[r0:r1, :])
        if cols is not None:
            a = a[:, np.asarray(cols, dtype=np.int64)]
        return a


# =============================================================================
# Dataset metadata
# =============================================================================

def load_ps_metadata(dataset: Path):
    ps2 = loadmat(
        dataset / "ps2.mat",
        squeeze_me=True,
        struct_as_record=False,
    )
    n_ps = int(np.asarray(ps2["n_ps"]).reshape(-1)[0])
    n_image = int(np.asarray(ps2["n_image"]).reshape(-1)[0])

    lonlat = np.asarray(ps2["lonlat"], dtype=float)
    if lonlat.shape[0] != n_ps:
        lonlat = lonlat.T
    if lonlat.shape[0] != n_ps or lonlat.shape[1] < 2:
        raise ValueError(f"ps2.lonlat unexpected shape {lonlat.shape}")
    lon = lonlat[:, 0]
    lat = lonlat[:, 1]

    ij = np.asarray(ps2.get("ij")) if "ij" in ps2 else None
    if ij is not None:
        ij = np.squeeze(ij)
        if ij.ndim == 2 and ij.shape[0] != n_ps and ij.shape[1] == n_ps:
            ij = ij.T

    return n_ps, n_image, lon, lat, ij


def load_network(dataset: Path, n_image: int):
    path = dataset / "phuw_sm2.mat"
    vars_needed = ["ifgday_ix", "day"]
    obj = loadmat(
        path,
        variable_names=vars_needed,
        squeeze_me=True,
        struct_as_record=False,
    )
    if "ifgday_ix" not in obj:
        raise KeyError(f"{path}:ifgday_ix not found")
    ifg = np.asarray(obj["ifgday_ix"])
    if ifg.ndim != 2 or ifg.shape[1] != 2:
        if ifg.ndim == 2 and ifg.shape[0] == 2:
            ifg = ifg.T
        else:
            raise ValueError(f"ifgday_ix shape={ifg.shape}")

    if "day" not in obj:
        raise KeyError(f"{path}:day not found")
    day = np.asarray(obj["day"], dtype=float).reshape(-1)
    if len(day) != n_image:
        raise ValueError(f"day length={len(day)} != n_image={n_image}")

    dates_dt = [matlab_datenum_to_datetime(v) for v in day]
    dates = [d.strftime("%Y%m%d") for d in dates_dt]

    x = np.asarray(ifg, dtype=float)

    # Case 1: acquisition indices.
    if np.nanmin(x) >= 1 and np.nanmax(x) <= n_image and np.allclose(x, np.round(x)):
        edges = np.round(x).astype(int) - 1
        mode = "1based_acquisition_indices"
    elif np.nanmin(x) >= 0 and np.nanmax(x) < n_image and np.allclose(x, np.round(x)):
        edges = np.round(x).astype(int)
        mode = "0based_acquisition_indices"
    else:
        # Case 2: MATLAB datenums or YYYYMMDD-like values.
        edges = np.empty_like(x, dtype=int)
        lookup_day = {int(round(v)): i for i, v in enumerate(day)}
        lookup_date = {int(d): i for i, d in enumerate(dates)}
        ok = True
        for r in range(x.shape[0]):
            for c in range(2):
                v = int(round(float(x[r, c])))
                if v in lookup_day:
                    edges[r, c] = lookup_day[v]
                elif v in lookup_date:
                    edges[r, c] = lookup_date[v]
                else:
                    ok = False
                    break
            if not ok:
                break
        if not ok:
            raise ValueError(
                "Cannot map ifgday_ix to acquisition indices. "
                f"range={np.nanmin(x)}..{np.nanmax(x)}"
            )
        mode = "date_values_mapped"

    if np.any(edges < 0) or np.any(edges >= n_image):
        raise ValueError("Normalized edges out of acquisition range")
    if np.any(edges[:, 0] == edges[:, 1]):
        raise ValueError("Self-edge found in ifgday_ix")

    return edges, dates, dates_dt, day, mode


def design_matrix(edges: np.ndarray, n_image: int) -> np.ndarray:
    """Incidence design matrix with acquisition 0 fixed to zero."""
    A = np.zeros((len(edges), n_image - 1), dtype=np.float64)
    for k, (m, s) in enumerate(edges):
        if m != 0:
            A[k, m - 1] -= 1.0
        if s != 0:
            A[k, s - 1] += 1.0
    return A


def solve_mapping(A: np.ndarray, weights: Optional[np.ndarray] = None) -> np.ndarray:
    """Return P such that x_nonref = P @ y."""
    if weights is None:
        # np.linalg.pinv is stable and handles a fully connected redundant network.
        return np.linalg.pinv(A, rcond=1e-10)

    w = np.asarray(weights, dtype=np.float64)
    if len(w) != A.shape[0]:
        raise ValueError("weights length mismatch")
    w = np.clip(w, 1e-12, np.inf)
    sw = np.sqrt(w)
    Aw = A * sw[:, None]
    # pinv(Aw) @ diag(sw), without forming the diagonal matrix.
    return np.linalg.pinv(Aw, rcond=1e-10) * sw[None, :]


# =============================================================================
# Graph audit / dynamic protection
# =============================================================================

def adjacency(n: int, edges: np.ndarray, active: np.ndarray):
    adj = [[] for _ in range(n)]
    for k, (a, b) in enumerate(edges):
        if not active[k]:
            continue
        adj[a].append((b, k))
        adj[b].append((a, k))
    return adj


def connected_components(n: int, edges: np.ndarray, active: np.ndarray) -> List[List[int]]:
    adj = adjacency(n, edges, active)
    seen = np.zeros(n, dtype=bool)
    comps = []
    for s in range(n):
        if seen[s]:
            continue
        stack = [s]
        seen[s] = True
        comp = []
        while stack:
            u = stack.pop()
            comp.append(u)
            for v, _ in adj[u]:
                if not seen[v]:
                    seen[v] = True
                    stack.append(v)
        comps.append(comp)
    return comps


def graph_degrees(n: int, edges: np.ndarray, active: np.ndarray) -> np.ndarray:
    d = np.zeros(n, dtype=int)
    ee = edges[active]
    if len(ee):
        np.add.at(d, ee[:, 0], 1)
        np.add.at(d, ee[:, 1], 1)
    return d


def find_bridges(n: int, edges: np.ndarray, active: np.ndarray) -> List[int]:
    """Tarjan bridge finder."""
    adj = adjacency(n, edges, active)
    disc = np.full(n, -1, dtype=int)
    low = np.full(n, -1, dtype=int)
    t = 0
    bridges: List[int] = []

    sys.setrecursionlimit(max(10000, n * 10))

    def dfs(u: int, parent_edge: int):
        nonlocal t
        disc[u] = low[u] = t
        t += 1
        for v, eid in adj[u]:
            if eid == parent_edge:
                continue
            if disc[v] == -1:
                dfs(v, eid)
                low[u] = min(low[u], low[v])
                if low[v] > disc[u]:
                    bridges.append(eid)
            else:
                low[u] = min(low[u], disc[v])

    for i in range(n):
        if disc[i] == -1:
            dfs(i, -1)
    return bridges


def network_summary(n_image: int, edges: np.ndarray, active: np.ndarray) -> Dict[str, Any]:
    comps = connected_components(n_image, edges, active)
    deg = graph_degrees(n_image, edges, active)
    b = find_bridges(n_image, edges, active)
    A = design_matrix(edges[active], n_image)
    rank = int(np.linalg.matrix_rank(A))
    E = int(np.count_nonzero(active))
    return {
        "n_acquisition": int(n_image),
        "n_ifg": E,
        "components": len(comps),
        "component_sizes": [len(c) for c in comps],
        "rank": rank,
        "expected_rank": n_image - 1,
        "cycle_dimension": E - n_image + len(comps),
        "degree_min": int(np.min(deg)),
        "degree_p10": float(np.percentile(deg, 10)),
        "degree_median": float(np.median(deg)),
        "degree_max": int(np.max(deg)),
        "degree1_nodes": int(np.count_nonzero(deg == 1)),
        "bridge_count": int(len(b)),
        "bridge_indices_0based": [int(x) for x in b],
    }


# =============================================================================
# Quality metrics
# =============================================================================

def percentile_risk(v: np.ndarray, high_is_bad: bool = True) -> np.ndarray:
    """Empirical percentile risk in [0,1], robust to scale/outliers."""
    x = np.asarray(v, dtype=float)
    out = np.full(len(x), np.nan)
    good = np.isfinite(x)
    if np.count_nonzero(good) == 0:
        return out
    vals = x[good]
    order = np.argsort(vals, kind="mergesort")
    ranks = np.empty(len(vals), dtype=float)
    ranks[order] = np.linspace(0.0, 1.0, len(vals), endpoint=True)
    if not high_is_bad:
        ranks = 1.0 - ranks
    out[good] = ranks
    return out


def build_spatial_edges(
    x: np.ndarray,
    y: np.ndarray,
    sample_n: int,
    k_neighbor: int,
    seed: int,
):
    rng = np.random.default_rng(seed)
    n = len(x)
    if sample_n >= n:
        seeds = np.arange(n, dtype=np.int64)
    else:
        # Spatially stratified seed selection: one random PS from coarse cells first.
        cell = max(500.0, math.sqrt(
            (np.nanmax(x)-np.nanmin(x))*(np.nanmax(y)-np.nanmin(y)) / max(sample_n, 1)
        ))
        ix = np.floor(x / cell).astype(np.int64)
        iy = np.floor(y / cell).astype(np.int64)
        key = np.rec.fromarrays([ix, iy])
        _, first = np.unique(key, return_index=True)
        seeds = first.astype(np.int64)
        if len(seeds) > sample_n:
            seeds = np.sort(rng.choice(seeds, size=sample_n, replace=False))
        elif len(seeds) < sample_n:
            rest = np.setdiff1d(np.arange(n, dtype=np.int64), seeds, assume_unique=False)
            add_n = min(sample_n - len(seeds), len(rest))
            if add_n > 0:
                add = rng.choice(rest, size=add_n, replace=False)
                seeds = np.sort(np.concatenate([seeds, add]))

    tree = cKDTree(np.column_stack([x, y]))
    kk = max(2, k_neighbor + 1)
    d, idx = tree.query(
        np.column_stack([x[seeds], y[seeds]]),
        k=kk,
        workers=-1,
    )
    idx = np.atleast_2d(idx)
    src = np.repeat(seeds, kk - 1)
    dst = idx[:, 1:kk].reshape(-1).astype(np.int64)

    a = np.minimum(src, dst)
    b = np.maximum(src, dst)
    valid = a != b
    pairs = np.column_stack([a[valid], b[valid]])

    # Unique undirected pairs.
    dtype = np.dtype([("a", np.int64), ("b", np.int64)])
    view = np.ascontiguousarray(pairs).view(dtype).reshape(-1)
    _, first = np.unique(view, return_index=True)
    pairs = pairs[np.sort(first)]

    return seeds, pairs


def wrapped_phase_from_input(a: np.ndarray) -> np.ndarray:
    if np.iscomplexobj(a):
        return np.angle(a).astype(np.float32)
    x = np.asarray(a, dtype=np.float64)
    # Input may already be phase.  Always wrap to (-pi, pi].
    return ((x + np.pi) % (2 * np.pi) - np.pi).astype(np.float32)


def phase_continuity_metrics(
    ph_reader: MatrixReader,
    spatial_pairs: np.ndarray,
    n_ifg: int,
    threshold_rad: float,
    chunk_ifg: int = 32,
):
    # Load only unique PS rows involved in local edges.
    unique_ps, inverse = np.unique(spatial_pairs.reshape(-1), return_inverse=True)
    edge_local = inverse.reshape(-1, 2)
    ph_all = ph_reader.rows(unique_ps)

    rows = []
    for c0 in range(0, n_ifg, chunk_ifg):
        c1 = min(n_ifg, c0 + chunk_ifg)
        ph = wrapped_phase_from_input(ph_all[:, c0:c1])
        d = ph[edge_local[:, 0], :] - ph[edge_local[:, 1], :]
        d = (d + np.pi) % (2*np.pi) - np.pi
        ad = np.abs(d)

        for j in range(c1 - c0):
            v = ad[:, j]
            finite = np.isfinite(v)
            vv = v[finite]
            dd = d[finite, j]
            if len(vv) == 0:
                rows.append((np.nan, np.nan, np.nan, np.nan, 0))
            else:
                rows.append((
                    float(np.median(vv)),
                    float(np.percentile(vv, 90)),
                    float(np.mean(vv <= threshold_rad)),
                    float(np.abs(np.mean(np.exp(1j * dd)))),
                    int(len(vv)),
                ))
        del ph, d, ad
        gc.collect()

    del ph_all
    gc.collect()

    arr = np.asarray(rows, dtype=float)
    return {
        "phase_grad_median_rad": arr[:, 0],
        "phase_grad_p90_rad": arr[:, 1],
        "phase_continuity_ratio": arr[:, 2],
        "phase_circular_continuity": arr[:, 3],
        "phase_continuity_edge_count": arr[:, 4],
    }


def network_residual_metrics(
    obs_reader: MatrixReader,
    A: np.ndarray,
    sample_ps: np.ndarray,
):
    Y = np.asarray(obs_reader.rows(sample_ps), dtype=np.float64)
    finite_rows = np.all(np.isfinite(Y), axis=1)
    Y = Y[finite_rows]
    if len(Y) < 100:
        raise RuntimeError("Too few fully finite PS for network residual audit")
    P = solve_mapping(A, None)
    X = Y @ P.T
    R = Y - X @ A.T
    AR = np.abs(R)
    out = {
        "network_resid_median_abs_rad": np.nanmedian(AR, axis=0),
        "network_resid_p90_abs_rad": np.nanpercentile(AR, 90, axis=0),
        "network_resid_sample_ps": np.full(A.shape[0], len(Y), dtype=float),
    }
    del Y, X, R, AR
    gc.collect()
    return out


def load_ifg_std(dataset: Path, n_ifg: int) -> np.ndarray:
    path = dataset / "ifgstd2.mat"
    if not path.exists():
        return np.full(n_ifg, np.nan)
    obj = loadmat(
        path,
        variable_names=["ifg_std"],
        squeeze_me=True,
        struct_as_record=False,
    )
    if "ifg_std" not in obj:
        return np.full(n_ifg, np.nan)
    a = np.asarray(obj["ifg_std"], dtype=float).reshape(-1)
    if len(a) != n_ifg:
        raise ValueError(f"ifg_std length={len(a)} != n_ifg={n_ifg}")
    return a


# -----------------------------------------------------------------------------
# Optional GAMMA coherence raster mapper
# -----------------------------------------------------------------------------


def _parse_par_dims(path: Path) -> Optional[Tuple[int, int]]:
    """Parse plausible raster (lines, width) from a GAMMA parameter file."""
    try:
        txt = path.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return None

    width_patterns = [
        r"^\s*range_samples\s*:\s*(\d+)",
        r"^\s*width\s*:\s*(\d+)",
        r"^\s*range_samp_1\s*:\s*(\d+)",
    ]
    line_patterns = [
        r"^\s*azimuth_lines\s*:\s*(\d+)",
        r"^\s*nlines\s*:\s*(\d+)",
        r"^\s*line_count\s*:\s*(\d+)",
    ]

    w = None
    h = None
    for pat in width_patterns:
        m = re.search(pat, txt, re.I | re.M)
        if m:
            w = int(m.group(1))
            break
    for pat in line_patterns:
        m = re.search(pat, txt, re.I | re.M)
        if m:
            h = int(m.group(1))
            break

    if w and h and w > 100 and h > 100:
        return h, w
    return None


def index_coherence_files(project: Path) -> List[Path]:
    """Index likely per-IFG coherence/correlation rasters in production directories."""
    dirs = [
        project / "DIFF",
        project / "diff",
        project / "DIFF_dir",
        project / "INTERFEROGRAMS",
    ]
    files: List[Path] = []

    for d in dirs:
        if not d.is_dir():
            continue
        for p in d.iterdir():
            if not p.is_file():
                continue
            name = p.name.lower()

            # Avoid averaged products. Favor standard GAMMA cc/coh/corr naming.
            if "avg" in name or "mean" in name:
                continue

            if (
                re.search(r"(^|[._-])cc([._-]|$)", name)
                or name.endswith(".cc")
                or ".cc." in name
                or "coh" in name
                or "corr" in name
            ):
                files.append(p)

    return sorted(set(files))


def collect_gamma_dim_candidates(project: Path, coh_files: Sequence[Path]) -> List[Dict[str, Any]]:
    """Collect candidate production raster dimensions instead of trusting the first MLI par.

    This fixes the V1 failure where rslc_prep/20170103.mli.par (2760x4551) was selected
    even though the production IFGs are on a different multilooked grid.
    """
    candidates: Dict[Tuple[int, int], Dict[str, Any]] = {}

    # Prefer common production parameter locations, but scan all MLI/OFF/DIFF pars.
    par_globs = [
        "MLI_dir/*.mli.par",
        "MLI/*.mli.par",
        "rslc_prep/*.mli.par",
        "DIFF/*.par",
        "**/*.mli.par",
    ]

    par_files: List[Path] = []
    seen = set()
    for pat in par_globs:
        for p in project.glob(pat):
            if p in seen or not p.is_file():
                continue
            seen.add(p)
            par_files.append(p)

    for p in par_files[:3000]:
        dims = _parse_par_dims(p)
        if dims is None:
            continue
        h, w = dims
        rec = candidates.setdefault(
            (h, w),
            {
                "h": h,
                "w": w,
                "sources": [],
                "matching_coh_file_count": 0,
            },
        )
        if len(rec["sources"]) < 20:
            rec["sources"].append(str(p))

    # Add factor-pair candidates directly from coherence file sizes.
    # Typical GAMMA coherence rasters are uint8, float32, or float64.
    # We only add geometrically plausible pairs to avoid a combinatorial explosion.
    for p in list(coh_files)[:3000]:
        sz = p.stat().st_size
        for bytes_per_px in (1, 4, 8):
            if sz % bytes_per_px:
                continue
            ncell = sz // bytes_per_px
            root = int(math.sqrt(ncell))
            for h in range(max(101, root - 8000), root + 8001):
                if h <= 0 or ncell % h:
                    continue
                w = ncell // h
                if w < 101:
                    continue
                # Plausible SAR raster aspect ratio only.
                ar = w / h
                if not (0.25 <= ar <= 8.0):
                    continue
                rec = candidates.setdefault(
                    (int(h), int(w)),
                    {
                        "h": int(h),
                        "w": int(w),
                        "sources": [],
                        "matching_coh_file_count": 0,
                    },
                )
                tag = f"factor_of:{p.name}:bytes={bytes_per_px}"
                if tag not in rec["sources"] and len(rec["sources"]) < 20:
                    rec["sources"].append(tag)

    # Count how many coherence files exactly fit each candidate.
    for rec in candidates.values():
        ncell = int(rec["h"]) * int(rec["w"])
        rec["matching_coh_file_count"] = int(sum(
            p.stat().st_size in (ncell, ncell * 4, ncell * 8)
            for p in coh_files
        ))

    return list(candidates.values())


def map_ij_to_rc_best(ij: Optional[np.ndarray], candidates: Sequence[Dict[str, Any]]):
    """Jointly choose ij row/col columns, index base, and raster dimensions."""
    if ij is None or ij.ndim != 2 or ij.shape[1] < 2:
        return None, []

    audit_rows = []
    best = None

    cols = list(range(ij.shape[1]))
    for rec in candidates:
        h, w = int(rec["h"]), int(rec["w"])
        coh_hits = int(rec.get("matching_coh_file_count", 0))

        for rc in cols:
            for cc in cols:
                if rc == cc:
                    continue
                r0 = np.asarray(ij[:, rc], dtype=float)
                c0 = np.asarray(ij[:, cc], dtype=float)

                # A true spatial row/col column pair should be almost integer.
                integer_like = float(np.mean(
                    np.isfinite(r0) & np.isfinite(c0)
                    & (np.abs(r0 - np.round(r0)) < 1e-6)
                    & (np.abs(c0 - np.round(c0)) < 1e-6)
                ))

                for base in (0, 1):
                    r = np.round(r0).astype(np.int64) - base
                    c = np.round(c0).astype(np.int64) - base
                    valid = (
                        np.isfinite(r0) & np.isfinite(c0)
                        & (r >= 0) & (r < h)
                        & (c >= 0) & (c < w)
                    )
                    inside = float(np.mean(valid))

                    # Spatial coverage score: real row/col coordinates should span
                    # a meaningful fraction of the production raster.
                    if np.any(valid):
                        rr = r[valid]
                        cc0 = c[valid]
                        row_span = (float(np.max(rr)) - float(np.min(rr)) + 1.0) / h
                        col_span = (float(np.max(cc0)) - float(np.min(cc0)) + 1.0) / w
                    else:
                        row_span = col_span = 0.0

                    # The file-match term strongly favors the actual coherence grid.
                    score = (
                        8.0 * inside
                        + 1.0 * integer_like
                        + 0.5 * min(row_span, 1.0)
                        + 0.5 * min(col_span, 1.0)
                        + 0.25 * min(coh_hits, 20)
                    )

                    audit = {
                        "h": h,
                        "w": w,
                        "row_col": rc,
                        "col_col": cc,
                        "base": base,
                        "inside_fraction": inside,
                        "integer_like_fraction": integer_like,
                        "row_span_fraction": row_span,
                        "col_span_fraction": col_span,
                        "matching_coh_file_count": coh_hits,
                        "score": score,
                        "sources": " | ".join(rec.get("sources", [])[:5]),
                    }
                    audit_rows.append(audit)

                    if best is None or score > best["score"]:
                        best = {
                            **audit,
                            "row": r,
                            "col": c,
                        }

    audit_rows.sort(key=lambda r: r["score"], reverse=True)

    if best is None:
        return None, audit_rows

    # Require strong spatial mapping and at least one matching coherence raster.
    if best["inside_fraction"] < 0.95 or best["matching_coh_file_count"] < 1:
        return None, audit_rows

    return best, audit_rows


def choose_coh_file(files: Sequence[Path], d1: str, d2: str, ncell: int) -> Optional[Path]:
    candidates = []
    for p in files:
        n = p.name
        if not ((d1 in n and d2 in n) or (d2 in n and d1 in n)):
            continue
        sz = p.stat().st_size
        if sz in (ncell * 4, ncell * 8, ncell):
            score = 0
            name = p.name.lower()
            if ".cc" in name or name.endswith("cc"):
                score += 5
            if "coh" in name:
                score += 4
            if "corr" in name:
                score += 3
            if sz == ncell * 4:
                score += 2
            candidates.append((score, len(n), p))
    if not candidates:
        return None
    candidates.sort(key=lambda x: (-x[0], x[1]))
    return candidates[0][2]


def read_gamma_coh_sample(path: Path, flat_idx: np.ndarray, ncell: int):
    sz = path.stat().st_size
    if sz == ncell:
        a = np.memmap(path, mode="r", dtype=np.uint8)
        v = np.asarray(a[flat_idx], dtype=float) / 255.0
        return v, "uint8/255"

    if sz == ncell * 4:
        best = None
        for dtp in (">f4", "<f4"):
            a = np.memmap(path, mode="r", dtype=dtp)
            v = np.asarray(a[flat_idx], dtype=float)
            score = float(np.mean(np.isfinite(v) & (v >= -0.01) & (v <= 1.05)))
            if best is None or score > best[0]:
                best = (score, v, dtp)
        return best[1], best[2]

    if sz == ncell * 8:
        best = None
        for dtp in (">f8", "<f8"):
            a = np.memmap(path, mode="r", dtype=dtp)
            v = np.asarray(a[flat_idx], dtype=float)
            score = float(np.mean(np.isfinite(v) & (v >= -0.01) & (v <= 1.05)))
            if best is None or score > best[0]:
                best = (score, v, dtp)
        return best[1], best[2]

    raise ValueError("unsupported raster size")


def coherence_metrics_auto(
    project: Path,
    dates: Sequence[str],
    edges: np.ndarray,
    ij: Optional[np.ndarray],
    sample_n: int,
    coh_threshold: float,
    seed: int,
    audit_out: Optional[Path] = None,
):
    n_ifg = len(edges)
    out = {
        "coh_mean_pssample": np.full(n_ifg, np.nan),
        "coh_median_pssample": np.full(n_ifg, np.nan),
        "effective_coh_ratio_pssample": np.full(n_ifg, np.nan),
        "coh_sample_count": np.zeros(n_ifg, dtype=float),
        "coh_file": np.array([""] * n_ifg, dtype=object),
        "coh_dtype": np.array([""] * n_ifg, dtype=object),
    }

    files = index_coherence_files(project)
    if not files:
        return out, {
            "enabled": False,
            "reason": "no_candidate_per_ifg_coherence_files_found",
            "coverage_fraction": 0.0,
        }

    dim_candidates = collect_gamma_dim_candidates(project, files)
    mapped, audit_rows = map_ij_to_rc_best(ij, dim_candidates)

    if audit_out is not None:
        write_csv(audit_out / "00_coherence_grid_mapping_candidates.csv", audit_rows[:200])

    if mapped is None:
        return out, {
            "enabled": False,
            "reason": "could_not_jointly_map_ps2_ij_and_coherence_raster_grid",
            "candidate_coherence_file_count": len(files),
            "dimension_candidate_count": len(dim_candidates),
            "best_mapping_candidate": audit_rows[0] if audit_rows else None,
            "coverage_fraction": 0.0,
        }

    h, w = int(mapped["h"]), int(mapped["w"])
    r = mapped["row"]
    c = mapped["col"]

    valid_ps = np.flatnonzero(
        (r >= 0) & (r < h)
        & (c >= 0) & (c < w)
    )
    rng = np.random.default_rng(seed)
    if len(valid_ps) > sample_n:
        sample_ps = np.sort(rng.choice(valid_ps, size=sample_n, replace=False))
    else:
        sample_ps = valid_ps

    flat = r[sample_ps] * w + c[sample_ps]
    flat = np.asarray(flat, dtype=np.int64)
    flat = np.unique(np.sort(flat))

    ncell = h * w
    found = 0
    failures = []

    for k, (m, s) in enumerate(edges):
        p = choose_coh_file(files, dates[m], dates[s], ncell)
        if p is None:
            continue
        try:
            v, dtype_used = read_gamma_coh_sample(p, flat, ncell)
            good = np.isfinite(v) & (v >= 0) & (v <= 1.05)
            vv = v[good]
            if len(vv) < 100:
                failures.append({
                    "ifg_index_1based": k+1,
                    "date12": f"{dates[m]}_{dates[s]}",
                    "file": str(p),
                    "reason": f"too_few_valid_samples:{len(vv)}",
                })
                continue

            out["coh_mean_pssample"][k] = float(np.mean(vv))
            out["coh_median_pssample"][k] = float(np.median(vv))
            out["effective_coh_ratio_pssample"][k] = float(
                np.mean(vv >= coh_threshold)
            )
            out["coh_sample_count"][k] = len(vv)
            out["coh_file"][k] = str(p)
            out["coh_dtype"][k] = dtype_used
            found += 1
        except Exception as e:
            failures.append({
                "ifg_index_1based": k+1,
                "date12": f"{dates[m]}_{dates[s]}",
                "file": str(p),
                "reason": repr(e),
            })

    if audit_out is not None:
        write_csv(audit_out / "00_coherence_read_failures.csv", failures)

    meta_mapping = {
        k: v for k, v in mapped.items()
        if k not in ("row", "col")
    }

    return out, {
        "enabled": found > 0,
        "reason": "ok" if found > 0 else "no_readable_mapped_per_ifg_coherence_rasters",
        "dims": [h, w],
        "ij_mapping": meta_mapping,
        "candidate_coherence_file_count": len(files),
        "mapped_ifg_count": found,
        "coverage_fraction": found / n_ifg,
        "coh_threshold": coh_threshold,
        "sample_ps_count": len(flat),
    }


def combine_quality_risks(metrics: Dict[str, np.ndarray], coherence_enabled: bool):
    """Build independent hard-evidence risks.

    IMPORTANT: network residual is reported but excluded from hard-delete votes and
    from the hard-deletion composite score.
    """
    r_phase = np.nanmean(np.vstack([
        percentile_risk(metrics["phase_grad_p90_rad"], True),
        percentile_risk(metrics["phase_continuity_ratio"], False),
        percentile_risk(metrics["phase_circular_continuity"], False),
    ]), axis=0)

    if coherence_enabled:
        r_coh = np.nanmean(np.vstack([
            percentile_risk(metrics["coh_mean_pssample"], False),
            percentile_risk(metrics["coh_median_pssample"], False),
            percentile_risk(metrics["effective_coh_ratio_pssample"], False),
        ]), axis=0)
    else:
        r_coh = np.full(len(r_phase), np.nan)

    r_std = percentile_risk(metrics["ifg_std"], True)

    # Diagnostic only.
    r_net = np.nanmean(np.vstack([
        percentile_risk(metrics["network_resid_median_abs_rad"], True),
        percentile_risk(metrics["network_resid_p90_abs_rad"], True),
    ]), axis=0)

    risks = {
        "risk_phase_continuity": r_phase,
        "risk_coherence": r_coh,
        "risk_ifg_std": r_std,
        "risk_network_residual_diagnostic_only": r_net,
    }

    # Hard-deletion composite: ONLY independent evidence.
    nominal_weights = {
        "risk_phase_continuity": 0.40,
        "risk_coherence": 0.35,
        "risk_ifg_std": 0.25,
    }

    stack = np.vstack([risks[k] for k in nominal_weights])
    w = np.asarray([nominal_weights[k] for k in nominal_weights], dtype=float)[:, None]
    valid = np.isfinite(stack)
    num = np.nansum(stack * w, axis=0)
    den = np.sum(valid * w, axis=0)
    hard_comp = np.divide(
        num,
        den,
        out=np.full(stack.shape[1], np.nan),
        where=den > 0,
    )
    risks["hard_composite_risk"] = hard_comp

    # Soft WLS diagnostic score may include network residual with low weight,
    # but this is never used to decide deletion.
    soft_names = [
        "risk_phase_continuity",
        "risk_coherence",
        "risk_ifg_std",
        "risk_network_residual_diagnostic_only",
    ]
    soft_w = np.asarray([0.35, 0.30, 0.25, 0.10], dtype=float)[:, None]
    soft_stack = np.vstack([risks[k] for k in soft_names])
    soft_valid = np.isfinite(soft_stack)
    soft_num = np.nansum(soft_stack * soft_w, axis=0)
    soft_den = np.sum(soft_valid * soft_w, axis=0)
    risks["soft_quality_risk_for_wls_only"] = np.divide(
        soft_num,
        soft_den,
        out=np.full(stack.shape[1], np.nan),
        where=soft_den > 0,
    )

    return risks, nominal_weights


def select_network_dynamic(
    edges: np.ndarray,
    n_image: int,
    risks: Dict[str, np.ndarray],
    bad_metric_risk: float,
    min_bad_votes: int,
    composite_min: float,
    max_remove_fraction: float,
    degree_floor_target: int,
    original_bridge_count: int,
):
    """Conservative hard selection.

    Hard votes are ONLY:
      phase continuity, coherence (if available), ifg_std.

    If coherence is unavailable, deletion requires BOTH phase-continuity and ifg_std
    evidence (2/2), not a phase + network-residual combination.

    Structural protection:
      - connected
      - node degree floor
      - bridge count may not exceed the ORIGINAL bridge count
        (for the current Cangzhou network: remains exactly zero)
    """
    n_ifg = len(edges)
    active = np.ones(n_ifg, dtype=bool)
    original_deg = graph_degrees(n_image, edges, active)
    degree_floor = np.minimum(original_deg, degree_floor_target)

    hard_names = [
        "risk_phase_continuity",
        "risk_coherence",
        "risk_ifg_std",
    ]

    votes = np.zeros(n_ifg, dtype=int)
    available_votes = np.zeros(n_ifg, dtype=int)

    for name in hard_names:
        r = risks[name]
        finite = np.isfinite(r)
        available_votes += finite.astype(int)
        votes += (finite & (r >= bad_metric_risk)).astype(int)

    # With three available families require configured min votes (default 2/3).
    # With only phase + ifg_std available, require both (2/2).
    required_votes = np.where(
        available_votes >= 3,
        min_bad_votes,
        available_votes,
    )
    required_votes = np.maximum(required_votes, 2)

    comp = risks["hard_composite_risk"]
    candidate = (
        np.isfinite(comp)
        & (comp >= composite_min)
        & (votes >= required_votes)
        & (available_votes >= 2)
    )

    order = np.flatnonzero(candidate)
    order = order[np.argsort(comp[order])[::-1]]

    status = np.array(["kept_not_flagged"] * n_ifg, dtype=object)
    reason = np.array([""] * n_ifg, dtype=object)
    status[candidate] = "flagged_candidate"

    max_remove = int(math.floor(max_remove_fraction * n_ifg))
    removed = 0

    for eid in order:
        if removed >= max_remove:
            status[eid] = "kept_safety_remove_cap"
            reason[eid] = "max_remove_fraction_reached"
            continue

        a, b = edges[eid]
        deg = graph_degrees(n_image, edges, active)

        if (deg[a] - 1 < degree_floor[a]) or (deg[b] - 1 < degree_floor[b]):
            status[eid] = "kept_protected_degree"
            reason[eid] = (
                f"degree_floor: before=({deg[a]},{deg[b]}), "
                f"floor=({degree_floor[a]},{degree_floor[b]})"
            )
            continue

        active[eid] = False

        comps = connected_components(n_image, edges, active)
        if len(comps) != 1:
            active[eid] = True
            status[eid] = "kept_protected_connectivity"
            reason[eid] = "deletion_would_disconnect_network"
            continue

        bridges_after = find_bridges(n_image, edges, active)
        if len(bridges_after) > original_bridge_count:
            active[eid] = True
            status[eid] = "kept_protected_no_new_bridge"
            reason[eid] = (
                f"deletion_would_increase_bridge_count:"
                f"{original_bridge_count}->{len(bridges_after)}"
            )
            continue

        status[eid] = "removed_bad_redundant"
        reason[eid] = "independent_quality_evidence_and_structurally_safe"
        removed += 1

    for eid in np.flatnonzero(candidate):
        if status[eid] == "flagged_candidate":
            status[eid] = "kept_flagged_but_not_removed"

    return (
        active,
        status,
        reason,
        votes,
        available_votes,
        required_votes,
    )


# =============================================================================
# Inversion / velocity
# =============================================================================

def elapsed_years(dts: Sequence[dt.datetime]) -> np.ndarray:
    t0 = dts[0]
    return np.asarray(
        [(d - t0).total_seconds() / 86400.0 / 365.2425 for d in dts],
        dtype=np.float64,
    )


def slope_coefficients(dates_dt: Sequence[dt.datetime], year: Optional[int] = None):
    n = len(dates_dt)
    c = np.zeros(n, dtype=np.float64)

    if year is None:
        idx = np.arange(n, dtype=int)
    else:
        idx = np.asarray([i for i, d in enumerate(dates_dt) if d.year == year], dtype=int)

    if len(idx) < 3:
        return c, idx

    local = [dates_dt[i] for i in idx]
    t = elapsed_years(local)
    tc = t - np.mean(t)
    den = np.sum(tc**2)
    if den <= 0:
        return c, idx
    c[idx] = tc / den
    return c, idx


def phase_rate_edge_coeff(P: np.ndarray, c_acq: np.ndarray) -> np.ndarray:
    """q with phase_rate_per_PS = y_ifg @ q."""
    # acquisition 0 is fixed to zero and has no row in P output.
    return P.T @ c_acq[1:]


def compute_rates_from_obs(
    obs_reader: MatrixReader,
    Q_full_edges: np.ndarray,
    active_idx: np.ndarray,
    n_ps: int,
    block_rows: int,
):
    """Compute one or many linear phase-rate functionals in a single IFG read pass.

    Q_full_edges: shape (n_selected_ifg, n_rate_functionals)
    Returns:      shape (n_ps, n_rate_functionals)

    This avoids repeatedly reading the ~1 GB IFG matrix once per year/branch.
    """
    Q = np.asarray(Q_full_edges, dtype=np.float64)
    if Q.ndim == 1:
        Q = Q[:, None]
    if Q.shape[0] != len(active_idx):
        raise ValueError("Q / active edge count mismatch")

    out = np.full((n_ps, Q.shape[1]), np.nan, dtype=np.float64)

    for r0 in range(0, n_ps, block_rows):
        r1 = min(n_ps, r0 + block_rows)
        Y = np.asarray(obs_reader.block(r0, r1, active_idx), dtype=np.float64)
        good = np.all(np.isfinite(Y), axis=1)
        if np.any(good):
            block_out = out[r0:r1]
            block_out[good, :] = Y[good] @ Q

    return out


def apply_mapping_to_rows(Y: np.ndarray, P: np.ndarray, n_image: int, sign: float):
    Xnr = (Y @ P.T) * sign
    X = np.zeros((len(Y), n_image), dtype=np.float64)
    X[:, 1:] = Xnr
    return X


def load_correction_matrix(dataset: Path, source: str, n_ps: int, n_image: int):
    if source == "ramp":
        path = dataset / "scla2.mat"
        var = "ph_ramp"
    elif source == "scn":
        path = dataset / "uw_space_time.mat"
        var = "ph_scn"
    else:
        raise ValueError(source)

    if not path.exists():
        return None

    if mat_is_hdf5(path):
        reader = MatrixReader(path, var, n_ps, n_image)
        # Dataset is only ~375051x257 float; load once for fast annual products.
        a = reader.block(0, n_ps)
    else:
        a = classic_load_var(path, var)
        if a.shape == (n_image, n_ps):
            a = a.T
        if a.shape != (n_ps, n_image):
            raise ValueError(f"{path}:{var} shape={a.shape}")
    return np.asarray(a, dtype=np.float32)


def calibrate_edge_sign(
    dataset: Path,
    obs_reader: MatrixReader,
    P_full_ols: np.ndarray,
    n_ps: int,
    n_image: int,
    sample_n: int,
    seed: int,
):
    path = dataset / "phuw_sm2.mat"
    try:
        target = classic_load_var(path, "ph_uw")
        if target.shape == (n_image, n_ps):
            target = target.T
        if target.shape != (n_ps, n_image):
            return 1.0, {"status": "fallback", "reason": f"phuw_sm2.ph_uw shape={target.shape}"}

        rng = np.random.default_rng(seed)
        idx = np.sort(rng.choice(n_ps, size=min(sample_n, n_ps), replace=False))
        Y = np.asarray(obs_reader.rows(idx), dtype=np.float64)
        good = np.all(np.isfinite(Y), axis=1)
        idx = idx[good]
        Y = Y[good]
        if len(Y) < 100:
            return 1.0, {"status": "fallback", "reason": "too_few_finite_sample_rows"}

        X = apply_mapping_to_rows(Y, P_full_ols, n_image, 1.0)
        T = np.asarray(target[idx, :], dtype=np.float64)

        scores = {}
        for s in (+1.0, -1.0):
            D = T - s * X
            # Remove epoch-wise common mode; compare only spatial structure/sign.
            D -= np.nanmedian(D, axis=0, keepdims=True)
            scores[str(int(s))] = float(np.nanmedian(np.abs(D)))

        sign = +1.0 if scores["1"] <= scores["-1"] else -1.0
        return sign, {
            "status": "ok",
            "method": "min_median_abs_spatial_residual_vs_phuw_sm2_ph_uw_after_epoch_common_mode",
            "score_plus": scores["1"],
            "score_minus": scores["-1"],
            "selected_sign": sign,
            "sample_ps": int(len(idx)),
        }
    except Exception as e:
        return 1.0, {"status": "fallback", "reason": repr(e)}


# =============================================================================
# Truth validation
# =============================================================================

def choose_vfield(gdf, preferred: str):
    geom = gdf.geometry.name
    cols = [c for c in gdf.columns if c != geom]
    for c in cols:
        if c.lower() == preferred.lower():
            return c
    numeric = [c for c in cols if np.issubdtype(gdf[c].dtype, np.number)]
    for p in ("v", "vel", "velocity", "rate"):
        for c in numeric:
            if norm_key(c) == p:
                return c
    raise RuntimeError(f"Cannot identify truth velocity field; columns={cols}")


def read_truth_cropped(
    path: Path,
    preferred_field: str,
    scale: float,
    lon0: float,
    lat0: float,
    ps_bbox: Tuple[float, float, float, float],
    buffer_m: float,
):
    import geopandas as gpd
    gdf = gpd.read_file(path)
    if gdf.crs is not None:
        gdf = gdf.to_crs(4326)
    if not np.all(gdf.geometry.geom_type == "Point"):
        raise RuntimeError(f"{path.name} is not Point geometry")
    vf = choose_vfield(gdf, preferred_field)

    lon = np.asarray(gdf.geometry.x, dtype=float)
    lat = np.asarray(gdf.geometry.y, dtype=float)
    v = np.asarray(gdf[vf], dtype=float) * scale
    good = np.isfinite(lon) & np.isfinite(lat) & np.isfinite(v)
    lon, lat, v = lon[good], lat[good], v[good]

    x, y, _, _ = local_xy(lon, lat, lon0, lat0)
    xmin, xmax, ymin, ymax = ps_bbox
    inside = (
        (x >= xmin-buffer_m) & (x <= xmax+buffer_m)
        & (y >= ymin-buffer_m) & (y <= ymax+buffer_m)
    )
    del gdf
    gc.collect()
    return lon[inside], lat[inside], x[inside], y[inside], v[inside], vf


def unique_ps_truth_mapping(ps_xy: np.ndarray, truth_xy: np.ndarray, match_m: float):
    tree = cKDTree(truth_xy)
    dist, tidx = tree.query(ps_xy, k=1, workers=-1)
    dist = np.asarray(dist, dtype=float)
    tidx = np.asarray(tidx, dtype=np.int64)

    within = np.isfinite(dist) & (dist <= match_m)
    p = np.flatnonzero(within)
    d = dist[within]
    t = tidx[within]

    order = np.argsort(d)
    t_order = t[order]
    _, first = np.unique(t_order, return_index=True)
    keep = np.sort(order[first])
    return p[keep], t[keep], d[keep]


def validation_metrics(pred, truth):
    good = np.isfinite(pred) & np.isfinite(truth)
    p = np.asarray(pred[good], dtype=float)
    t = np.asarray(truth[good], dtype=float)
    if len(p) < 3:
        return None
    e = p - t
    if np.std(p) > 0 and np.std(t) > 0:
        cc = float(np.corrcoef(p, t)[0, 1])
    else:
        cc = np.nan
    G = np.column_stack([np.ones_like(t), t])
    beta, *_ = np.linalg.lstsq(G, p, rcond=None)
    return {
        "n": int(len(e)),
        "rmse_mm_yr": float(np.sqrt(np.mean(e**2))),
        "mae_mm_yr": float(np.mean(np.abs(e))),
        "median_bias_mm_yr": float(np.median(e)),
        "mean_bias_mm_yr": float(np.mean(e)),
        "p95_abs_error_mm_yr": float(np.percentile(np.abs(e), 95)),
        "correlation": cc,
        "regression_intercept_mm_yr": float(beta[0]),
        "regression_pred_vs_truth_slope": float(beta[1]),
        "pred_std_mm_yr": float(np.std(p)),
        "truth_std_mm_yr": float(np.std(t)),
        "pred_std_over_truth_std": float(np.std(p)/np.std(t)) if np.std(t) > 0 else np.nan,
    }


# =============================================================================
# Raster outputs
# =============================================================================

def raster_assignment(lon, lat, template_path: Path):
    import rasterio
    with rasterio.open(template_path) as src:
        profile = src.profile.copy()
        transform = src.transform
        crs = src.crs
        width, height = src.width, src.height

    if crs is None:
        raise RuntimeError(f"Raster template lacks CRS: {template_path}")

    if crs.to_epsg() == 4326:
        xs, ys = lon.astype(float), lat.astype(float)
    else:
        from pyproj import Transformer
        tr = Transformer.from_crs("EPSG:4326", crs, always_xy=True)
        xs, ys = tr.transform(lon.astype(float), lat.astype(float))
        xs, ys = np.asarray(xs), np.asarray(ys)

    inv = ~transform
    cols_f, rows_f = inv * (xs, ys)
    cols = np.floor(cols_f).astype(np.int64)
    rows = np.floor(rows_f).astype(np.int64)
    inside = (
        np.isfinite(xs) & np.isfinite(ys)
        & (rows >= 0) & (rows < height)
        & (cols >= 0) & (cols < width)
    )
    psidx = np.flatnonzero(inside)
    flat = (rows[inside] * width + cols[inside]).astype(np.int64)
    return psidx, flat, profile, width, height


def write_ps_median_tif(path, values, psidx, flat, profile, width, height, tags):
    import pandas as pd
    import rasterio

    vals = np.asarray(values, dtype=float)[psidx]
    good = np.isfinite(vals)
    df = pd.DataFrame({"cell": flat[good], "value": vals[good]})
    med = df.groupby("cell", sort=False)["value"].median()

    nodata = np.float32(-9999.0)
    arr = np.full(height * width, nodata, dtype=np.float32)
    arr[med.index.to_numpy(dtype=np.int64)] = med.to_numpy(dtype=np.float32)
    arr = arr.reshape(height, width)

    out_profile = profile.copy()
    out_profile.update(
        count=1,
        dtype="float32",
        nodata=float(nodata),
        compress="deflate",
        predictor=3,
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    with rasterio.open(path, "w", **out_profile) as dst:
        dst.write(arr, 1)
        dst.set_band_description(1, "velocity_mm_per_year")
        dst.update_tags(**tags)


# =============================================================================
# Main
# =============================================================================

def parse_args():
    p = argparse.ArgumentParser(
        description="Multi-indicator IFG selection + SBAS/WLS time-series inversion"
    )
    p.add_argument(
        "--dataset",
        default="/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized",
    )
    p.add_argument(
        "--project",
        default="/mnt/vol-gdc28n1r/insar/cangzhou_P69",
    )
    p.add_argument("--out", default="")
    p.add_argument("--truth-dir", default="")
    p.add_argument("--truth-field", default="v")
    p.add_argument("--truth-scale", type=float, default=1.0)

    p.add_argument("--wrapped-file", default="ph2.mat")
    p.add_argument("--wrapped-var", default="ph")
    p.add_argument("--unwrapped-file", default="phuw2_gacos.mat")
    p.add_argument("--unwrapped-var", default="ph_uw")

    p.add_argument("--continuity-sample", type=int, default=25000)
    p.add_argument("--continuity-k", type=int, default=4)
    p.add_argument("--continuity-threshold-rad", type=float, default=np.pi/2)
    p.add_argument("--network-resid-sample", type=int, default=12000)
    p.add_argument("--coherence-sample", type=int, default=20000)
    p.add_argument("--coherence-threshold", type=float, default=0.40)
    p.add_argument("--min-coherence-coverage", type=float, default=0.80)
    p.add_argument("--skip-coherence", action="store_true")

    p.add_argument("--bad-metric-risk", type=float, default=0.80)
    p.add_argument("--min-bad-votes", type=int, default=2)
    p.add_argument("--composite-remove-min", type=float, default=0.70)
    p.add_argument("--max-remove-fraction", type=float, default=0.15)
    p.add_argument("--degree-floor", type=int, default=3)

    p.add_argument("--wls-floor", type=float, default=0.03)
    p.add_argument("--wls-quality-power", type=float, default=2.0)
    p.add_argument("--block-rows", type=int, default=5000)
    p.add_argument("--sign-calibration-sample", type=int, default=2000)
    p.add_argument("--seed", type=int, default=20260811)

    p.add_argument("--reference-lon", type=float, default=117.21775055)
    p.add_argument("--reference-lat", type=float, default=38.40310669)
    p.add_argument("--reference-radius-m", type=float, default=500.0)

    p.add_argument("--match-m", type=float, default=200.0)
    p.add_argument("--truth-buffer-m", type=float, default=1500.0)
    p.add_argument(
        "--correction-modes",
        default="RAMP,RAMP_SCN",
        help="Comma-separated subset of RAMP,RAMP_SCN,NONE",
    )
    p.add_argument(
        "--always-write-product",
        action="store_true",
        help="Write best-new full products even if not better than current Final-C",
    )
    p.add_argument(
        "--min-improvement-to-write-product",
        type=float,
        default=0.02,
        help="Default minimum pooled truth-RMSE relative improvement needed to write full products",
    )
    p.add_argument("--no-write-timeseries", action="store_true")
    p.add_argument("--no-write-tifs", action="store_true")
    p.add_argument(
        "--raster-template",
        default="postprocess/rasters/geo_velocity.tif",
    )
    p.add_argument("--self-test", action="store_true")
    return p.parse_args()



def self_test():
    # 5-edge graph with redundancy and zero initial bridges.
    edges = np.array([
        [0,1],[1,2],[2,3],[3,0],[0,2],[1,3]
    ], dtype=int)
    n = 4
    active0 = np.ones(len(edges), dtype=bool)
    before = network_summary(n, edges, active0)
    assert before["components"] == 1
    assert before["bridge_count"] == 0

    risk = {
        "risk_phase_continuity": np.array([.95,.90,.20,.10,.85,.15]),
        "risk_coherence": np.array([.90,.88,.10,.20,.82,.10]),
        "risk_ifg_std": np.array([.91,.89,.20,.10,.81,.20]),
        "risk_network_residual_diagnostic_only": np.array([.10,.99,.10,.20,.99,.10]),
        "hard_composite_risk": np.array([.92,.89,.15,.15,.83,.15]),
        "soft_quality_risk_for_wls_only": np.array([.82,.91,.15,.15,.88,.15]),
    }

    (
        active,
        status,
        _,
        _,
        _,
        _,
    ) = select_network_dynamic(
        edges,
        n,
        risk,
        bad_metric_risk=.8,
        min_bad_votes=2,
        composite_min=.7,
        max_remove_fraction=.5,
        degree_floor_target=2,
        original_bridge_count=before["bridge_count"],
    )

    after = network_summary(n, edges, active)
    assert after["components"] == 1
    assert after["rank"] == n - 1
    assert after["bridge_count"] == 0

    A = design_matrix(edges[active], n)
    P = solve_mapping(A)
    x_true = np.array([0., 1., 3., 2.])
    y = np.array([x_true[b]-x_true[a] for a,b in edges[active]])
    xr = np.zeros(n)
    xr[1:] = P @ y
    assert np.allclose(xr, x_true, atol=1e-9)

    # Network residual diagnostic alone must not create a delete vote.
    assert "risk_network_residual_diagnostic_only" in risk
    print("SELF-TEST: PASS")

def main():
    args = parse_args()
    if args.self_test:
        self_test()
        return

    dataset = Path(args.dataset).resolve()
    project = Path(args.project).resolve()
    truth_dir = Path(args.truth_dir).resolve() if args.truth_dir else dataset / "cangzhou"

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = Path(args.out).resolve() if args.out else (
        dataset / "_audit" / f"ifg_select_sbas_v2_{stamp}"
    )
    out.mkdir(parents=True, exist_ok=True)

    print("=" * 78)
    print("IFG selection + SBAS/WLS deformation pipeline")
    print("=" * 78)
    print("dataset :", dataset)
    print("project :", project)
    print("output  :", out)
    print()

    required = [
        dataset / "ps2.mat",
        dataset / "phuw_sm2.mat",
        dataset / args.wrapped_file,
        dataset / args.unwrapped_file,
        dataset / "ifgstd2.mat",
    ]
    for p in required:
        if not p.exists():
            raise FileNotFoundError(p)

    n_ps, n_image, lon, lat, ij = load_ps_metadata(dataset)
    edges, dates, dates_dt, day, ifg_mode = load_network(dataset, n_image)
    n_ifg = len(edges)

    if n_ifg <= n_image - 1:
        print("WARNING: network has little/no redundancy before quality selection")

    x, y, lon0, lat0 = local_xy(lon, lat)
    ps_xy = np.column_stack([x, y])
    ps_bbox = (float(x.min()), float(x.max()), float(y.min()), float(y.max()))

    wavelength, wavelength_source = find_wavelength(project)
    phase_to_mm = -wavelength / (4*np.pi) * 1000.0

    print(f"n_ps={n_ps}, n_image={n_image}, n_ifg={n_ifg}")
    print(f"date range={dates[0]}..{dates[-1]}")
    print(f"phase_to_mm={phase_to_mm:.9f} mm/rad")
    print(f"ifgday_ix mode={ifg_mode}")

    active_all = np.ones(n_ifg, dtype=bool)
    before = network_summary(n_image, edges, active_all)
    if before["components"] != 1 or before["rank"] != n_image - 1:
        raise RuntimeError(
            "Original IFG network is not fully connected/full-rank; "
            "quality selection is intentionally aborted."
        )

    A_full = design_matrix(edges, n_image)
    P_full_ols = solve_mapping(A_full)

    obs_reader = MatrixReader(
        dataset / args.unwrapped_file,
        args.unwrapped_var,
        n_ps,
        n_ifg,
    )

    # ------------------------------------------------------------------
    # 1. Phase continuity
    # ------------------------------------------------------------------
    print("\n=== 1. wrapped-phase spatial continuity ===")
    _, spatial_pairs = build_spatial_edges(
        x, y,
        sample_n=args.continuity_sample,
        k_neighbor=args.continuity_k,
        seed=args.seed,
    )
    print("local PS edges:", len(spatial_pairs))

    ph_reader = MatrixReader(
        dataset / args.wrapped_file,
        args.wrapped_var,
        n_ps,
        n_ifg,
    )
    continuity = phase_continuity_metrics(
        ph_reader,
        spatial_pairs,
        n_ifg,
        args.continuity_threshold_rad,
    )
    # Release large classic wrapped matrix immediately.
    del ph_reader
    gc.collect()

    # ------------------------------------------------------------------
    # 2. IFG std
    # ------------------------------------------------------------------
    print("\n=== 2. ifg_std ===")
    ifg_std = load_ifg_std(dataset, n_ifg)
    print(
        "ifg_std median/p90:",
        float(np.nanmedian(ifg_std)),
        float(np.nanpercentile(ifg_std, 90)),
    )

    # ------------------------------------------------------------------
    # 3. Network residual
    # ------------------------------------------------------------------
    print("\n=== 3. network residual consistency ===")
    rng = np.random.default_rng(args.seed + 1)
    resid_sample = np.sort(
        rng.choice(
            n_ps,
            size=min(args.network_resid_sample, n_ps),
            replace=False,
        )
    )
    netres = network_residual_metrics(
        obs_reader,
        A_full,
        resid_sample,
    )

    # ------------------------------------------------------------------
    # 4. Optional per-IFG coherence
    # ------------------------------------------------------------------
    print("\n=== 4. optional GAMMA per-IFG coherence ===")
    if args.skip_coherence:
        coh = {
            "coh_mean_pssample": np.full(n_ifg, np.nan),
            "coh_median_pssample": np.full(n_ifg, np.nan),
            "effective_coh_ratio_pssample": np.full(n_ifg, np.nan),
            "coh_sample_count": np.zeros(n_ifg),
            "coh_file": np.array([""]*n_ifg, dtype=object),
            "coh_dtype": np.array([""]*n_ifg, dtype=object),
        }
        coh_meta = {
            "enabled": False,
            "reason": "disabled_by_user",
            "coverage_fraction": 0.0,
        }
    else:
        coh, coh_meta = coherence_metrics_auto(
            project, dates, edges, ij,
            sample_n=args.coherence_sample,
            coh_threshold=args.coherence_threshold,
            seed=args.seed + 2,
            audit_out=out,
        )

    coherence_enabled_for_score = (
        coh_meta.get("coverage_fraction", 0.0) >= args.min_coherence_coverage
    )
    print("coherence metadata:", json.dumps(coh_meta, ensure_ascii=False, indent=2))
    print("coherence used in composite score:", coherence_enabled_for_score)

    metrics: Dict[str, np.ndarray] = {}
    metrics.update(continuity)
    metrics.update(netres)
    metrics.update(coh)
    metrics["ifg_std"] = ifg_std

    risks, risk_weights = combine_quality_risks(
        metrics,
        coherence_enabled=coherence_enabled_for_score,
    )

    # ------------------------------------------------------------------
    # 5. Dynamic network selection
    # ------------------------------------------------------------------
    print("\n=== 5. dynamic connectivity-protected selection ===")
    (
        selected_active,
        selection_status,
        selection_reason,
        bad_votes,
        available_votes,
        required_votes,
    ) = select_network_dynamic(
        edges,
        n_image,
        risks,
        bad_metric_risk=args.bad_metric_risk,
        min_bad_votes=args.min_bad_votes,
        composite_min=args.composite_remove_min,
        max_remove_fraction=args.max_remove_fraction,
        degree_floor_target=args.degree_floor,
        original_bridge_count=before["bridge_count"],
    )

    after = network_summary(n_image, edges, selected_active)
    if after["components"] != 1 or after["rank"] != n_image - 1:
        raise RuntimeError("Internal error: selected network lost connectivity/rank")

    print("before:", json.dumps(before, indent=2))
    print("after :", json.dumps(after, indent=2))

    # ------------------------------------------------------------------
    # IFG table
    # ------------------------------------------------------------------
    ifg_rows = []
    for k, (m, s) in enumerate(edges):
        row = {
            "ifg_index_1based": k + 1,
            "date12": f"{dates[m]}_{dates[s]}",
            "master_index_1based": int(m) + 1,
            "slave_index_1based": int(s) + 1,
            "selected": int(selected_active[k]),
            "selection_status": str(selection_status[k]),
            "selection_reason": str(selection_reason[k]),
            "bad_votes": int(bad_votes[k]),
            "available_quality_votes": int(available_votes[k]),
            "required_bad_votes": int(required_votes[k]),
        }
        for name, a in metrics.items():
            if name in ("coh_file", "coh_dtype"):
                row[name] = str(a[k])
            else:
                try:
                    row[name] = float(a[k])
                except Exception:
                    row[name] = a[k]
        for name, a in risks.items():
            row[name] = float(a[k]) if np.isfinite(a[k]) else np.nan
        ifg_rows.append(row)

    write_csv(out / "01_ifg_quality_and_selection.csv", ifg_rows)
    write_csv(
        out / "02_removed_ifgs.csv",
        [r for r in ifg_rows if not r["selected"]],
    )
    write_csv(
        out / "03_protected_weak_ifgs.csv",
        [
            r for r in ifg_rows
            if str(r["selection_status"]).startswith("kept_protected")
        ],
    )

    selected_idx = np.flatnonzero(selected_active)
    np.savetxt(
        out / "selected_ifg_indices_1based.txt",
        selected_idx + 1,
        fmt="%d",
    )
    (out / "selected_ifg_date12.txt").write_text(
        "\n".join(ifg_rows[k]["date12"] for k in selected_idx) + "\n",
        encoding="utf-8",
    )

    network_meta = {
        "before": before,
        "after": after,
        "quality_weights": risk_weights,
        "selection_parameters": {
            "bad_metric_risk": args.bad_metric_risk,
            "min_bad_votes": args.min_bad_votes,
            "composite_remove_min": args.composite_remove_min,
            "max_remove_fraction": args.max_remove_fraction,
            "degree_floor": args.degree_floor,
        },
        "coherence": coh_meta,
        "coherence_used_in_composite_score": coherence_enabled_for_score,
        "hard_delete_evidence":
            "phase continuity + coherence/effective area (when mapped) + ifg_std only",
        "note_network_residual":
            "Diagnostic / soft-WLS only; NEVER a hard-delete vote because this dataset "
            "has verified multilook-induced non-closure.",
        "structural_protection":
            "connected + degree floor + no increase in bridge count",
    }
    (out / "04_network_summary.json").write_text(
        json.dumps(network_meta, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    # ------------------------------------------------------------------
    # 6. Inversion mappings and weights
    # ------------------------------------------------------------------
    print("\n=== 6. inversion mappings ===")
    sign, sign_meta = calibrate_edge_sign(
        dataset,
        obs_reader,
        P_full_ols,
        n_ps,
        n_image,
        args.sign_calibration_sample,
        args.seed + 3,
    )
    print("edge sign calibration:", json.dumps(sign_meta, ensure_ascii=False, indent=2))

    # Inverse-ifg_std weights.
    std = np.asarray(ifg_std, dtype=float)
    med_std = float(np.nanmedian(std[np.isfinite(std) & (std > 0)]))
    std_filled = np.where(np.isfinite(std) & (std > 0), std, med_std)
    w_std = (med_std / std_filled) ** 2
    w_std = np.clip(w_std, 0.03, 30.0)
    w_std /= np.nanmedian(w_std)

    # Multi-quality weights: retain inverse-variance physics, add soft quality damping.
    comp = risks["soft_quality_risk_for_wls_only"]
    comp_filled = np.where(np.isfinite(comp), comp, np.nanmedian(comp))
    quality_factor = np.clip(
        (1.0 - comp_filled) ** args.wls_quality_power,
        args.wls_floor,
        1.0,
    )
    w_multi = w_std * quality_factor
    w_multi /= np.nanmedian(w_multi[selected_active])

    configs = {}
    for net_name, mask in [
        ("FULL", np.ones(n_ifg, dtype=bool)),
        ("SELECTED", selected_active),
    ]:
        idx = np.flatnonzero(mask)
        A = design_matrix(edges[idx], n_image)
        configs[f"{net_name}_OLS"] = {
            "network": net_name,
            "mode": "OLS",
            "idx": idx,
            "P": solve_mapping(A),
            "weights": np.ones(len(idx)),
        }
        configs[f"{net_name}_WLS_STD"] = {
            "network": net_name,
            "mode": "WLS_STD",
            "idx": idx,
            "P": solve_mapping(A, w_std[idx]),
            "weights": w_std[idx],
        }
        configs[f"{net_name}_WLS_MULTI"] = {
            "network": net_name,
            "mode": "WLS_MULTI",
            "idx": idx,
            "P": solve_mapping(A, w_multi[idx]),
            "weights": w_multi[idx],
        }

    # ------------------------------------------------------------------
    # Corrections and fixed reference
    # ------------------------------------------------------------------
    correction_modes = [
        x.strip().upper()
        for x in args.correction_modes.split(",")
        if x.strip()
    ]
    for x in correction_modes:
        if x not in ("NONE", "RAMP", "RAMP_SCN"):
            raise ValueError(f"unsupported correction mode: {x}")

    need_ramp = any(x in ("RAMP", "RAMP_SCN") for x in correction_modes)
    need_scn = any(x == "RAMP_SCN" for x in correction_modes)

    print("\n=== 7. load downstream correction fields ===")
    ramp = load_correction_matrix(dataset, "ramp", n_ps, n_image) if need_ramp else None
    scn = load_correction_matrix(dataset, "scn", n_ps, n_image) if need_scn else None
    if need_ramp and ramp is None:
        raise RuntimeError("RAMP requested but scla2.mat:ph_ramp unavailable")
    if need_scn and scn is None:
        raise RuntimeError("RAMP_SCN requested but uw_space_time.mat:ph_scn unavailable")

    # Fixed reference PS.
    # Prefer the exact established Final-C PS index list so all branches use the
    # identical 65-PS reference set, not merely a newly queried 500 m circle.
    ps_tree = cKDTree(ps_xy)
    final_candidates_for_ref = sorted(
        [
            p for p in dataset.glob("final_C_fixed_reference_*")
            if (p / "reference" / "reference_ps_indices_1based.txt").exists()
        ],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )

    if final_candidates_for_ref:
        ref_file = (
            final_candidates_for_ref[0]
            / "reference"
            / "reference_ps_indices_1based.txt"
        )
        ref_ids = np.asarray(
            np.loadtxt(ref_file, dtype=np.int64),
            dtype=np.int64,
        ).reshape(-1) - 1
        ref_ids = np.unique(ref_ids)
        if (
            len(ref_ids) < 10
            or np.any(ref_ids < 0)
            or np.any(ref_ids >= n_ps)
        ):
            raise RuntimeError(f"Invalid established reference PS indices: {ref_file}")

        center_ps = int(ref_ids[
            np.argmin(
                (lon[ref_ids] - args.reference_lon) ** 2
                + (lat[ref_ids] - args.reference_lat) ** 2
            )
        ])
        ref_lon = float(args.reference_lon)
        ref_lat = float(args.reference_lat)
        reference_source = str(ref_file)
    else:
        refx, refy = lonlat_to_xy(
            args.reference_lon, args.reference_lat, lon0, lat0
        )
        _, center_ps = ps_tree.query([refx, refy], k=1)
        center_ps = int(center_ps)
        ref_ids = np.asarray(
            ps_tree.query_ball_point(
                ps_xy[center_ps],
                r=args.reference_radius_m,
            ),
            dtype=np.int64,
        )
        ref_ids = np.unique(ref_ids)
        if len(ref_ids) < 10:
            raise RuntimeError(f"Reference region only contains {len(ref_ids)} PS")
        ref_lon = float(lon[center_ps])
        ref_lat = float(lat[center_ps])
        reference_source = "requeried_500m_circle_fallback"

    print(
        f"reference center={ref_lon:.8f},{ref_lat:.8f}, "
        f"R={args.reference_radius_m:.0f}m, PS={len(ref_ids)}, "
        f"source={reference_source}"
    )

    # ------------------------------------------------------------------
    # 8. Truth and PS->truth mappings once
    # ------------------------------------------------------------------
    print("\n=== 8. truth preparation ===")
    truth_data = {}
    for year in (2021, 2022, 2023):
        p = truth_dir / f"result{year}.shp"
        if not p.exists():
            raise FileNotFoundError(p)
        tlon, tlat, tx, ty, tv_raw, vf = read_truth_cropped(
            p,
            args.truth_field,
            args.truth_scale,
            lon0,
            lat0,
            ps_bbox,
            args.truth_buffer_m,
        )
        tt = cKDTree(np.column_stack([tx, ty]))
        refx_truth, refy_truth = lonlat_to_xy(
            ref_lon, ref_lat, lon0, lat0
        )
        truth_ref_ids = np.asarray(
            tt.query_ball_point(
                [refx_truth, refy_truth],
                r=args.reference_radius_m,
            ),
            dtype=np.int64,
        )
        if len(truth_ref_ids) < 10:
            raise RuntimeError(f"{year}: too few truth points in reference circle")
        truth_ref = float(np.nanmedian(tv_raw[truth_ref_ids]))
        tv = tv_raw - truth_ref
        pidx, tidx, dist = unique_ps_truth_mapping(
            ps_xy,
            np.column_stack([tx, ty]),
            args.match_m,
        )
        truth_data[year] = {
            "truth_v": tv,
            "pidx": pidx,
            "tidx": tidx,
            "dist": dist,
            "truth_ref": truth_ref,
            "vfield": vf,
        }
        print(
            f"{year}: truth={len(tv)}, matched={len(pidx)}, "
            f"truth_ref={truth_ref:.4f} mm/yr"
        )

    # ------------------------------------------------------------------
    # 9. Precompute correction phase rates
    # ------------------------------------------------------------------
    years_all = sorted(set(d.year for d in dates_dt))
    coeffs = {"full": slope_coefficients(dates_dt, None)[0]}
    for yy in years_all:
        coeffs[str(yy)] = slope_coefficients(dates_dt, yy)[0]

    corr_rate = {"NONE": {}}
    for mode in correction_modes:
        corr_rate.setdefault(mode, {})
        for label, c in coeffs.items():
            rr = np.zeros(n_ps, dtype=np.float64)
            if mode in ("RAMP", "RAMP_SCN"):
                rr += np.asarray(ramp @ c, dtype=np.float64)
            if mode == "RAMP_SCN":
                rr += np.asarray(scn @ c, dtype=np.float64)
            corr_rate[mode][label] = rr

    # ------------------------------------------------------------------
    # 10. Branch annual velocity validation without forming full time series
    # ------------------------------------------------------------------
    print("\n=== 9. branch velocity A/B ===")
    branch_vel_2021_2023: Dict[str, Dict[int, np.ndarray]] = {}
    branch_year_rows = []
    branch_pooled_rows = []

    # Prepare observation phase rates for all configs and validation years.
    for cfg_name, cfg in configs.items():
        idx = cfg["idx"]
        P = cfg["P"]

        # Reference acquisition time series for exact per-epoch median reference.
        Yref = np.asarray(obs_reader.rows(ref_ids, idx), dtype=np.float64)
        if not np.all(np.isfinite(Yref)):
            raise RuntimeError(
                f"{cfg_name}: non-finite observation in fixed reference PS; "
                "row-dependent missing-data inversion is not enabled for production."
            )
        Xref_raw = apply_mapping_to_rows(Yref, P, n_image, sign)

        # Three validation-year phase rates in ONE read pass for this inversion config.
        eval_years = (2021, 2022, 2023)
        Q_eval = np.column_stack([
            phase_rate_edge_coeff(P, coeffs[str(year)]) * sign
            for year in eval_years
        ])
        raw_phase_rates_eval = compute_rates_from_obs(
            obs_reader, Q_eval, idx, n_ps, args.block_rows
        )

        for corr_mode in correction_modes:
            branch = f"{cfg_name}_{corr_mode}"
            branch_vel_2021_2023[branch] = {}

            # Exact reference time series after correction.
            Xref = Xref_raw.copy()
            if corr_mode in ("RAMP", "RAMP_SCN"):
                Xref -= np.asarray(ramp[ref_ids, :], dtype=np.float64)
            if corr_mode == "RAMP_SCN":
                Xref -= np.asarray(scn[ref_ids, :], dtype=np.float64)
            ref_ts = np.nanmedian(Xref, axis=0)

            pooled_pred = []
            pooled_truth = []

            for jj, year in enumerate(eval_years):
                c = coeffs[str(year)]
                raw_phase_rate = raw_phase_rates_eval[:, jj]
                phase_rate = raw_phase_rate - corr_rate[corr_mode][str(year)]
                ref_phase_rate = float(np.dot(ref_ts, c))
                vel = (phase_rate - ref_phase_rate) * phase_to_mm

                branch_vel_2021_2023[branch][year] = vel.astype(np.float32)

                td = truth_data[year]
                pidx = td["pidx"]
                tidx = td["tidx"]
                pred = vel[pidx]
                truth_v = td["truth_v"][tidx]
                mm = validation_metrics(pred, truth_v)
                branch_year_rows.append({
                    "branch": branch,
                    "network": cfg["network"],
                    "inversion": cfg["mode"],
                    "correction": corr_mode,
                    "year": year,
                    **mm,
                })
                valid_pair = np.isfinite(pred) & np.isfinite(truth_v)
                pooled_pred.append(pred[valid_pair])
                pooled_truth.append(truth_v[valid_pair])

                print(
                    f"{branch:32s} {year}: "
                    f"RMSE={mm['rmse_mm_yr']:.3f}, corr={mm['correlation']:.3f}"
                )

            pp = np.concatenate(pooled_pred)
            tt = np.concatenate(pooled_truth)
            pm = validation_metrics(pp, tt)
            branch_pooled_rows.append({
                "branch": branch,
                "network": cfg["network"],
                "inversion": cfg["mode"],
                "correction": corr_mode,
                **pm,
            })

        del raw_phase_rates_eval
        gc.collect()

    # Current final-C baseline if available.
    current_baseline = None
    final_candidates = sorted(
        [
            p for p in dataset.glob("final_C_fixed_reference_*")
            if (p / "velocity" / "final_C_velocity_points.npz").exists()
        ],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if final_candidates:
        fp = final_candidates[0] / "velocity" / "final_C_velocity_points.npz"
        with np.load(fp, allow_pickle=False) as z:
            pred_all = []
            truth_all = []
            baseline_year_rows = []
            for year in (2021, 2022, 2023):
                v = np.asarray(z[f"velocity_{year}_mm_yr"], dtype=float)
                td = truth_data[year]
                pidx, tidx = td["pidx"], td["tidx"]
                mm = validation_metrics(v[pidx], td["truth_v"][tidx])
                baseline_year_rows.append({
                    "branch": "CURRENT_FINAL_C",
                    "network": "current_custom",
                    "inversion": "current_custom",
                    "correction": "RAMP_SCN",
                    "year": year,
                    **mm,
                })
                good = np.isfinite(v[pidx]) & np.isfinite(td["truth_v"][tidx])
                pred_all.append(v[pidx][good])
                truth_all.append(td["truth_v"][tidx][good])
            current_baseline = {
                "branch": "CURRENT_FINAL_C",
                "network": "current_custom",
                "inversion": "current_custom",
                "correction": "RAMP_SCN",
                **validation_metrics(np.concatenate(pred_all), np.concatenate(truth_all)),
            }
            branch_year_rows.extend(baseline_year_rows)
            branch_pooled_rows.append(current_baseline)

    write_csv(out / "05_branch_validation_by_year.csv", branch_year_rows)
    write_csv(out / "06_branch_pooled_validation.csv", branch_pooled_rows)

    new_rows = [r for r in branch_pooled_rows if r["branch"] != "CURRENT_FINAL_C"]
    best_new = min(new_rows, key=lambda r: r["rmse_mm_yr"])
    if current_baseline is not None:
        improve = (
            current_baseline["rmse_mm_yr"] - best_new["rmse_mm_yr"]
        ) / current_baseline["rmse_mm_yr"]
    else:
        improve = np.nan

    best_meta = {
        "best_new_branch": best_new,
        "current_final_C": current_baseline,
        "relative_rmse_improvement_vs_current_final_C": improve,
        "classification": (
            "NEW_NETWORK_INVERSION_SUPPORTED"
            if current_baseline is not None and improve >= 0.02
            else
            "NEW_NETWORK_INVERSION_NOT_CLEARLY_BETTER"
        ),
        "edge_sign": sign_meta,
    }
    (out / "07_best_branch.json").write_text(
        json.dumps(best_meta, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    print("\nBEST NEW:", json.dumps(best_new, ensure_ascii=False, indent=2))
    if current_baseline:
        print(
            f"relative improvement vs current final-C = "
            f"{100*improve:.2f}%"
        )

    # ------------------------------------------------------------------
    # 11. Generate full-period + annual products and full TS for best new branch
    # ------------------------------------------------------------------
    write_product = (
        args.always_write_product
        or current_baseline is None
        or (
            np.isfinite(improve)
            and improve >= args.min_improvement_to_write_product
        )
    )

    if not write_product:
        print()
        print("=" * 78)
        print("FULL PRODUCT GENERATION SKIPPED")
        print("=" * 78)
        print(
            "Best new branch does not beat current Final-C by the required "
            f"{100*args.min_improvement_to_write_product:.1f}%."
        )
        print("Diagnostics and validation CSV/JSON are complete.")
        print("Use --always-write-product only for a deliberate diagnostic product.")

        manifest = {
            "dataset": str(dataset),
            "project": str(project),
            "input_unwrapped": f"{args.unwrapped_file}:{args.unwrapped_var}",
            "input_wrapped_continuity": f"{args.wrapped_file}:{args.wrapped_var}",
            "n_ps": n_ps,
            "n_image": n_image,
            "n_ifg_original": n_ifg,
            "n_ifg_selected": int(len(selected_idx)),
            "network_before": before,
            "network_after": after,
            "coherence": coh_meta,
            "coherence_used_in_hard_selection": coherence_enabled_for_score,
            "hard_risk_weights": risk_weights,
            "edge_sign": sign_meta,
            "fixed_reference": {
                "lon": ref_lon,
                "lat": ref_lat,
                "radius_m": args.reference_radius_m,
                "ps_count": int(len(ref_ids)),
                "source": reference_source,
            },
            "best_new_branch": best_new,
            "current_final_C": current_baseline,
            "relative_rmse_improvement_vs_current_final_C": improve,
            "product_generation": "skipped_not_better_than_threshold",
            "method_note":
                "Hard deletion uses phase continuity, coherence/effective area when "
                "available, and ifg_std only. Network residual is diagnostic only. "
                "No new bridge edges are allowed.",
        }
        (out / "MANIFEST.json").write_text(
            json.dumps(manifest, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

        readme = f"""
IFG network selection + SBAS/WLS V2 diagnostics completed
============================================================================

Original IFGs : {n_ifg}
Selected IFGs : {len(selected_idx)}

Original bridges : {before['bridge_count']}
Selected bridges : {after['bridge_count']}

Best new branch:
  {best_new['branch']}

Best-new pooled RMSE:
  {best_new['rmse_mm_yr']:.6f} mm/yr

Current Final-C pooled RMSE:
  {current_baseline['rmse_mm_yr'] if current_baseline else 'N/A'}

Relative improvement:
  {100*improve if np.isfinite(improve) else float('nan'):.3f} %

Full candidate product was NOT written because the new branch did not exceed
the configured improvement threshold. Existing Final-C remains untouched.
""".strip()
        (out / "READ_ME_FIRST.txt").write_text(readme + "\n", encoding="utf-8")

        print()
        print("OUTPUT:", out)
        print("Inspect:")
        for p in [
            out / "00_coherence_grid_mapping_candidates.csv",
            out / "01_ifg_quality_and_selection.csv",
            out / "02_removed_ifgs.csv",
            out / "03_protected_weak_ifgs.csv",
            out / "04_network_summary.json",
            out / "05_branch_validation_by_year.csv",
            out / "06_branch_pooled_validation.csv",
            out / "07_best_branch.json",
            out / "MANIFEST.json",
        ]:
            if p.exists():
                print(" ", p)
        return

    best_branch = best_new["branch"]
    parts = best_branch.rsplit("_", 1)
    # correction suffix can contain underscore; resolve by longest known mode.
    corr_mode = None
    cfg_name = None
    for cm in sorted(correction_modes, key=len, reverse=True):
        suffix = "_" + cm
        if best_branch.endswith(suffix):
            corr_mode = cm
            cfg_name = best_branch[:-len(suffix)]
            break
    if corr_mode is None or cfg_name not in configs:
        raise RuntimeError(f"Cannot parse best branch {best_branch}")

    cfg = configs[cfg_name]
    idx = cfg["idx"]
    P = cfg["P"]

    # Exact reference TS.
    Yref = np.asarray(obs_reader.rows(ref_ids, idx), dtype=np.float64)
    Xref = apply_mapping_to_rows(Yref, P, n_image, sign)
    if corr_mode in ("RAMP", "RAMP_SCN"):
        Xref -= np.asarray(ramp[ref_ids, :], dtype=np.float64)
    if corr_mode == "RAMP_SCN":
        Xref -= np.asarray(scn[ref_ids, :], dtype=np.float64)
    ref_ts = np.nanmedian(Xref, axis=0)

    product_dir = out / "best_new_product"
    product_dir.mkdir(parents=True, exist_ok=True)

    # Compute all full/annual phase rates for the winning branch in ONE IFG read pass.
    product_labels = list(coeffs.keys())
    Q_product = np.column_stack([
        phase_rate_edge_coeff(P, coeffs[label]) * sign
        for label in product_labels
    ])
    raw_product_rates = compute_rates_from_obs(
        obs_reader, Q_product, idx, n_ps, args.block_rows
    )

    velocity_product = {}
    for jj, label in enumerate(product_labels):
        c = coeffs[label]
        phase_rate = raw_product_rates[:, jj] - corr_rate[corr_mode][label]
        ref_phase_rate = float(np.dot(ref_ts, c))
        velocity_product[label] = (
            (phase_rate - ref_phase_rate) * phase_to_mm
        ).astype(np.float32)

    del raw_product_rates
    gc.collect()

    npz_payload = {
        "ps_index_1based": np.arange(1, n_ps+1, dtype=np.int32),
        "lon": lon.astype(np.float64),
        "lat": lat.astype(np.float64),
        "full_velocity_mm_yr": velocity_product["full"],
        "selected_ifg_index_1based": idx.astype(np.int32) + 1,
    }
    for yy in years_all:
        if str(yy) in velocity_product:
            npz_payload[f"velocity_{yy}_mm_yr"] = velocity_product[str(yy)]
    np.savez_compressed(
        product_dir / "best_new_velocity_points.npz",
        **npz_payload,
    )

    # HDF5 time series for winning new branch.
    if not args.no_write_timeseries:
        print("\n=== 10. write best-new time series HDF5 ===")
        import h5py
        h5p = product_dir / "best_new_timeseries.h5"
        with h5py.File(h5p, "w") as h:
            h.attrs["branch"] = best_branch
            h.attrs["edge_sign"] = sign
            h.attrs["reference_lon"] = ref_lon
            h.attrs["reference_lat"] = ref_lat
            h.attrs["reference_radius_m"] = args.reference_radius_m
            h.attrs["reference_ps_count"] = len(ref_ids)
            h.attrs["phase_to_los_mm_per_rad"] = phase_to_mm
            h.create_dataset("lon", data=lon.astype(np.float64), compression="lzf")
            h.create_dataset("lat", data=lat.astype(np.float64), compression="lzf")
            h.create_dataset(
                "date_yyyymmdd",
                data=np.asarray([int(d) for d in dates], dtype=np.int32),
            )
            h.create_dataset(
                "selected_ifg_index_1based",
                data=idx.astype(np.int32)+1,
            )
            ds = h.create_dataset(
                "los_displacement_mm",
                shape=(n_ps, n_image),
                dtype="f4",
                chunks=(min(args.block_rows, n_ps), n_image),
                compression="lzf",
            )
            missing_rows_total = 0
            for r0 in range(0, n_ps, args.block_rows):
                r1 = min(n_ps, r0 + args.block_rows)
                Y = np.asarray(obs_reader.block(r0, r1, idx), dtype=np.float64)
                good = np.all(np.isfinite(Y), axis=1)
                X = np.full((r1-r0, n_image), np.nan, dtype=np.float64)
                if np.any(good):
                    X[good] = apply_mapping_to_rows(Y[good], P, n_image, sign)
                    if corr_mode in ("RAMP", "RAMP_SCN"):
                        X[good] -= np.asarray(ramp[r0:r1, :][good], dtype=np.float64)
                    if corr_mode == "RAMP_SCN":
                        X[good] -= np.asarray(scn[r0:r1, :][good], dtype=np.float64)
                    X[good] -= ref_ts[None, :]
                missing_rows_total += int(np.count_nonzero(~good))
                ds[r0:r1, :] = (X * phase_to_mm).astype(np.float32)
            h.attrs["rows_with_any_missing_selected_ifg"] = missing_rows_total

    # GeoTIFFs for best new branch.
    raster_template = Path(args.raster_template)
    if not raster_template.is_absolute():
        raster_template = dataset / raster_template
    if not args.no_write_tifs and raster_template.exists():
        print("\n=== 11. write best-new GeoTIFF velocities ===")
        psidx, flat, profile, width, height = raster_assignment(
            lon, lat, raster_template
        )
        common_tags = {
            "source_branch": best_branch,
            "reference_lon": f"{ref_lon:.10f}",
            "reference_lat": f"{ref_lat:.10f}",
            "reference_radius_m": f"{args.reference_radius_m:.3f}",
            "units": "mm/year",
            "rasterization": "median_of_PS_in_template_pixel",
            "selected_ifg_count": str(len(idx)),
        }
        write_ps_median_tif(
            product_dir / "full_period_velocity.tif",
            velocity_product["full"],
            psidx, flat, profile, width, height,
            {**common_tags, "period": "full"},
        )
        ann_dir = product_dir / "annual_velocity"
        for yy in years_all:
            key = str(yy)
            if key not in velocity_product:
                continue
            write_ps_median_tif(
                ann_dir / f"annual_velocity_{yy}.tif",
                velocity_product[key],
                psidx, flat, profile, width, height,
                {**common_tags, "period": key},
            )

    # Final manifest.
    manifest = {
        "dataset": str(dataset),
        "project": str(project),
        "input_unwrapped": f"{args.unwrapped_file}:{args.unwrapped_var}",
        "input_wrapped_continuity": f"{args.wrapped_file}:{args.wrapped_var}",
        "n_ps": n_ps,
        "n_image": n_image,
        "n_ifg_original": n_ifg,
        "n_ifg_selected": int(len(selected_idx)),
        "network_before": before,
        "network_after": after,
        "coherence": coh_meta,
        "coherence_used_in_composite_score": coherence_enabled_for_score,
        "risk_weights": risk_weights,
        "edge_sign": sign_meta,
        "fixed_reference": {
            "lon": ref_lon,
            "lat": ref_lat,
            "radius_m": args.reference_radius_m,
            "ps_count": int(len(ref_ids)),
        },
        "phase_to_mm": phase_to_mm,
        "wavelength_m": wavelength,
        "wavelength_source": wavelength_source,
        "best_new_branch": best_new,
        "current_final_C": current_baseline,
        "relative_rmse_improvement_vs_current_final_C": improve,
        "best_product_dir": str(product_dir),
        "important_method_note":
            "Temporal/perpendicular baselines are not used as quality criteria here. "
            "Hard deletion requires independent evidence from phase continuity, "
            "coherence/effective area when available, and ifg_std. Network residual is "
            "diagnostic only. Dynamic protection keeps connectivity, degree floor, and "
            "does not allow any new bridge edges. The network is not reduced to an MST.",
    }
    (out / "MANIFEST.json").write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )

    readme = f"""
IFG network selection + SBAS/WLS inversion completed
============================================================================

Original IFGs : {n_ifg}
Selected IFGs : {len(selected_idx)}

Original network:
  components = {before['components']}
  rank       = {before['rank']}
  cycles     = {before['cycle_dimension']}
  bridges    = {before['bridge_count']}

Selected network:
  components = {after['components']}
  rank       = {after['rank']}
  cycles     = {after['cycle_dimension']}
  bridges    = {after['bridge_count']}

Selection is NOT "delete to MST".
Every attempted removal is rejected if it would disconnect the network,
violate the conservative node-degree floor, or create any new bridge edge.

Quality indicators:
  1. wrapped-phase spatial continuity (primary)
  2. GAMMA per-IFG coherence / PS-sampled effective coherence ratio when found
  3. ifg_std
  4. network residual consistency (diagnostic / soft-WLS only; never hard deletion)

Best new branch:
  {best_branch}

Best-new pooled 2021-2023 RMSE:
  {best_new['rmse_mm_yr']:.6f} mm/yr

Current final-C pooled RMSE:
  {current_baseline['rmse_mm_yr'] if current_baseline else 'N/A'}

Relative improvement vs current final-C:
  {100*improve if np.isfinite(improve) else float('nan'):.3f} %

Important outputs:
  01_ifg_quality_and_selection.csv
  02_removed_ifgs.csv
  03_protected_weak_ifgs.csv
  04_network_summary.json
  05_branch_validation_by_year.csv
  06_branch_pooled_validation.csv
  07_best_branch.json
  selected_ifg_indices_1based.txt
  selected_ifg_date12.txt
  best_new_product/best_new_velocity_points.npz
  best_new_product/best_new_timeseries.h5
  best_new_product/full_period_velocity.tif
  best_new_product/annual_velocity/*.tif

Do not replace the current production result merely because a new branch wins by
a tiny amount.  Use 07_best_branch.json and inspect yearly metrics, the selected
network, protected weak IFGs, and maps.
""".strip()

    (out / "READ_ME_FIRST.txt").write_text(readme + "\n", encoding="utf-8")

    print()
    print("=" * 78)
    print("PIPELINE COMPLETE")
    print("=" * 78)
    print("output:", out)
    print("selected IFGs:", len(selected_idx), "/", n_ifg)
    print("best new branch:", best_branch)
    print("best new pooled RMSE:", best_new["rmse_mm_yr"])
    if current_baseline:
        print("current final-C pooled RMSE:", current_baseline["rmse_mm_yr"])
        print("relative improvement:", f"{100*improve:.2f}%")
    print()
    print("First inspect:")
    for p in [
        out / "03_protected_weak_ifgs.csv",
        out / "04_network_summary.json",
        out / "05_branch_validation_by_year.csv",
        out / "06_branch_pooled_validation.csv",
        out / "07_best_branch.json",
        out / "MANIFEST.json",
    ]:
        print(" ", p)


if __name__ == "__main__":
    main()
