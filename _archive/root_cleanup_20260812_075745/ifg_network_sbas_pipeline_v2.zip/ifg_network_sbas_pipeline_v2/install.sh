#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/home/ubuntu/software/pystamps-main}"
PYTHON="${PYTHON:-/home/ubuntu/software/miniconda3/envs/stamps/bin/python}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$ROOT/tools"

cp "$HERE/ifg_network_sbas_pipeline_v2.py" "$ROOT/tools/ifg_network_sbas_v2.py"
cp "$HERE/run_ifg_network_sbas_v2.sh" "$ROOT/run_ifg_network_sbas_v2.sh"

chmod +x "$ROOT/tools/ifg_network_sbas_v2.py"
chmod +x "$ROOT/run_ifg_network_sbas_v2.sh"

echo "Installed:"
echo "  $ROOT/tools/ifg_network_sbas_v2.py"
echo "  $ROOT/run_ifg_network_sbas_v2.sh"
echo
echo "Existing V1, Final-C, Stage6/7/8 outputs are NOT modified."
echo "No conda/pip packages are changed."

echo
echo "Dependency check:"
"$PYTHON" - <<'PY'
mods = ["numpy","scipy","h5py","geopandas","rasterio","pyproj","pandas"]
missing = []
for m in mods:
    try:
        __import__(m)
        print("  OK ", m)
    except Exception as e:
        print("  MISS", m, repr(e))
        missing.append(m)
if missing:
    raise SystemExit(
        "Missing dependencies: " + ", ".join(missing) +
        ". Do NOT change the environment blindly."
    )
PY

echo
echo "Self-test:"
"$ROOT/run_ifg_network_sbas_v2.sh" --self-test

echo
echo "Installation complete."
echo "Run:"
echo "  cd '$ROOT'"
echo "  ./run_ifg_network_sbas_v2.sh"

if [[ "${1:-}" == "--run" ]]; then
  shift
  echo
  echo "Running V2 now..."
  exec "$ROOT/run_ifg_network_sbas_v2.sh" "$@"
fi
