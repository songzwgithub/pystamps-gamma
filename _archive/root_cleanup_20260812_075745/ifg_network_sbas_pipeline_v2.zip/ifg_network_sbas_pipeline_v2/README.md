# IFG network selection + SBAS/WLS pipeline V2

V2 fixes the two main problems exposed by the V1 run:

1. the production coherence raster grid was not mapped correctly;
2. the selected network stayed connected but created 25 bridge edges and became structurally fragile.

## What changes in V2

### Hard deletion evidence

Only three independent evidence families may vote to remove an IFG:

- wrapped-phase spatial continuity;
- per-IFG coherence / effective coherent-area ratio, when mapped reliably;
- `ifgstd2.mat:ifg_std`.

`network residual` is **diagnostic only** and never casts a hard-delete vote, because
the current 4:1 multilooked GAMMA data have verified intrinsic non-closure.

If per-IFG coherence cannot be mapped, V2 requires **both** phase-continuity and
`ifg_std` evidence before an IFG can become a deletion candidate.

### Stronger network protection

Every attempted deletion must preserve:

- one connected component;
- full network rank;
- the conservative degree floor (default 3);
- **no increase in bridge-edge count**.

The original Cangzhou network had zero bridges, so the selected V2 network must also
have zero bridges. The goal is not to reach an MST.

### Coherence grid mapping

V1 trusted the first MLI parameter file and selected a 2760×4551 grid. V2 instead:

- indexes candidate per-IFG coherence files;
- scans multiple GAMMA parameter files;
- derives plausible dimensions from coherence file sizes;
- jointly scores raster dimensions and `ps2.mat:ij` row/column/base mappings;
- writes `00_coherence_grid_mapping_candidates.csv` for audit.

Coherence enters hard selection only if coverage across IFGs reaches the configured
minimum (default 80%).

### Safer product generation

V2 always completes network and truth-validation diagnostics. It writes the expensive
full candidate time-series/GeoTIFF product only when the best new branch improves the
current Final-C pooled RMSE by at least 2% by default.

Use `--always-write-product` only if you deliberately want a worse diagnostic product.

## Install

```bash
cd /home/ubuntu/software/pystamps-main

rm -rf /tmp/ifg_sbas_v2
mkdir -p /tmp/ifg_sbas_v2

unzip /上传目录/ifg_network_sbas_pipeline_v2.zip -d /tmp/ifg_sbas_v2

bash /tmp/ifg_sbas_v2/ifg_network_sbas_pipeline_v2/install.sh
```

Run:

```bash
cd /home/ubuntu/software/pystamps-main
./run_ifg_network_sbas_v2.sh
```

## Important defaults

```text
bad_metric_risk       = 0.80
min_bad_votes         = 2
hard composite min    = 0.70
max remove fraction   = 0.15
degree floor          = 3
new bridge allowance  = 0 when original bridge count = 0
```

These are deliberately conservative.

## First outputs to inspect

```bash
D=/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized

LATEST=$(
  find "$D/_audit" -maxdepth 1 -type d \
    -name 'ifg_select_sbas_v2_*' \
    -printf '%T@ %p\n' |
  sort -nr | head -1 | cut -d' ' -f2-
)

echo "===== COHERENCE GRID MAPPING ====="
column -s, -t "$LATEST/00_coherence_grid_mapping_candidates.csv" | head -20

echo "===== NETWORK ====="
cat "$LATEST/04_network_summary.json"

echo "===== REMOVED ====="
column -s, -t "$LATEST/02_removed_ifgs.csv" | head -30

echo "===== PROTECTED ====="
column -s, -t "$LATEST/03_protected_weak_ifgs.csv" | head -30

echo "===== POOLED ====="
column -s, -t "$LATEST/06_branch_pooled_validation.csv"

echo "===== BEST ====="
cat "$LATEST/07_best_branch.json"
```
