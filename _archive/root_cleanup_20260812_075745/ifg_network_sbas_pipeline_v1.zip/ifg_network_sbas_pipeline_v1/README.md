# IFG network selection + SBAS/WLS inversion v1

This bundle installs a self-contained pipeline into:

- `/home/ubuntu/software/pystamps-main/tools/ifg_network_sbas_v1.py`
- `/home/ubuntu/software/pystamps-main/run_ifg_network_sbas_v1.sh`

It does **not** change NumPy, Conda, MintPy, pySTAMPS, GAMMA, or any existing Stage6/7/8 result.

## Scientific logic

The IFGs were already generated with small temporal/perpendicular baselines, so this pipeline does not use temporal/perpendicular baseline as a screening criterion.

The selection uses four data-quality families:

1. wrapped-phase spatial continuity (`ph2.mat:ph`) — primary;
2. per-IFG GAMMA coherence / PS-sampled effective coherence ratio — optional and auto-detected;
3. `ifgstd2.mat:ifg_std`;
4. network-inversion residual consistency — auxiliary only, because this dataset has confirmed multilook-induced non-closure.

Candidate bad IFGs are considered in descending quality-risk order. An IFG is removed only when doing so:

- keeps the 257-acquisition network connected;
- keeps full network rank;
- does not violate the conservative node-degree floor.

Thus the network is **not** reduced to a minimum spanning tree. Weak edges that are necessary for connectivity remain and are labelled in `03_protected_weak_ifgs.csv`.

## Inversion A/B branches

For both the full network and the selected network:

- OLS (uniform SBAS-like network LS);
- WLS_STD (`1 / ifg_std²`);
- WLS_MULTI (inverse-variance weight with soft multi-quality damping).

Each is tested with downstream:

- `RAMP`;
- `RAMP_SCN`.

The fixed reference is the established 500 m reference around approximately:

- lon `117.21775055`
- lat `38.40310669`

All branches are compared against `result2021.shp`, `result2022.shp`, `result2023.shp` in the same reference frame, with no additional offset or plane alignment.

The best **new** branch is then used to create:

- full referenced displacement time series HDF5;
- full-period velocity;
- annual velocities;
- GeoTIFFs.

The current `final-C` result remains untouched and is included as a validation baseline.

## Install

```bash
cd /home/ubuntu/software/pystamps-main
unzip /上传目录/ifg_network_sbas_pipeline_v1.zip -d /tmp/ifg_sbas_v1
bash /tmp/ifg_sbas_v1/ifg_network_sbas_pipeline_v1/install.sh
```

Or install and immediately run:

```bash
bash /tmp/ifg_sbas_v1/ifg_network_sbas_pipeline_v1/install.sh --run
```

## Run

```bash
cd /home/ubuntu/software/pystamps-main
./run_ifg_network_sbas_v1.sh
```

Useful optional controls:

```bash
./run_ifg_network_sbas_v1.sh \
  --continuity-sample 25000 \
  --network-resid-sample 12000 \
  --bad-metric-risk 0.80 \
  --min-bad-votes 2 \
  --composite-remove-min 0.65 \
  --degree-floor 2
```

If GAMMA per-IFG coherence files are absent or cannot be mapped reliably, the program records that fact and falls back to the other quality metrics. To explicitly skip the coherence-raster scan:

```bash
./run_ifg_network_sbas_v1.sh --skip-coherence
```

## First outputs to inspect

```text
01_ifg_quality_and_selection.csv
02_removed_ifgs.csv
03_protected_weak_ifgs.csv
04_network_summary.json
05_branch_validation_by_year.csv
06_branch_pooled_validation.csv
07_best_branch.json
MANIFEST.json
```

The output directory is created under:

```text
<dataset>/_audit/ifg_select_sbas_v1_<timestamp>
```

## Important caution

`WLS_MULTI` is a diagnostic extension. `WLS_STD` is the more directly interpretable inverse-variance branch. Do not promote a branch solely because of a very small truth-RMSE advantage; inspect yearly behavior, protected weak edges, selected-network redundancy, and maps.
