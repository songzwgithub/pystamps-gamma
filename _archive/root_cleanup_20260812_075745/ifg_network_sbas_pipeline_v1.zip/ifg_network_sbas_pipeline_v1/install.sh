#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/home/ubuntu/software/pystamps-main}"
PYTHON="${PYTHON:-/home/ubuntu/software/miniconda3/envs/stamps/bin/python}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$ROOT/tools"

cp "$HERE/ifg_network_sbas_pipeline.py" "$ROOT/tools/ifg_network_sbas_v1.py"
cp "$HERE/run_ifg_network_sbas.sh" "$ROOT/run_ifg_network_sbas_v1.sh"

chmod +x "$ROOT/tools/ifg_network_sbas_v1.py"
chmod +x "$ROOT/run_ifg_network_sbas_v1.sh"

echo "Installed:"
echo "  $ROOT/tools/ifg_network_sbas_v1.py"
echo "  $ROOT/run_ifg_network_sbas_v1.sh"
echo
echo "No conda/pip packages were changed."

echo
echo "Dependency check:"
"$PYTHON" - <<'PY'
mods = ["numpy","scipy","h5py","geopandas","rasterio","pyproj","pandas"]
missing = []
for m in mods:
    try:
        __import__(m)
        print("  OK ", m)
    except Exception as e:
        print("  MISS", m, repr(e))
        missing.append(m)
if missing:
    raise SystemExit(
        "Missing dependencies: " + ", ".join(missing) +
        ". Do NOT change the environment blindly; install only after review."
    )
PY

echo
echo "Self-test:"
"$ROOT/run_ifg_network_sbas_v1.sh" --self-test

echo
echo "Installation complete."
echo
echo "Run:"
echo "  cd '$ROOT'"
echo "  ./run_ifg_network_sbas_v1.sh"

if [[ "${1:-}" == "--run" ]]; then
  shift
  echo
  echo "Running pipeline now..."
  exec "$ROOT/run_ifg_network_sbas_v1.sh" "$@"
fi
