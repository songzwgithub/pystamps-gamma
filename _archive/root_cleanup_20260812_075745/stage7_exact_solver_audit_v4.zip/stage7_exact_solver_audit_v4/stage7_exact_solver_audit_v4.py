#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
V4 Stage7 exact solver / reconstruction audit for the customized pySTAMPS SBAS chain.

Purpose
-------
After V2/V3 showed that:
  - IFG deletion degrades the solution even when topology remains healthy;
  - global WLS offers only small benefit;
  - per-PS/per-IFG coherence WLS degrades the solution;

the next question is:
    WHY is phuw_sm2.mat:ph_uw better than a direct full-network OLS acquisition
    solution, and exactly what does Stage7 do differently?

This script is READ-ONLY. It does not rerun Stage6/7/8 and never overwrites any
production MAT file.

It performs five audits:

A. Stage7 source-code discovery
   - locate stage7_sbas.py / related custom Stage7 code;
   - hash source files;
   - extract lines around key solver terms:
       ph_uw, ifg_vcm, pinv, lstsq, solve, weight, covariance, bperp,
       ph_scla, ph_ramp, ph_uw_deramped, ph_scn.

B. Direct full-network reconstruction
   - phuw2_gacos.mat:ph_uw [PS x IFG]
   - phuw2.mat:ph_uw       [PS x IFG]
   -> reconstruct acquisition phase using the exact 763-edge full network and OLS.
   - calibrate global edge sign against phuw_sm2.mat:ph_uw.

C. Stage7-vs-direct-OLS decomposition
   - common-mode aligned residual;
   - per-epoch XY-plane explainability;
   - residual after XY-plane removal;
   - full-period and annual slope contribution in mm/yr;
   - edge back-projection residuals.

D. Stage7 saved-variable identity search
   - inventory numeric variables in:
       phuw_sm2.mat, scla2.mat, scla_smooth2.mat, scla_sb2.mat, bp_sm2.mat,
       mean_v.mat, stage7_sbas_debug.json
   - for PS x acquisition variables, test whether they directly match:
       Stage7 ph_uw,
       Stage7 - OLS,
       Stage7 - OLS - plane,
       Stage7 ramp,
     after allowed common-mode alignment.
   - report top candidate identities instead of guessing.

E. Truth-isolation experiment
   With the exact fixed 65-PS reference and the same downstream corrections:
       OLS_GACOS_RAW
       STAGE7_RAW
       OLS_GACOS_LEGACY_RAMP_SCN
       STAGE7_LEGACY_RAMP_SCN  (should reproduce current Final-C annual chain)
   Compare 2021/2022/2023 and pooled truth metrics.
   This isolates the contribution of the Stage7 acquisition-space solution itself.

The script is designed for the current Cangzhou dataset:
  n_ps=375051, n_image=257, n_ifg=763
but reads dimensions dynamically.

No internet access and no environment modification are required.
"""

from __future__ import annotations

import argparse
import csv
import datetime as dt
import gc
import hashlib
import json
import math
import os
import re
import sys
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy.io import loadmat, whosmat
from scipy.spatial import cKDTree


# =============================================================================
# helpers
# =============================================================================

def write_csv(path: Path, rows: Sequence[Dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    fields: List[str] = []
    for r in rows:
        for k in r:
            if k not in fields:
                fields.append(k)
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def local_xy(lon, lat, lon0=None, lat0=None):
    lon = np.asarray(lon, dtype=float)
    lat = np.asarray(lat, dtype=float)
    if lon0 is None:
        lon0 = float(np.nanmedian(lon))
    if lat0 is None:
        lat0 = float(np.nanmedian(lat))
    R = 6371008.8
    x = np.deg2rad(lon - lon0) * R * math.cos(math.radians(lat0))
    y = np.deg2rad(lat - lat0) * R
    return x, y, float(lon0), float(lat0)


def lonlat_to_xy(lon, lat, lon0, lat0):
    R = 6371008.8
    x = math.radians(lon - lon0) * R * math.cos(math.radians(lat0))
    y = math.radians(lat - lat0) * R
    return x, y


def matlab_datenum_to_datetime(v: float) -> dt.datetime:
    ordinal = int(v)
    frac = float(v) - ordinal
    return (
        dt.datetime.fromordinal(ordinal)
        + dt.timedelta(days=frac)
        - dt.timedelta(days=366)
    )


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def mat_is_hdf5(path: Path) -> bool:
    try:
        import h5py
        with h5py.File(path, "r"):
            return True
    except Exception:
        return False


def classic_load_var(path: Path, var: str):
    obj = loadmat(
        path,
        variable_names=[var],
        squeeze_me=False,
        struct_as_record=False,
    )
    if var not in obj:
        raise KeyError(f"{path}:{var} not found")
    return np.asarray(obj[var])


class MatrixReader:
    """Read row blocks from classic MAT or MATLAB v7.3/HDF5."""

    def __init__(self, path: Path, var: str, nrow: int, ncol: int):
        self.path = Path(path)
        self.var = var
        self.nrow = int(nrow)
        self.ncol = int(ncol)
        self.hdf5 = mat_is_hdf5(self.path)
        self._classic = None
        self._transposed = False

        if self.hdf5:
            import h5py
            with h5py.File(self.path, "r") as h:
                if var not in h:
                    raise KeyError(f"{path}:{var} not found")
                shape = tuple(int(v) for v in h[var].shape)
            if shape == (nrow, ncol):
                self._transposed = False
            elif shape == (ncol, nrow):
                self._transposed = True
            else:
                raise ValueError(
                    f"{path}:{var} shape={shape}, expected "
                    f"({nrow},{ncol}) or ({ncol},{nrow})"
                )
        else:
            a = classic_load_var(path, var)
            if a.shape == (nrow, ncol):
                self._classic = a
            elif a.shape == (ncol, nrow):
                self._classic = a
                self._transposed = True
            else:
                raise ValueError(
                    f"{path}:{var} shape={a.shape}, expected "
                    f"({nrow},{ncol}) or ({ncol},{nrow})"
                )

    def rows(self, idx: np.ndarray) -> np.ndarray:
        idx = np.asarray(idx, dtype=np.int64)
        if self.hdf5:
            import h5py
            order = np.argsort(idx)
            sidx = idx[order]
            with h5py.File(self.path, "r") as h:
                ds = h[self.var]
                if not self._transposed:
                    a = np.asarray(ds[sidx, :])
                else:
                    a = np.asarray(ds[:, sidx]).T
            inv = np.empty_like(order)
            inv[order] = np.arange(len(order))
            return a[inv]
        a = self._classic.T if self._transposed else self._classic
        return np.asarray(a[idx, :])

    def block(self, r0: int, r1: int) -> np.ndarray:
        if self.hdf5:
            import h5py
            with h5py.File(self.path, "r") as h:
                ds = h[self.var]
                if not self._transposed:
                    return np.asarray(ds[r0:r1, :])
                return np.asarray(ds[:, r0:r1]).T
        a = self._classic.T if self._transposed else self._classic
        return np.asarray(a[r0:r1, :])


def mat_variable_inventory(path: Path) -> List[Dict[str, Any]]:
    rows = []
    if not path.exists():
        return rows

    if mat_is_hdf5(path):
        import h5py
        with h5py.File(path, "r") as h:
            def visit(name, obj):
                if isinstance(obj, h5py.Dataset):
                    rows.append({
                        "file": path.name,
                        "variable": name,
                        "shape": "x".join(str(int(v)) for v in obj.shape),
                        "dtype": str(obj.dtype),
                        "format": "hdf5",
                    })
            h.visititems(visit)
    else:
        for name, shape, dtype in whosmat(path):
            rows.append({
                "file": path.name,
                "variable": name,
                "shape": "x".join(str(int(v)) for v in shape),
                "dtype": str(dtype),
                "format": "classic",
            })
    return rows


# =============================================================================
# metadata/network
# =============================================================================

def load_ps_metadata(dataset: Path):
    obj = loadmat(
        dataset / "ps2.mat",
        variable_names=["n_ps", "n_image", "lonlat"],
        squeeze_me=True,
        struct_as_record=False,
    )
    n_ps = int(np.asarray(obj["n_ps"]).reshape(-1)[0])
    n_image = int(np.asarray(obj["n_image"]).reshape(-1)[0])
    lonlat = np.asarray(obj["lonlat"], dtype=float)
    if lonlat.shape[0] != n_ps and lonlat.shape[1] == n_ps:
        lonlat = lonlat.T
    return n_ps, n_image, lonlat[:, 0], lonlat[:, 1]


def load_network(dataset: Path, n_image: int):
    obj = loadmat(
        dataset / "phuw_sm2.mat",
        variable_names=["ifgday_ix", "day"],
        squeeze_me=True,
        struct_as_record=False,
    )
    ifg = np.asarray(obj["ifgday_ix"])
    if ifg.ndim == 2 and ifg.shape[0] == 2 and ifg.shape[1] != 2:
        ifg = ifg.T

    day = np.asarray(obj["day"], dtype=float).reshape(-1)
    dts = [matlab_datenum_to_datetime(v) for v in day]
    dates = [d.strftime("%Y%m%d") for d in dts]

    x = np.asarray(ifg, dtype=float)
    if (
        np.nanmin(x) >= 1
        and np.nanmax(x) <= n_image
        and np.allclose(x, np.round(x))
    ):
        edges = np.round(x).astype(int) - 1
        mode = "1based_acquisition_indices"
    elif (
        np.nanmin(x) >= 0
        and np.nanmax(x) < n_image
        and np.allclose(x, np.round(x))
    ):
        edges = np.round(x).astype(int)
        mode = "0based_acquisition_indices"
    else:
        lookup_day = {int(round(v)): i for i, v in enumerate(day)}
        lookup_date = {int(d): i for i, d in enumerate(dates)}
        edges = np.empty_like(x, dtype=int)
        for r in range(len(x)):
            for c in range(2):
                v = int(round(float(x[r, c])))
                if v in lookup_day:
                    edges[r, c] = lookup_day[v]
                elif v in lookup_date:
                    edges[r, c] = lookup_date[v]
                else:
                    raise ValueError(f"Cannot map ifgday_ix value {v}")
        mode = "date_values_mapped"

    return edges, dates, dts, day, mode


def incidence_design(edges: np.ndarray, n_image: int):
    A = np.zeros((len(edges), n_image - 1), dtype=np.float64)
    for k, (a, b) in enumerate(edges):
        if a != 0:
            A[k, a - 1] -= 1.0
        if b != 0:
            A[k, b - 1] += 1.0
    return A


def reconstruct_ols(Y_ifg: np.ndarray, P: np.ndarray, n_image: int, sign=1.0):
    X = np.zeros((len(Y_ifg), n_image), dtype=np.float64)
    X[:, 1:] = (Y_ifg @ P.T) * sign
    return X


def slope_coefficients(dts: Sequence[dt.datetime], year: Optional[int]):
    c = np.zeros(len(dts), dtype=np.float64)
    if year is None:
        idx = np.arange(len(dts))
    else:
        idx = np.asarray([i for i, d in enumerate(dts) if d.year == year], dtype=int)
    if len(idx) < 3:
        return c
    local = [dts[i] for i in idx]
    t0 = local[0]
    t = np.asarray(
        [(d - t0).total_seconds() / 86400.0 / 365.2425 for d in local],
        dtype=float,
    )
    tc = t - np.mean(t)
    den = float(np.sum(tc**2))
    if den > 0:
        c[idx] = tc / den
    return c


# =============================================================================
# source-code audit
# =============================================================================

def discover_stage7_sources(root: Path):
    patterns = [
        "**/stage7_sbas.py",
        "**/*stage7*sbas*.py",
        "**/*scla*.py",
    ]
    files = []
    for pat in patterns:
        for p in root.glob(pat):
            if p.is_file() and "__pycache__" not in str(p):
                files.append(p)
    # unique ordered
    seen = set()
    out = []
    for p in files:
        rp = p.resolve()
        if rp not in seen:
            seen.add(rp)
            out.append(rp)
    return out


def extract_source_hits(path: Path, keywords: Sequence[str], context: int = 4):
    text = path.read_text(encoding="utf-8", errors="ignore").splitlines()
    rows = []
    lower_kw = [k.lower() for k in keywords]

    hit_lines = set()
    for i, line in enumerate(text):
        ll = line.lower()
        if any(k in ll for k in lower_kw):
            for j in range(max(0, i-context), min(len(text), i+context+1)):
                hit_lines.add(j)

    for j in sorted(hit_lines):
        rows.append({
            "file": str(path),
            "line": j + 1,
            "text": text[j],
        })
    return rows


# =============================================================================
# spatial decomposition
# =============================================================================

def fit_plane_epochwise(D: np.ndarray, x: np.ndarray, y: np.ndarray):
    """Fit D[:,epoch] = a + b*x100km + c*y100km."""
    xn = x / 100000.0
    yn = y / 100000.0
    G = np.column_stack([np.ones(len(xn)), xn, yn])

    n_epoch = D.shape[1]
    coef = np.full((3, n_epoch), np.nan)
    r2 = np.full(n_epoch, np.nan)
    resid_p95 = np.full(n_epoch, np.nan)
    resid_std = np.full(n_epoch, np.nan)

    for j in range(n_epoch):
        z = D[:, j]
        good = np.isfinite(z)
        if np.count_nonzero(good) < 100:
            continue
        Gj = G[good]
        zj = z[good]
        beta, *_ = np.linalg.lstsq(Gj, zj, rcond=None)
        pred = Gj @ beta
        r = zj - pred

        ss_res = float(np.sum(r**2))
        ss_tot = float(np.sum((zj - np.mean(zj))**2))
        coef[:, j] = beta
        r2[j] = 1.0 - ss_res / ss_tot if ss_tot > 0 else np.nan
        resid_p95[j] = float(np.percentile(np.abs(r), 95))
        resid_std[j] = float(np.std(r))

    return coef, r2, resid_p95, resid_std


def remove_epoch_common_mode(D: np.ndarray):
    cm = np.nanmedian(D, axis=0)
    return D - cm[None, :], cm


def regression_metrics(a, b):
    good = np.isfinite(a) & np.isfinite(b)
    x = np.asarray(a[good], dtype=float)
    y = np.asarray(b[good], dtype=float)
    if len(x) < 3:
        return None
    if np.std(x) > 0 and np.std(y) > 0:
        corr = float(np.corrcoef(x, y)[0, 1])
    else:
        corr = np.nan
    G = np.column_stack([np.ones_like(x), x])
    beta, *_ = np.linalg.lstsq(G, y, rcond=None)
    e = y - x
    return {
        "n": int(len(x)),
        "median_abs_diff": float(np.median(np.abs(e))),
        "p95_abs_diff": float(np.percentile(np.abs(e), 95)),
        "rmse_diff": float(np.sqrt(np.mean(e**2))),
        "correlation": corr,
        "regression_y_vs_x_intercept": float(beta[0]),
        "regression_y_vs_x_slope": float(beta[1]),
    }


# =============================================================================
# truth
# =============================================================================

def norm_name(x):
    return re.sub(r"[^a-z0-9]", "", str(x).lower())


def choose_vfield(gdf, preferred: str):
    geom = gdf.geometry.name
    cols = [c for c in gdf.columns if c != geom]
    for c in cols:
        if c.lower() == preferred.lower():
            return c
    numeric = [c for c in cols if np.issubdtype(gdf[c].dtype, np.number)]
    for p in ("v", "vel", "velocity", "rate"):
        for c in numeric:
            if norm_name(c) == p:
                return c
    raise RuntimeError(f"Cannot identify truth field: {cols}")


def read_truth_cropped(
    path: Path,
    preferred_field: str,
    scale: float,
    lon0: float,
    lat0: float,
    ps_bbox: Tuple[float, float, float, float],
    buffer_m: float,
):
    import geopandas as gpd
    gdf = gpd.read_file(path)
    if gdf.crs is not None:
        gdf = gdf.to_crs(4326)
    vf = choose_vfield(gdf, preferred_field)
    lon = np.asarray(gdf.geometry.x, dtype=float)
    lat = np.asarray(gdf.geometry.y, dtype=float)
    v = np.asarray(gdf[vf], dtype=float) * scale
    good = np.isfinite(lon) & np.isfinite(lat) & np.isfinite(v)
    lon, lat, v = lon[good], lat[good], v[good]
    x, y, _, _ = local_xy(lon, lat, lon0, lat0)
    xmin, xmax, ymin, ymax = ps_bbox
    inside = (
        (x >= xmin-buffer_m) & (x <= xmax+buffer_m)
        & (y >= ymin-buffer_m) & (y <= ymax+buffer_m)
    )
    del gdf
    gc.collect()
    return lon[inside], lat[inside], x[inside], y[inside], v[inside], vf


def unique_ps_truth_mapping(ps_xy, truth_xy, match_m):
    tree = cKDTree(truth_xy)
    dist, tidx = tree.query(ps_xy, k=1, workers=-1)
    dist = np.asarray(dist, dtype=float)
    tidx = np.asarray(tidx, dtype=np.int64)
    within = np.isfinite(dist) & (dist <= match_m)
    p = np.flatnonzero(within)
    d = dist[within]
    t = tidx[within]
    order = np.argsort(d)
    t_order = t[order]
    _, first = np.unique(t_order, return_index=True)
    keep = np.sort(order[first])
    return p[keep], t[keep], d[keep]


def validation_metrics(pred, truth):
    good = np.isfinite(pred) & np.isfinite(truth)
    p = np.asarray(pred[good], dtype=float)
    t = np.asarray(truth[good], dtype=float)
    e = p - t
    if len(e) < 3:
        return None
    if np.std(p) > 0 and np.std(t) > 0:
        cc = float(np.corrcoef(p, t)[0, 1])
    else:
        cc = np.nan
    G = np.column_stack([np.ones_like(t), t])
    beta, *_ = np.linalg.lstsq(G, p, rcond=None)
    return {
        "n": int(len(e)),
        "rmse_mm_yr": float(np.sqrt(np.mean(e**2))),
        "mae_mm_yr": float(np.mean(np.abs(e))),
        "mean_bias_mm_yr": float(np.mean(e)),
        "median_bias_mm_yr": float(np.median(e)),
        "p95_abs_error_mm_yr": float(np.percentile(np.abs(e), 95)),
        "correlation": cc,
        "regression_intercept_mm_yr": float(beta[0]),
        "regression_pred_vs_truth_slope": float(beta[1]),
        "pred_std_mm_yr": float(np.std(p)),
        "truth_std_mm_yr": float(np.std(t)),
        "pred_std_over_truth_std": float(np.std(p)/np.std(t)) if np.std(t)>0 else np.nan,
    }


def exact_reference_indices(dataset: Path, n_ps: int):
    candidates = sorted(
        [
            p for p in dataset.glob("final_C_fixed_reference_*")
            if (p/"reference"/"reference_ps_indices_1based.txt").exists()
        ],
        key=lambda p: p.stat().st_mtime,
        reverse=True,
    )
    if not candidates:
        raise RuntimeError("Established Final-C reference PS list not found")
    p = candidates[0] / "reference" / "reference_ps_indices_1based.txt"
    ids = np.asarray(np.loadtxt(p, dtype=np.int64), dtype=np.int64).reshape(-1)-1
    ids = np.unique(ids)
    if np.any(ids < 0) or np.any(ids >= n_ps):
        raise RuntimeError(f"Invalid reference indices in {p}")
    return ids, str(p)


# =============================================================================
# candidate identity search
# =============================================================================

def load_ps_acq_candidate(path: Path, var: str, n_ps: int, n_image: int, sample_idx: np.ndarray):
    try:
        rdr = MatrixReader(path, var, n_ps, n_image)
        return np.asarray(rdr.rows(sample_idx), dtype=np.float64)
    except Exception:
        return None


def candidate_identity_scores(
    candidate_name: str,
    C: np.ndarray,
    targets: Dict[str, np.ndarray],
):
    rows = []
    for tname, T in targets.items():
        if C.shape != T.shape:
            continue

        # raw
        m = regression_metrics(C.ravel(), T.ravel())
        if m:
            rows.append({
                "candidate": candidate_name,
                "target": tname,
                "alignment": "raw",
                **m,
            })

        # epoch common-mode aligned
        D = T - C
        D2, cm = remove_epoch_common_mode(D)
        T_aligned = T - cm[None, :]
        m = regression_metrics(C.ravel(), T_aligned.ravel())
        if m:
            rows.append({
                "candidate": candidate_name,
                "target": tname,
                "alignment": "remove_target_minus_candidate_epoch_median",
                **m,
            })
    return rows


# =============================================================================
# CLI/main
# =============================================================================

def parse_args():
    p = argparse.ArgumentParser(
        description="Exact Stage7 solver/reconstruction audit"
    )
    p.add_argument(
        "--root",
        default="/home/ubuntu/software/pystamps-main",
    )
    p.add_argument(
        "--dataset",
        default="/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized",
    )
    p.add_argument(
        "--project",
        default="/mnt/vol-gdc28n1r/insar/cangzhou_P69",
    )
    p.add_argument("--out", default="")
    p.add_argument("--truth-dir", default="")
    p.add_argument("--truth-field", default="v")
    p.add_argument("--truth-scale", type=float, default=1.0)
    p.add_argument("--match-m", type=float, default=200.0)
    p.add_argument("--truth-buffer-m", type=float, default=1500.0)
    p.add_argument("--sample-ps", type=int, default=8000)
    p.add_argument("--edge-resid-sample-ps", type=int, default=4000)
    p.add_argument("--block-ps", type=int, default=5000)
    p.add_argument("--reference-lon", type=float, default=117.21775055)
    p.add_argument("--reference-lat", type=float, default=38.40310669)
    p.add_argument("--reference-radius-m", type=float, default=500.0)
    p.add_argument("--seed", type=int, default=20260811)
    p.add_argument("--self-test", action="store_true")
    return p.parse_args()


def self_test():
    rng = np.random.default_rng(0)
    n_image = 8
    edges = []
    for i in range(n_image):
        for d in (1,2,3):
            if i+d < n_image:
                edges.append((i, i+d))
    edges = np.asarray(edges)
    A = incidence_design(edges, n_image)
    P = np.linalg.pinv(A, rcond=1e-10)
    X = rng.normal(size=(20, n_image))
    X -= X[:, [0]]
    Y = np.empty((len(X), len(edges)))
    for k,(a,b) in enumerate(edges):
        Y[:,k] = X[:,b]-X[:,a]
    XR = reconstruct_ols(Y, P, n_image, sign=1.0)
    assert np.max(np.abs(X-XR)) < 1e-10

    x = rng.uniform(-1e4,1e4,100)
    y = rng.uniform(-1e4,1e4,100)
    D = np.column_stack([
        1 + 2*x/1e5 - 3*y/1e5,
        -2 + 0.5*x/1e5 + 1.2*y/1e5,
    ])
    coef,r2,_,_ = fit_plane_epochwise(D,x,y)
    assert np.nanmin(r2) > 0.999999
    print("SELF-TEST: PASS")


def main():
    args = parse_args()
    if args.self_test:
        self_test()
        return

    t0 = time.time()
    root = Path(args.root).resolve()
    dataset = Path(args.dataset).resolve()
    project = Path(args.project).resolve()
    truth_dir = Path(args.truth_dir).resolve() if args.truth_dir else dataset/"cangzhou"

    stamp = dt.datetime.now().strftime("%Y%m%d_%H%M%S")
    out = (
        Path(args.out).resolve()
        if args.out
        else dataset/"_audit"/f"stage7_exact_solver_audit_v4_{stamp}"
    )
    out.mkdir(parents=True, exist_ok=True)

    print("="*80)
    print("V4 Stage7 exact solver / reconstruction audit")
    print("="*80)
    print("root   :", root)
    print("dataset:", dataset)
    print("output :", out)
    print()

    # ------------------------------------------------------------------
    # metadata
    # ------------------------------------------------------------------
    n_ps, n_image, lon, lat = load_ps_metadata(dataset)
    edges, dates, dts, day, ifg_mode = load_network(dataset, n_image)
    n_ifg = len(edges)
    x, y, lon0, lat0 = local_xy(lon, lat)
    ps_xy = np.column_stack([x,y])
    ps_bbox = (float(x.min()),float(x.max()),float(y.min()),float(y.max()))

    wavelength = 0.0554657595
    # Try actual project radar frequency.
    c0 = 299792458.0
    par_candidates = list((project/"RSLC_cropped").glob("*.rslc.par"))
    for ppar in par_candidates[:100]:
        txt = ppar.read_text(encoding="utf-8",errors="ignore")
        m = re.search(r"radar_frequency:\s*([0-9.eE+-]+)",txt)
        if m:
            f=float(m.group(1))
            if f>1e8:
                wavelength=c0/f
                break
    phase_to_mm = -wavelength/(4*np.pi)*1000.0

    print(f"n_ps={n_ps}, n_image={n_image}, n_ifg={n_ifg}")
    print(f"dates={dates[0]}..{dates[-1]}")
    print(f"phase_to_mm={phase_to_mm:.9f}")
    print()

    # ------------------------------------------------------------------
    # A. Source-code audit
    # ------------------------------------------------------------------
    print("=== A. Stage7 source discovery ===")
    sources = discover_stage7_sources(root)
    source_rows = []
    for p in sources:
        source_rows.append({
            "path": str(p),
            "sha256": sha256_file(p),
            "size_bytes": p.stat().st_size,
        })
    write_csv(out/"01_stage7_source_files.csv", source_rows)

    keywords = [
        "ph_uw", "ifg_vcm", "pinv", "lstsq", "solve", "weight",
        "covariance", "bperp", "ph_scla", "ph_ramp",
        "ph_uw_deramped", "ph_scn", "scla", "sb_inv", "network",
    ]
    hit_rows = []
    for p in sources:
        hit_rows.extend(extract_source_hits(p, keywords, context=4))
    write_csv(out/"02_stage7_source_key_excerpts.csv", hit_rows)

    print(f"Stage7-like source files found: {len(sources)}")
    for r in source_rows[:10]:
        print(" ", r["path"])

    # ------------------------------------------------------------------
    # B. MAT inventory
    # ------------------------------------------------------------------
    print("\n=== B. Stage7/8 MAT inventory ===")
    files = [
        "phuw2.mat",
        "phuw2_gacos.mat",
        "phuw_sm2.mat",
        "scla2.mat",
        "scla_smooth2.mat",
        "scla_sb2.mat",
        "bp_sm2.mat",
        "mean_v.mat",
        "uw_space_time.mat",
    ]
    inv_rows = []
    for fn in files:
        inv_rows.extend(mat_variable_inventory(dataset/fn))
    write_csv(out/"03_mat_variable_inventory.csv", inv_rows)

    # ------------------------------------------------------------------
    # readers / OLS
    # ------------------------------------------------------------------
    A = incidence_design(edges,n_image)
    rankA = int(np.linalg.matrix_rank(A))
    P = np.linalg.pinv(A,rcond=1e-10)

    gacos_reader = MatrixReader(dataset/"phuw2_gacos.mat","ph_uw",n_ps,n_ifg)
    raw_reader = MatrixReader(dataset/"phuw2.mat","ph_uw",n_ps,n_ifg)
    stage7_reader = MatrixReader(dataset/"phuw_sm2.mat","ph_uw",n_ps,n_image)

    rng = np.random.default_rng(args.seed)
    sample = np.sort(rng.choice(n_ps,size=min(args.sample_ps,n_ps),replace=False))
    edge_sample = np.sort(rng.choice(n_ps,size=min(args.edge_resid_sample_ps,n_ps),replace=False))

    Yg = np.asarray(gacos_reader.rows(sample),dtype=np.float64)
    Yr = np.asarray(raw_reader.rows(sample),dtype=np.float64)
    S7 = np.asarray(stage7_reader.rows(sample),dtype=np.float64)

    OLSg_plus = reconstruct_ols(Yg,P,n_image,+1.0)
    OLSg_minus = reconstruct_ols(Yg,P,n_image,-1.0)

    # Sign using spatially aligned Stage7.
    sign_scores = {}
    for sgn,Xc in [(+1,OLSg_plus),(-1,OLSg_minus)]:
        D=S7-Xc
        D2,_=remove_epoch_common_mode(D)
        sign_scores[str(sgn)] = float(np.nanmedian(np.abs(D2)))
    edge_sign = +1.0 if sign_scores["1"] <= sign_scores["-1"] else -1.0

    OLSg = OLSg_plus if edge_sign>0 else OLSg_minus
    OLSr = reconstruct_ols(Yr,P,n_image,edge_sign)

    print(f"network rank={rankA}/{n_image-1}")
    print("edge sign scores:",sign_scores,"selected",edge_sign)

    # ------------------------------------------------------------------
    # C. decomposition
    # ------------------------------------------------------------------
    print("\n=== C. Stage7 vs direct OLS decomposition ===")
    Dg = S7 - OLSg
    Dg_aligned, cm_g = remove_epoch_common_mode(Dg)

    Dr = S7 - OLSr
    Dr_aligned, cm_r = remove_epoch_common_mode(Dr)

    coef_g,r2_g,p95_g,std_g = fit_plane_epochwise(Dg_aligned,x[sample],y[sample])
    plane_g = (
        np.column_stack([
            np.ones(len(sample)),
            x[sample]/100000.0,
            y[sample]/100000.0,
        ]) @ coef_g
    )
    Dg_after_plane = Dg_aligned-plane_g

    epoch_rows=[]
    for j,d in enumerate(dates):
        epoch_rows.append({
            "date":d,
            "common_mode_stage7_minus_ols_gacos_rad":float(cm_g[j]),
            "common_mode_stage7_minus_ols_raw_rad":float(cm_r[j]),
            "plane_r2_stage7_minus_ols_gacos":float(r2_g[j]),
            "plane_intercept_rad":float(coef_g[0,j]),
            "plane_x_rad_per_100km":float(coef_g[1,j]),
            "plane_y_rad_per_100km":float(coef_g[2,j]),
            "resid_after_plane_p95_rad":float(p95_g[j]),
            "resid_after_plane_std_rad":float(std_g[j]),
            "stage7_minus_ols_gacos_spatial_std_rad":float(np.nanstd(Dg_aligned[:,j])),
            "stage7_minus_ols_gacos_spatial_p95_abs_rad":float(np.nanpercentile(np.abs(Dg_aligned[:,j]),95)),
        })
    write_csv(out/"04_epoch_stage7_minus_ols_decomposition.csv",epoch_rows)

    # rate contribution
    rate_rows=[]
    coeffs={"full":slope_coefficients(dts,None)}
    for yy in sorted(set(d.year for d in dts)):
        coeffs[str(yy)] = slope_coefficients(dts,yy)

    for label,c in coeffs.items():
        if np.count_nonzero(c)==0:
            continue
        v_D=(Dg_aligned@c)*phase_to_mm
        v_Dp=(Dg_after_plane@c)*phase_to_mm
        rate_rows.append({
            "period":label,
            "stage7_minus_ols_gacos_median_abs_mm_yr":float(np.nanmedian(np.abs(v_D))),
            "stage7_minus_ols_gacos_p95_abs_mm_yr":float(np.nanpercentile(np.abs(v_D),95)),
            "after_removing_epoch_plane_median_abs_mm_yr":float(np.nanmedian(np.abs(v_Dp))),
            "after_removing_epoch_plane_p95_abs_mm_yr":float(np.nanpercentile(np.abs(v_Dp),95)),
        })
    write_csv(out/"05_stage7_minus_ols_rate_contribution.csv",rate_rows)

    print(
        "median epoch plane R2:",
        float(np.nanmedian(r2_g)),
        "P05:",
        float(np.nanpercentile(r2_g,5)),
    )

    # Edge residual comparison.
    Ye = np.asarray(gacos_reader.rows(edge_sample),dtype=np.float64)*edge_sign
    S7e = np.asarray(stage7_reader.rows(edge_sample),dtype=np.float64)
    Oe = reconstruct_ols(Ye/edge_sign,P,n_image,edge_sign)

    # predicted IFGs from acquisition phase
    pred_ols = np.empty_like(Ye)
    pred_s7 = np.empty_like(Ye)
    for k,(a,b) in enumerate(edges):
        pred_ols[:,k] = Oe[:,b]-Oe[:,a]
        pred_s7[:,k] = S7e[:,b]-S7e[:,a]
    Rols = Ye-pred_ols
    Rs7 = Ye-pred_s7

    edge_rows=[]
    for k,(a,b) in enumerate(edges):
        edge_rows.append({
            "ifg_index_1based":k+1,
            "date12":f"{dates[a]}_{dates[b]}",
            "ols_resid_median_abs_rad":float(np.nanmedian(np.abs(Rols[:,k]))),
            "ols_resid_p90_abs_rad":float(np.nanpercentile(np.abs(Rols[:,k]),90)),
            "stage7_resid_median_abs_rad":float(np.nanmedian(np.abs(Rs7[:,k]))),
            "stage7_resid_p90_abs_rad":float(np.nanpercentile(np.abs(Rs7[:,k]),90)),
        })
    write_csv(out/"06_edge_backprojection_residuals.csv",edge_rows)

    edge_summary={
        "OLS_resid_abs_median_all":float(np.nanmedian(np.abs(Rols))),
        "OLS_resid_abs_p95_all":float(np.nanpercentile(np.abs(Rols),95)),
        "Stage7_resid_abs_median_all":float(np.nanmedian(np.abs(Rs7))),
        "Stage7_resid_abs_p95_all":float(np.nanpercentile(np.abs(Rs7),95)),
        "note":"OLS must minimize unweighted L2 edge residual. Stage7 may intentionally have larger edge residual if it applies additional modelling/regularization.",
    }
    (out/"07_edge_backprojection_summary.json").write_text(
        json.dumps(edge_summary,ensure_ascii=False,indent=2),encoding="utf-8"
    )

    del Ye,S7e,Oe,pred_ols,pred_s7,Rols,Rs7
    gc.collect()

    # ------------------------------------------------------------------
    # D. saved-variable identity search
    # ------------------------------------------------------------------
    print("\n=== D. Stage7 saved-variable identity search ===")
    identity_targets = {
        "STAGE7_ph_uw":S7,
        "STAGE7_minus_OLS_GACOS_aligned":Dg_aligned,
        "STAGE7_minus_OLS_GACOS_after_plane":Dg_after_plane,
    }

    identity_rows=[]
    candidate_vars=[]

    for fn in [
        "phuw_sm2.mat","scla2.mat","scla_smooth2.mat",
        "scla_sb2.mat","bp_sm2.mat","mean_v.mat","uw_space_time.mat",
    ]:
        path=dataset/fn
        for inv in [r for r in inv_rows if r["file"]==fn]:
            var=inv["variable"]
            shape=inv["shape"]
            if shape not in (f"{n_ps}x{n_image}",f"{n_image}x{n_ps}"):
                continue
            # Avoid repeating primary target as a candidate except useful known vars.
            candidate_vars.append((path,var))

    seen=set()
    for path,var in candidate_vars:
        key=(str(path),var)
        if key in seen:
            continue
        seen.add(key)
        C=load_ps_acq_candidate(path,var,n_ps,n_image,sample)
        if C is None:
            continue
        cname=f"{path.name}:{var}"
        identity_rows.extend(candidate_identity_scores(cname,C,identity_targets))

        # Also exact algebraic tests against known Stage7 fields if names are relevant.
        del C
        gc.collect()

    identity_rows.sort(key=lambda r:r["median_abs_diff"])
    write_csv(out/"08_saved_variable_identity_scores.csv",identity_rows)

    # Known exact identities.
    known_rows=[]
    try:
        der=load_ps_acq_candidate(dataset/"phuw_sm2.mat","ph_uw_deramped",n_ps,n_image,sample)
        ramp=load_ps_acq_candidate(dataset/"scla2.mat","ph_ramp",n_ps,n_image,sample)
        if der is not None and ramp is not None:
            E=der-(S7-ramp)
            known_rows.append({
                "identity":"phuw_sm2.ph_uw_deramped == phuw_sm2.ph_uw - scla2.ph_ramp",
                "median_abs_residual_rad":float(np.nanmedian(np.abs(E))),
                "p95_abs_residual_rad":float(np.nanpercentile(np.abs(E),95)),
                "max_abs_residual_rad":float(np.nanmax(np.abs(E))),
            })
    except Exception as e:
        known_rows.append({
            "identity":"phuw_sm2.ph_uw_deramped identity",
            "error":repr(e),
        })
    write_csv(out/"09_known_stage7_identities.csv",known_rows)

    # ------------------------------------------------------------------
    # E. Truth isolation experiment
    # ------------------------------------------------------------------
    print("\n=== E. Truth isolation: Stage7 vs direct OLS under same corrections ===")
    ref_ids,ref_source=exact_reference_indices(dataset,n_ps)

    ramp_reader=MatrixReader(dataset/"scla2.mat","ph_ramp",n_ps,n_image)
    scn_reader=MatrixReader(dataset/"uw_space_time.mat","ph_scn",n_ps,n_image)

    # Exact reference time series for each branch.
    Yref=np.asarray(gacos_reader.rows(ref_ids),dtype=np.float64)
    OLSref=reconstruct_ols(Yref,P,n_image,edge_sign)
    S7ref=np.asarray(stage7_reader.rows(ref_ids),dtype=np.float64)
    Rref=np.asarray(ramp_reader.rows(ref_ids),dtype=np.float64)
    Cref=np.asarray(scn_reader.rows(ref_ids),dtype=np.float64)

    ref_ols_raw=np.nanmedian(OLSref,axis=0)
    ref_s7_raw=np.nanmedian(S7ref,axis=0)
    ref_ols_corr=np.nanmedian(OLSref-Rref-Cref,axis=0)
    ref_s7_corr=np.nanmedian(S7ref-Rref-Cref,axis=0)

    # Truth mappings once.
    truth={}
    refx,refy=lonlat_to_xy(args.reference_lon,args.reference_lat,lon0,lat0)
    for year in (2021,2022,2023):
        tlon,tlat,tx,ty,tv_raw,vf=read_truth_cropped(
            truth_dir/f"result{year}.shp",
            args.truth_field,args.truth_scale,lon0,lat0,ps_bbox,args.truth_buffer_m
        )
        tree=cKDTree(np.column_stack([tx,ty]))
        rids=np.asarray(tree.query_ball_point([refx,refy],r=args.reference_radius_m),dtype=np.int64)
        truth_ref=float(np.nanmedian(tv_raw[rids]))
        tv=tv_raw-truth_ref
        pidx,tidx,dist=unique_ps_truth_mapping(ps_xy,np.column_stack([tx,ty]),args.match_m)
        truth[year]={
            "v":tv,"pidx":pidx,"tidx":tidx,
            "truth_ref":truth_ref,"field":vf,
        }
        print(f"  {year}: matched={len(pidx)}, truth_ref={truth_ref:.4f}")

    branch_names=[
        "OLS_GACOS_RAW",
        "STAGE7_RAW",
        "OLS_GACOS_LEGACY_RAMP_SCN",
        "STAGE7_LEGACY_RAMP_SCN",
    ]
    branch_pred={b:{y:np.full(n_ps,np.nan,dtype=np.float32) for y in (2021,2022,2023)} for b in branch_names}

    for r0 in range(0,n_ps,args.block_ps):
        r1=min(n_ps,r0+args.block_ps)
        Y=np.asarray(gacos_reader.block(r0,r1),dtype=np.float64)
        O=reconstruct_ols(Y,P,n_image,edge_sign)
        S=np.asarray(stage7_reader.block(r0,r1),dtype=np.float64)
        R=np.asarray(ramp_reader.block(r0,r1),dtype=np.float64)
        C=np.asarray(scn_reader.block(r0,r1),dtype=np.float64)

        X={
            "OLS_GACOS_RAW":O-ref_ols_raw[None,:],
            "STAGE7_RAW":S-ref_s7_raw[None,:],
            "OLS_GACOS_LEGACY_RAMP_SCN":O-R-C-ref_ols_corr[None,:],
            "STAGE7_LEGACY_RAMP_SCN":S-R-C-ref_s7_corr[None,:],
        }

        for year in (2021,2022,2023):
            c=slope_coefficients(dts,year)
            for b in branch_names:
                branch_pred[b][year][r0:r1]=((X[b]@c)*phase_to_mm).astype(np.float32)

        if r0==0 or r1==n_ps or r1%50000<args.block_ps:
            print(f"  truth-isolation PS: {r1}/{n_ps}")

        del Y,O,S,R,C,X
        gc.collect()

    truth_rows=[]
    pooled_rows=[]
    for b in branch_names:
        pp=[];tt=[]
        for year in (2021,2022,2023):
            td=truth[year]
            pred=branch_pred[b][year][td["pidx"]]
            tv=td["v"][td["tidx"]]
            mm=validation_metrics(pred,tv)
            truth_rows.append({"branch":b,"year":year,**mm})
            good=np.isfinite(pred)&np.isfinite(tv)
            pp.append(pred[good]);tt.append(tv[good])
        pm=validation_metrics(np.concatenate(pp),np.concatenate(tt))
        pooled_rows.append({"branch":b,**pm})

    write_csv(out/"10_truth_isolation_by_year.csv",truth_rows)
    write_csv(out/"11_truth_isolation_pooled.csv",pooled_rows)

    # Current Final-C baseline for consistency check.
    final_candidates=sorted(
        [p for p in dataset.glob("final_C_fixed_reference_*") if (p/"velocity"/"final_C_velocity_points.npz").exists()],
        key=lambda p:p.stat().st_mtime,reverse=True
    )
    current_final=None
    if final_candidates:
        fp=final_candidates[0]/"velocity"/"final_C_velocity_points.npz"
        pp=[];tt=[]
        with np.load(fp,allow_pickle=False) as z:
            for year in (2021,2022,2023):
                v=np.asarray(z[f"velocity_{year}_mm_yr"],dtype=float)
                td=truth[year]
                pred=v[td["pidx"]];tv=td["v"][td["tidx"]]
                good=np.isfinite(pred)&np.isfinite(tv)
                pp.append(pred[good]);tt.append(tv[good])
        current_final=validation_metrics(np.concatenate(pp),np.concatenate(tt))

    # Final interpretation.
    pooled_by={r["branch"]:r for r in pooled_rows}
    stage7_gain_raw=pooled_by["OLS_GACOS_RAW"]["rmse_mm_yr"]-pooled_by["STAGE7_RAW"]["rmse_mm_yr"]
    stage7_gain_corr=pooled_by["OLS_GACOS_LEGACY_RAMP_SCN"]["rmse_mm_yr"]-pooled_by["STAGE7_LEGACY_RAMP_SCN"]["rmse_mm_yr"]

    conclusion={
        "network":{
            "n_ps":n_ps,"n_image":n_image,"n_ifg":n_ifg,
            "rank":rankA,"edge_sign":edge_sign,"sign_scores":sign_scores,
        },
        "stage7_minus_direct_ols":{
            "median_epoch_plane_r2":float(np.nanmedian(r2_g)),
            "p05_epoch_plane_r2":float(np.nanpercentile(r2_g,5)),
            "median_after_plane_p95_rad":float(np.nanmedian(p95_g)),
        },
        "edge_backprojection":edge_summary,
        "truth_isolation":{
            "pooled":pooled_rows,
            "stage7_rmse_gain_vs_ols_raw_mm_yr":stage7_gain_raw,
            "stage7_rmse_gain_vs_ols_under_same_legacy_ramp_scn_mm_yr":stage7_gain_corr,
            "current_final_C_pooled":current_final,
        },
        "top_saved_variable_identity_matches":identity_rows[:15],
        "interpretation":(
            "If STAGE7_LEGACY_RAMP_SCN is materially better than "
            "OLS_GACOS_LEGACY_RAMP_SCN, the acquisition-space Stage7 solution itself "
            "contributes measurable truth skill under identical downstream corrections. "
            "If their difference is small, the dominant advantage lies in downstream "
            "ramp/SCN rather than Stage7 network inversion."
        ),
        "reference_source":ref_source,
        "runtime_seconds":time.time()-t0,
    }
    (out/"12_CONCLUSION.json").write_text(
        json.dumps(conclusion,ensure_ascii=False,indent=2),encoding="utf-8"
    )

    readme=f"""
V4 Stage7 exact solver / reconstruction audit complete
============================================================================

Network:
  n_ps={n_ps}
  n_image={n_image}
  n_ifg={n_ifg}
  rank={rankA}/{n_image-1}
  edge_sign={edge_sign}

Stage7-vs-OLS:
  median per-epoch plane R2 = {np.nanmedian(r2_g):.6f}
  P05 per-epoch plane R2    = {np.nanpercentile(r2_g,5):.6f}

Truth isolation pooled RMSE:
  OLS_GACOS_RAW                  = {pooled_by['OLS_GACOS_RAW']['rmse_mm_yr']:.6f}
  STAGE7_RAW                     = {pooled_by['STAGE7_RAW']['rmse_mm_yr']:.6f}
  OLS_GACOS_LEGACY_RAMP_SCN      = {pooled_by['OLS_GACOS_LEGACY_RAMP_SCN']['rmse_mm_yr']:.6f}
  STAGE7_LEGACY_RAMP_SCN         = {pooled_by['STAGE7_LEGACY_RAMP_SCN']['rmse_mm_yr']:.6f}

Stage7 RMSE gain under identical legacy Ramp+SCN:
  {stage7_gain_corr:.6f} mm/yr

Key outputs:
  01_stage7_source_files.csv
  02_stage7_source_key_excerpts.csv
  03_mat_variable_inventory.csv
  04_epoch_stage7_minus_ols_decomposition.csv
  05_stage7_minus_ols_rate_contribution.csv
  06_edge_backprojection_residuals.csv
  07_edge_backprojection_summary.json
  08_saved_variable_identity_scores.csv
  09_known_stage7_identities.csv
  10_truth_isolation_by_year.csv
  11_truth_isolation_pooled.csv
  12_CONCLUSION.json

READ-ONLY:
  This audit does not modify or regenerate Stage6/7/8 or Final-C.
""".strip()
    (out/"READ_ME_FIRST.txt").write_text(readme+"\n",encoding="utf-8")

    print()
    print("="*80)
    print("V4 COMPLETE")
    print("="*80)
    print(f"runtime={time.time()-t0:.1f}s")
    print("OUTPUT:",out)
    print("Stage7 RMSE gain under same legacy Ramp+SCN:",stage7_gain_corr)
    print()
    print("First inspect:")
    for p in [
        out/"02_stage7_source_key_excerpts.csv",
        out/"05_stage7_minus_ols_rate_contribution.csv",
        out/"07_edge_backprojection_summary.json",
        out/"08_saved_variable_identity_scores.csv",
        out/"11_truth_isolation_pooled.csv",
        out/"12_CONCLUSION.json",
    ]:
        print(" ",p)


if __name__=="__main__":
    main()
