#!/usr/bin/env bash
set -euo pipefail

ROOT="${ROOT:-/home/ubuntu/software/pystamps-main}"
PYTHON="${PYTHON:-/home/ubuntu/software/miniconda3/envs/stamps/bin/python}"
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mkdir -p "$ROOT/tools"

cp "$HERE/stage7_exact_solver_audit_v4.py" \
   "$ROOT/tools/stage7_exact_solver_audit_v4.py"

cp "$HERE/run_stage7_exact_solver_audit_v4.sh" \
   "$ROOT/run_stage7_exact_solver_audit_v4.sh"

chmod +x "$ROOT/tools/stage7_exact_solver_audit_v4.py"
chmod +x "$ROOT/run_stage7_exact_solver_audit_v4.sh"

echo "Installed:"
echo "  $ROOT/tools/stage7_exact_solver_audit_v4.py"
echo "  $ROOT/run_stage7_exact_solver_audit_v4.sh"
echo
echo "No production MAT file is modified."
echo "No Conda/Python package is installed or upgraded."

echo
echo "Dependency check:"
"$PYTHON" - <<'PY'
mods=["numpy","scipy","h5py","geopandas"]
missing=[]
for m in mods:
    try:
        __import__(m)
        print("  OK  ",m)
    except Exception as e:
        print("  MISS",m,repr(e))
        missing.append(m)
if missing:
    raise SystemExit("Missing dependencies: "+", ".join(missing))
PY

echo
echo "Self-test:"
"$ROOT/run_stage7_exact_solver_audit_v4.sh" --self-test

echo
echo "Installation complete."
echo "Run:"
echo "  cd '$ROOT'"
echo "  ./run_stage7_exact_solver_audit_v4.sh"

if [[ "${1:-}" == "--run" ]]; then
    shift
    exec "$ROOT/run_stage7_exact_solver_audit_v4.sh" "$@"
fi
