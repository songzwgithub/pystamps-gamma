# V4 Stage7 exact solver / reconstruction audit

This is the next step after V3.

V3 showed that full-network per-PS/per-IFG coherence/variance WLS does not beat
the current Final-C. Therefore V4 stops changing the inversion and instead audits
the exact Stage7 mechanism.

## What V4 answers

1. Which Stage7 source file is actually installed?
2. Which equations / solver calls are used around `ph_uw`, `ifg_vcm`, `SCLA`,
   `ph_ramp`, `bperp`, and covariance/weighting?
3. How different is `phuw_sm2.mat:ph_uw` from direct OLS of
   `phuw2_gacos.mat:ph_uw`?
4. Is that difference mostly:
   - epoch common mode,
   - an XY plane,
   - or a non-planar spatial field?
5. Does Stage7 have larger IFG back-projection residual than direct OLS?
6. Which saved Stage7 variable best explains `Stage7 - OLS`?
7. Under the SAME old Ramp+SCN fields and the SAME fixed 65-PS reference, how much
   truth RMSE advantage comes specifically from the Stage7 acquisition-space solution?

## Install

```bash
cd /home/ubuntu/software/pystamps-main

rm -rf /tmp/stage7_v4
mkdir -p /tmp/stage7_v4

unzip /上传目录/stage7_exact_solver_audit_v4.zip \
  -d /tmp/stage7_v4

bash \
  /tmp/stage7_v4/stage7_exact_solver_audit_v4/install.sh
```

Run:

```bash
cd /home/ubuntu/software/pystamps-main
./run_stage7_exact_solver_audit_v4.sh
```

## First outputs to inspect

```bash
D=/mnt/vol-gdc28n1r/insar/cangzhou_P69/pystamps_sbas_ps_optimized

LATEST=$(
  find "$D/_audit" \
    -maxdepth 1 \
    -type d \
    -name 'stage7_exact_solver_audit_v4_*' \
    -printf '%T@ %p\n' |
  sort -nr |
  head -1 |
  cut -d' ' -f2-
)

echo "===== SOURCE EXCERPTS ====="
column -s, -t "$LATEST/02_stage7_source_key_excerpts.csv" | less -S

echo "===== RATE CONTRIBUTION ====="
column -s, -t "$LATEST/05_stage7_minus_ols_rate_contribution.csv"

echo "===== EDGE RESIDUAL ====="
cat "$LATEST/07_edge_backprojection_summary.json"

echo "===== IDENTITY SEARCH ====="
column -s, -t "$LATEST/08_saved_variable_identity_scores.csv" | head -30

echo "===== TRUTH ISOLATION ====="
column -s, -t "$LATEST/11_truth_isolation_pooled.csv"

echo "===== CONCLUSION ====="
cat "$LATEST/12_CONCLUSION.json"
```

## Safety

Read-only. It does not rerun or overwrite:
- Stage6;
- Stage7;
- Stage8;
- Final-C;
- the expensive V3 coherence cache.
